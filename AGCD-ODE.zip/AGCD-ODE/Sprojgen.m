function S = Sprojgen(E,n,m)
% Projection onto Sylvester structure
% E is the matrix we want to project
% n is the degree of the polynomials
% m is the number of polynomials




%E=randi([0,2],p+2*n,p+n)
% if nargin<5
%     istart2=1;
% %   if also q is constrained to be monic:    
% %   istart2=2;
% end
% if nargin<4 | istart ~= 1
%     istart=2;
%     p(1)=0;
% end
for i=1:n+1
    P(1,i)=0;
    for j=1:n
      P(1,i)=P(1,i)+E(j,i-1+j);
%          set  0 if p does not change
    end
    P(1,i)=P(1,i)./n;
end

for k=2:m
for i=1:n+1
    P(k,i)=0;
    for j=1:n
%       P(k,i)=P(k,i)+E((k-1)*n+j,n+i-j);
        P(k,i)=P(k,i)+E((k-1)*n+j,i+j-1);
    end
    P(k,i)=P(k,i)./n;
end 
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% patterns of variable parameters, example
% p(2)=0; p(4)=0; p(6)=0; q(2)=0; q(4)=0; q(6)=0;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

for i=1:n
    S(i,:)   = [zeros(1,i-1),P(1,:),zeros(1,n-i)];
end

for k=2:m
for i=1:n
    S((k-1)*n+i,:) = [zeros(1,i-1),P(k,:),zeros(1,n-i)];
end
end
