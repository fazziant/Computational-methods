function [sv,dist,eps0,A,E,Phat,epsval,len ] = dist_uncontrgen(P,deg,tol,itmax,E )
%   estimates distance to uncontrollability
%%%%%%%  output
% sv  d_th singular value at each step
% dist  computed value of distance
% eps0  final value of epsilon
% A  starting Sylvester matrix
% E  final (normalized) perturbation
% Phat  computed perturbed polynomials
% epsval  vector containing the values of epsilon at each step
    
%%%%%%%% input
% P matrix whose rows contain the coefficients of the data
% polynomials
% deg degree of the approximate GCD
% tol stopping tolerance
% itmax  maximum number oof iterations (optional)
% E starting perturbation
    
% default
if nargin<4
    itmax=40;
end

h0=1e-6;
threshold=1e-6;
c=0.5;
epsval=[];

[mP,nP]=size(P);
n=nP-1;

%construction of A
A=readpol(P);
[mA,nA]=size(A);
sigma=svd(A);
sv=[sigma(end+1-deg)];
if sv(end)<tol
    disp('the polynomials have a common factor')
    return
end


% estimate interval for distance
epsmin=sv(1);  

 epsmax=norm(A,'fro');
eps0=min(2*epsmin,(epsmin+epsmax)/2);



if nargin < 5
[zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0);
else
    [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0,E);
end
F(:,:,1)=E;

sv=[sv, zvec(end)];
len=[length(zvec)];
for it=1:itmax
    
    epsval(it)=eps0;
    
  
    if abs(sv(end)) > threshold 
     
        bis=0;
   %%%%% Newton's method
        epsmin=eps0;
 

[U,Sigma,V]=svd(B);
   z = Sigma(nA+1-deg,nA+1-deg);
   x=V(:,end+1-deg);
   x=x/norm(x);
   y=U(:,size(V,2)+1-deg); 
   y=y/norm(y);
  
    
         drho=norm(Sprojgen((y*x'),nP-1,mP),'fro');
         eps1=eps0+ (z/drho);
         
       
       
          
        
        if eps1>epsmin && eps1<epsmax
            if abs(eps1-eps0)<tol 
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            eps0=(1-c)*epsmin+c*epsmax;
        end
    else
        bis=1;
        disp('bisection step'), it
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
        if abs(eps0-epsmax)<tol 
      
                break
        end
       
    end
    zvec=[];
    Eold=E;
    disp('integration of ODE')
    if it >= 1
        [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0,E);
        
    else
        [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0)
       
    end
    F(:,:,it+1)=E;
    disp('completed')
    sv=[sv, zvec(end)];
    len=[len, length(zvec)];


 if  bis==0 && (sv(end)>sv(end-1))
%         while (sv(end)>sv(end-1))
        disp('adjusted monotonicity')
        sv=sv(1:end-1);
        len=len(1:end-1);
        F=F(:,:,end-1);
        
          eps0=1.5*eps0;
          h0=10*h0;
         
         [zvec,x,y,A,B,E]=controlodegen(P,deg,eps0,h0,F(:,:,end));
        F(:,:,it+1)=E;
        sv=[sv, zvec(end)];
        len=[len, length(zvec)];
         
%         end
 end

end
% this is the computed distance;
ddd=[];
for k=1:mP
    ddd=[ddd, E(1+(k-1)*n, :)];
end
dist=eps0*norm(ddd,'fro');
B=A+eps0*E;
Phat(1,:)=B(1,1:n+1); 
for k=2:mP
% Phat(k,:)=B((k-1)*n+1,nP-1:end); 
Phat(k,:)=B((k-1)*n+1,1:n+1); 
end
end