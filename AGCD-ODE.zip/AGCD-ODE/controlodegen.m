function [zvec,x,y,A,B,E]=controlodegen(P,deg,epsil,h0,E)
%%%%%%% output 
% zvec = smallest singular value
% x = left eigenvector of B^T B associated to the smallest eigenvalue
% y = B*x
% A = Sylvester matrix associated to the starting polynomials
% B = A + epsilon * E
% E = Perturbation matrix

%%%%%%%%%%%%  input
% P = matrix containing the data polynomials
% deg is the degree of the GCD
% epsil: scalar parameter of the perturbation epsilon * E
% h0 = starting value of the step in Euler method
% E = perturbation matrix
  

format short
tol=1e-8;
h=h0;
hmin=1e-14;
countmax=40;
gamma=1.25;%1.25;


[mP,nP]=size(P);


A=readpol(P);
[mA,nA]=size(A);

% Initialization
k=1;
if nargin < 5
    E=zeros(mA,nA);
    B=A+epsil*E;
  

   [U,Sigma,V]=svd(B);
   
   z = Sigma(nA+1-deg,nA+1-deg);
   x=V(:,end+1-deg);
   x=x/norm(x);
   y=U(:,size(V,2)+1-deg);
   y=y/norm(y);
    if (y'*x)<0
        x=-x;
    end
    E=-(y*x');     
   
    
    E=Sprojgen(E,nP-1,mP);
    
    E=E/norm(E,'fro');
%   starting matrix   
    B=A+epsil*E;
  

[U,Sigma,V]=svd(B);

   z = Sigma(nA+1-deg,nA+1-deg)
   
   x=V(:,end+1-deg);
   x=x/norm(x);
    y=U(:,size(V,2)+1-deg); 
    y=y/norm(y);
    
    
    zvec(k)=z;
    Edot=-(y*x');                  
    Edot=Sprojgen(Edot,nP-1,mP);
    Edot=Edot- (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');
   
else
    E=Sprojgen(real(E),nP-1,mP);
    E=E/norm(E,'fro');
    B=A+epsil*E;

   [U,Sigma,V]=svd(B);
   
  format long
   z = Sigma(nA+1-deg,nA+1-deg);
  
   x=V(:,end+1-deg);
   x=x/norm(x);
   y=U(:,size(V,2)+1-deg); 
   y=y/norm(y);
   
   
    zvec(k)=z;
    Edot=-(y*x');                       
    Edot=Sprojgen(Edot,nP-1,mP);
    Edot=Edot - (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');
end

Eold=E;

while h>hmin

z=zvec(k);
count=0;
  while count<=countmax
    count=count+1;
    B=A+epsil*E;
 

[U,Sigma,V]=svd(B);
format long
%diag(Sigma)
   z = Sigma(nA+1-deg,nA+1-deg);
   x=V(:,end+1-deg);
     x=x/norm(x);
     y=U(:,size(V,2)+1-deg); 
     y=y/norm(y);
     
    if abs(z)<abs(zvec(k))
        Edot=-(y*x');                
        Edot=Sprojgen(Edot,nP-1,mP);
        Edot=Edot-(trace(Edot'*E))*E;
        Edot=Edot/norm(Edot,'fro');

        k=k+1;
        zvec(k)=z;
        Eold=E;
        break
    else
        h=h/gamma;
        E=Eold+h*Edot;
        E=E/norm(E,'fro');
    end
end

if count==1
    h=h*gamma;
end
if count==countmax+1
   disp('maximum number of its reached in while loop')
    return
end


% Error control
if k>1
    if abs(zvec(k)) > abs(zvec(k-1))
        disp('monotonicity broken');
       pause
    end
    if abs(zvec(k)) <= tol
       disp('matrix looks singular');
        return
    end
    if abs(zvec(k)-zvec(k-1)) <= tol
        disp('reached tolerance');
        return
    end
end

% Euler step
E=Eold+h*Edot; 
E=E/norm(E,'fro');

end