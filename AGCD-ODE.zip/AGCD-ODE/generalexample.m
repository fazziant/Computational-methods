function [Phat,dist]=generalexample(P,deg)
clear;close all

% P=[3 2 5 1;
%    1 -1 -3 1;
%    1 1 0 0];
% deg=1;

% P=randi(4,4,7);
% deg=4;

 P=[1 2 2 2;
  2 0 1 -2];
 deg=1;


% P=[1,2,2,5;
%     3, 0, 1, 0;
%     1, 1, 1, 0];

% P=[1, 0, 1, 0, 2, 1;
%     -2, 1, 1, -1, 0, 1];
% deg=1;

%P=[randi(2,1,6);randi([-2,1],1,6)];deg=1;

%P=[conv([1,-1],[1,2,1]);
%    conv([1,-1],[1,3,1])];
%deg=1;

% P=[conv([1,-1],[1,0,0])+.01*randn(1,4);
%     conv([1,-1],[1,0,1])+.01*randn(1,4)];
% deg=1;

% P=[1, zeros(1,13), -1;
%    1, zeros(1,13), -3];
% deg=1;

% P=[1, ones(1,13), -1;
%    1, ones(1,13), -3];
% deg=1;

% p=poly([1,2,3,4,5]);
% P=[p;p+[2,0,0,0,0,0]];
% deg=1;

% n=1
% P=[1,zeros(1,10*n),ones(1,10*n),5;
%     1,ones(1,10*n),zeros(1,10*n),1];
% deg=1;

% P=[poly([1,1]); poly([-1,-1])];
% deg=1;

% P=[poly([ones(1,5),3,2]);poly([ones(1,5),4,2.2])];
% deg=6;

% load testdim
% P=P3;
% deg=1;

% % A=readpol(P);
% % [mA,nA]=size(A);

% P=[0, 0.8766, -1.9450, -10.8798, 12.0185;
%     1.3460, 3.8783, -7.1474, -22.3500, 24.1821];  
% deg=2;

% P=[1, -3.2, 2.2;
%     1, -6.5, 10];
% deg=1;


tic
[sv,dist,eps0,A,E,Phat,epsval,len ] = dist_uncontrgen(P,deg,1e-6);
t_ode=toc
t_iter=t_ode/length(epsval)
len
tit=t_ode/sum(len)*len
dist
% svd(readpol(Phat))
% % [sv,dist,eps0,A,E,Phat,epsval ] = dist_uncontrgen(P,deg,1e-6,40,randn(mA,nA));
sv
epsval
%plot(epsval)
%semilogy(sv,'-o')
format long
disp('estimated distance to uncontrollability'), [dist,eps0]

disp('perturbed polynomials, phat constrained to be monic')
Phat
%relerr=norm(P-Phat,'fro')/norm(P,'fro')
[mP,nP]=size(Phat);
disp('roots of phat and qhat')
roo=[];
for k=1:mP
roo=[roo, roots(Phat(k,:))];
end
%[[NaN*ones(nr-nph,1);roots(phat)],[NaN*ones(nr-nqh,1);roots(qhat)]]
roo
% svd(readpol(P))
% svd(readpol(Phat))


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

