% pdp
%
% Print polynomial matrices on the screen in symbolic form
%
% The command
%
%    pdp(P[,variable])
%
% displays the polynomial matrix P in 'symbolic' form using 
% powers of an indeterminate and coefficients such as
%
%    1 + 2s + 3s^2
%
% To prevent clutter the coefficients are displayed in three 
% digits accuracy only. Very small coefficients are set equal 
% to zero.
%
% If another one-character string is used as the second input 
% argument then the entries are returned as polynomials in powers 
% of this character. For instance, pdp(P,'d') returns the entries as
%
%    1 + 2d + 3d^2

% COPYRIGHT S. Pejchova, L. Burzacott, M. Sebek, 1997
% $Revision: 1.6 $     $Date: 1997/06/26  14:52:13$   $State: Exp $

function pdp(Ao,arg2)

smb='s';
if nargin<1
   test1=1;
elseif isstr(Ao)
   test1=1;
elseif nargin==2
   if isstr(arg2), smb=arg2(1);
   else, test1=1;
   end
end
if test1
 disp('usage: pdp(A[,''s'']) ');
 return
end      
[type,rA,cA,degA]=pinfo(Ao);  
A=punpck(Ao);            
A=pzero(A,1e-10*norm(A,inf));

if isempty(A)
   disp('[]');
elseif isnan(degA) | degA==0
   disp(' '); disp(A);
else
   strA=zeros(rA,cA);
   negA=strA;

   for i = 1:rA
      for j = 1:cA
         pols = '';
         nonzero = 0; % Set TRUE ( 1 ) when we get a nozero coeff.
         for d = 0:degA
            col = d*cA+j;
            if A(i,col) ~= 0
               nonzero = 1;
               if d == 0
                  pols = [pols, sprintf('%1.3g',A(i,col))];
               elseif abs(A(i,col)) ~= 1
                  pols = [pols, sprintf('%1.3g',abs(A(i,col)))];
               end
               if d > 0
                  pols = [pols,smb];
                  if d > 1
                     pols = [pols,'^',int2str(d)];
                  end
               end
            end
            if d < degA
               nextterm = (d+1)*cA+j;
               if A(i,nextterm) < 0
                  pols = [pols,' - '];
               elseif A(i,nextterm) > 0 & nonzero
                  pols = [pols,' + '];   % There is no need for a '+' if all 
                                         %terms so far including this one are 0.
               end
            end
         end
         if ~nonzero
            pols = [pols,'0'];
         end
         strA(i,j)=length(pols);
         if strcmp(pols(1),'-'), negA(i,j)=1; end;
         strtx=['polmtex',int2str(i),'a',int2str(j),'=pols;'];
         eval(strtx); 
      end % of column loop. 
   end % of row loop.

   pmcol=find((sum(negA)>0)&(sum(negA)<rA));
   plusA=zeros(rA,cA); 
   if ~isempty(pmcol), plusA(:,pmcol)=~negA(:,pmcol); end
   strA=strA+plusA;
   if rA>1
      maxlen=max(strA);
   else, maxlen=strA;
   end
   polmtx='';
   for i=1:rA
      polstring='';
      for j=1:cA
         strcol=['auxstr=polmtex',int2str(i),'a',int2str(j),';'];
         eval(strcol);
         if length(auxstr)~=strA(i,j), auxstr=[' ',auxstr]; end
         auxstr=['    ',auxstr];
         if strA(i,j)<maxlen(j)
            for sp=1:(maxlen(j)-strA(i,j))
                auxstr=[auxstr,' '];
            end
         end
         polstring=[polstring,auxstr];
      end
      polmtx=[polmtx; polstring];
   end
   maxlen=maxlen+4;            
 
   if cA == 1                  % Now to display the matrix of strings.
      disp(' ');
      disp(polmtx);
      disp(' ');
   else
      colsinline = fix(72/(max(maxlen)));
      if colsinline<1
         disp('Warning: Too wide column - can not be displayed.');
         return
      end
      rowcount = 0;
      colstart=1; colstop=1;
      lastchar=0;
      while colstart<=cA

       for i=colstart:cA
        rowwd=sum(maxlen(colstart:i));
        colstop=i;
        if rowwd > 72
           rowwd=sum(maxlen(colstart:i-1));
           colstop=i-1;
           break;
        end
       end
       if colstop~= colstart
          disp(' ');
          fprintf('Columns %g through %g\n\n',colstart,colstop);
       else
          disp(' ');
          fprintf('Column %g\n\n',colstart);
       end
       disp(polmtx(:,lastchar+1:lastchar+rowwd));
       disp(' ');

       rowcount = rowcount + 2 + rA;
       if rowcount > 20
          fprintf('\nHit any key to continue. ');
          pause;
          fprintf('\n\n');
          rowcount = 0;
       end
       colstart=colstop+1;
       lastchar=lastchar+rowwd;      
      end
   end
end


