% prank
%
% Rank of a polynomial matrix
%
% The function
%
%   r = prank(A)
%   r = prank(A,tol)
%
% computes the rank of a polynomial matrix.
%
% The algorithm is based on evaluation of the rank of constant 
% matrices and therefore the optional input argument tol has the 
% same meaning as for the standard Matlab function rank.

% Check rank by substitution.
% Henrion D. 9-96
% $Revision: 1.2 $	$Date: 1996/10/15 09:39:50 $	$State: Exp $
% Modified by Henrion D. 4-97 : random numbers are chosen distinct
% Modified by S. Pejchova, June 28, 1997

function r = prank(A,tol)

if nargin < 1
 disp('usage:  r = prank(A[,tol])');
 return
end

[typeA, rA, cA, degA] = pinfo(A);

if isinf(degA)|isempty(A)
  r = 0;
elseif (typeA == 'cons') | (degA == 0),
  A = punpck(A);
  if nargin == 1,
    r = rank(A);
  else
    r = rank(A,tol);
  end;
else
  i = 0;
  rmax = min([rA cA]);
  % maximal number of values to be substituted to avoid zeroes
  imax = rmax*degA+1;
  % already selected values to be compared
  olds = ones(imax,1)*Inf;
  r = 0;
  % r = rmax means that matrix has full rank and then the macro stops
  while (i < imax) & (r < rmax),
    i = i+1;
    s = randn;
    % ensure that this value has not been selected previously
    while any(abs(olds - s) < 1e-3),
      s = randn;
    end;
    olds(i) = s;
    Ap = pval(A, randn);
    if nargin == 1,
      rnew = rank(Ap);
    else
      rnew = rank(Ap, tol);
    end;
    if rnew > r,
      r = rnew;
    end;
  end;
end;

