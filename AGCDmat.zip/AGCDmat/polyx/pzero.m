%pzero
%
% Set small coefficients of a polynomial matrix
% equal to zero
%
% The commands
%
%   C = pzero(A)
%   C = pzero(A,EP)
%
% set all scalar coefficients with absolute value <= EP of the 
% polynomial matrix A equal to zero.
%
% If the argument EP is missing then the macro sets EP = eps*10^(8). 

% S. Pejchova, 1995
% $Revision: 1.1 $	$Date: 1995/12/05 11:33:10 $	$State: Exp $

function C = pzero(A,EP)

if nargin > 2 | nargin < 1
   disp('usage: C = pzero(A,EP)')
   return
end
if nargin == 1
   EP=eps*1e8;
end

[typeC,rC,cC,degC] = pinfo(A);
if typeC == 'poly'
   C=punpck(A);
 else
   C=A;, degC=0;
end
if isempty(C)==0 & degC >= 0
   for j=1:rC
       MC=find(abs(C(j,:))<=abs(EP));
       if isempty(MC)==0
          [k,l]=size(MC);
          C(j,MC)=zeros(k,l);
       end
   end 
end
if typeC == 'poly'
   C=ppck(C,degC);
end
