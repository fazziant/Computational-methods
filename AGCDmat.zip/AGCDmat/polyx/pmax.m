%pmax
%
% Maximum scalar coefficient of a polynomial matrix
%
% The command
%
%    c = pmax(A)
%
% finds the maximum (in absolute value) scalar coefficient occuring 
% in the polynomial matrix A .

% S. Pejchova, 1995
% $Revision: 1.1 $	$Date: 1995/12/05 10:41:07 $	$State: Exp $

function c = pmax(A)

if nargin ~= 1
   disp('usage: c = pmax(A)')
   return
end

[typeA,rA,cA,degA] = pinfo(A);

if typeA == 'poly'
    A = punpck(A);
end
c=max(max(abs(A)));
