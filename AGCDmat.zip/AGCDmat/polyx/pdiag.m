% pdiag
%
% Diagonals of polynomial matrices and diagonal polynomial matrices
%
% If A is a matrix, then the command
%
%    d = pdiag(A)        returns the main diagonal of the
%                        polynomial matrix A.
%
%    d = pdiag(A,k)      returns the k-th diagonal of A: k = 0 
%                        represents the main diagonal, k > 0 refers
%                        to above the main diagonal and k < 0 to 
%                        below the main diagonal.
%
% If a is a vector of polynomials of length n then the command
%
%    D = pdiag(a,k)      returns a square polynomial matrix D of 
%                        size n+abs(k) with the elements of a on 
%                        the k-th diagonal.
%
%    D = pdiag(a)        does the same with k = 0.

% S. Pejchova, 1995
% $Revision: 1.2 $	$Date: 1995/12/05 10:20:24 $	$State: Exp $

function [D] = pdiag(A,k)

if nargin < 1
   disp('usage: d = pdiag(A)');
   disp('   or  d = pdiag(A,k)');
   disp('   or  D = pdiag(A,k)');
   disp('   or  D = pdiag(A)');
   return
end

if nargin == 1
   k=0;
end
[typeA,rA,cA,degA]=pinfo(A);
if typeA=='empt' | typeA=='cons'
   D=diag(A,k);
 else
   AR=punpck(A);
   if degA < 0, degA=0;, end
   if (rA>1) & (cA>1)
      if k < 0
         Dr=min(rA+k,cA);
       else
         Dr=min(rA,cA-k);
      end
      if Dr < 1
         D=[];
         return
      end
      D=zeros(Dr,(degA+1));
      for i=1:degA+1
          D(:,i)=diag(AR(:,(cA*(i-1)+1):(cA*i)),k);
      end
    else
      if cA>1
         A=ptransp(A);
         rA=cA; cA=1;
         AR=A(1:rA,1:degA+1);
      end
      m=rA+abs(k);
      D=zeros(m,m*(degA+1));
      for j=1:degA+1
          D(:,m*(j-1)+1:m*j)=diag(AR(:,j),k);
      end
   end
   D=ppck(D,degA);
end
