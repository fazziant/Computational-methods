% mixed
%
% Solution of the SISO mixed sensitivity problem
%
% The command
%
%    [y,x,gopt] = mixed(n,m,d,a1,b1,a2,b2,gmin,gmax,accuracy,tol,show)
%
% solves the mixed sensitivity problem for the SISO plant P = n/d
% with weighting functions V = m/d, W1 = a1/b1 and W2 = a2/b2.
%
% The input parameters gmin and gmax are lower and upper bounds for
% the minimal H-infinity norm, respectively.
%
% The parameter accuracy specifies how closely the minimal norm is
% to be approached.
%
% The optional parameter tol is a tolerance that is used in canceling
% identical pole-zero pairs in the transfer function C = y/x of the
% optimal compensator.
%
% If a 12th input argument show is present then the successive values
% of gamma during the binary search are shown, and any pole-zero pairs
% that are canceled in y/x are reported.
%
% The output parameter gopt is an upper bound for the H-infinity norm.

% H. Kwakernaak, May, 1997
% Modified by S. Pejchova, June 16, 1997

function [y,x,gopt] = mixed(n,m,d,a1,b1,a2,b2,gmin,gmax,accuracy,tol,show)


% Checks

if nargin<10
 disp('usage: [y,x,gopt] = mixed(n,m,d,a1,b1,a2,b2,gmin,gmax,accuracy[,tol][,show])');
 return
end
if nargin == 10
   tol = 1e-4;
end
show = (nargin == 12);
if nargin > 12
   error('mixed: Too many input arguments')
end

[type,r,c,degm] = pinfo(m);
[type,r,c,degd] = pinfo(d);
if degd ~= degm
   error('mixed: The polynomials d and m have different degrees')
end
if degm > 0 & ~phurwitz(m)
   error('mixed: The polynomial m is not Hurwitz')
end
[type,r,c,degb1] = pinfo(b1);
if degb1 > 0 & ~phurwitz(b1)
   error('mixed: The polynomial b1 is not Hurwitz')
end
[type,r,c,degb2] = pinfo(b2);
if degb2 > 0 & ~phurwitz(b2)
   error('mixed: The polynomial b2 is not Hurwitz')
end


% Define the various polynomial matrices

D1 = ppck(zeros(3,2),0); D1 = pput(D1,1,1,b1); D1 = pput(D1,2,2,b2);
D2 = ppck(zeros(3,1),0); D2 = pput(D2,1,1,a1); D2 = pput(D2,3,1,d);
N1 = ppck(zeros(3,1),0); N1 = pput(N1,3,1,pscl(m,-1));
N2 = ppck(zeros(3,1),0); N2 = pput(N2,2,1,a2); N2 = pput(N2,3,1,pscl(n,-1));


% Left-to-right conversion

Q = ppck(eye(3),0); 
Q = pput(Q,1,1,b1); Q = pput(Q,2,2,b2); Q = pput(Q,3,3,m);
N2D2 = pcoljoin(N2,D2);
[Del,Lam] = lr(N2D2,Q);


% Prepare the search

if gmin > gmax
   error('The lower bound of gamma exceeds upper bound')
end

if show
   fprintf('\n     gamma  test result\n')
   fprintf('     -----  -----------\n')
end

% Check existence and stability for gamma = gmax

Jgamma = eye(3); Jgamma(3,3)= -gmax^2;
DelDel = pmul(cjg(Del),Jgamma,Del);
Eps = 1e6*eps*norm(punpck(DelDel),1);
if any(abs(real(proots(DelDel,'eig','all')))<Eps)
   error('No solution exists at the upper bound')
end
[Gam,J] = pjsf(DelDel,'ext',1);
xy = rl(pmul([1 0],Gam),Lam);
x = psel(xy,1,1); y = psel(xy,1,2);
phi = padd(pmul(n,y),pmul(d,x));
if ~phurwitz(phi)
   error('No stabilizing solution exists at the upper bound')
end

% Retain stabilizing solution
xopt = x; yopt = y; gopt = gmax;
if show, fprintf('%10.4f  stable\n',gmax),end


% Check existence and stability for gamma = gmin

Jgamma = eye(3); Jgamma(3,3)= -gmin^2;
DelDel = pmul(cjg(Del),Jgamma,Del);
Eps = 1e6*eps*norm(punpck(DelDel),1);
if all(abs(real(proots(DelDel,'eig','all')))>Eps)
   [Gam,J] = pjsf(DelDel,'ext',1);
   xy = rl(pmul([1 0],Gam),Lam);
   x = psel(xy,1,1); y = psel(xy,1,2);
   phi = padd(pmul(n,y),pmul(d,x));
   if phurwitz(phi)
      error('A stabilizing solution exists at the lower bound')
   else
      if show, fprintf('%10.4f  unstable\n',gmin),end
   end
else
   if show, fprintf('%10.4f  no solution\n',gmin),end
end


% Binary search

while gmax-gmin > accuracy
   gamma = (gmin+gmax)/2;
   Jgamma = eye(3); Jgamma(3,3)= -gamma^2;
   DelDel = pmul(cjg(Del),Jgamma,Del);
   Eps = 1e6*eps*norm(punpck(DelDel),1);
   if any(abs(real(proots(DelDel,'eig','all')))<Eps)
      gmin = gamma;
      if show, fprintf('%10.4f  no solution\n',gamma), end
   else
      [Gam,J] = pjsf(DelDel,'ext',1);
      xy = rl(pmul([1 0],Gam),Lam);
      x = psel(xy,1,1); y = psel(xy,1,2);
      phi = padd(pmul(n,y),pmul(d,x));
      if ~phurwitz(phi)
         gmin = gamma;
      if show, fprintf('%10.4f  unstable\n',gamma), end
      else
         gmax = gamma;
      if show, fprintf('%10.4f  stable\n',gamma),end
         xopt = x; yopt = y; gopt = gmax;
      end
   end
   if show
%      fprintf(1,'%g\n',gamma);
   end
end


% Cancel any common roots of xopt and yopt

rootsy = roots(punpckv(yopt,'rrow'));
xo = punpck(xopt); degxo = length(xo)-1;
yo = punpck(yopt); degyo = length(yo)-1;

for i = 1:length(rootsy)
   z = rootsy(i);

   % Divide xo(s) by s-z

   q = zeros(1,degxo);
   q(degxo) = xo(degxo+1);
   for j = degxo-1:-1:1
      q(j) = xo(j+1)+z*q(j+1);
   end

   % If the remainder is small then cancel
   % the factor s-z both in xo and in yo

   if abs(xo(1)+z*q(1)) < tol*norm(xo,1)
      xo = q; degxo = degxo-1;
      p = zeros(1,degyo);
      p(degyo) = yo(degyo+1);
      for j = degyo-1:-1:1
         p(j) = yo(j+1)+z*p(j+1);
      end
      yo = p; degyo = degyo-1;
      if show
        disp(sprintf('\nCancel root at %g\n',z));
      end
   end  
end

x = ppck(real(xo),degxo);
y = ppck(real(yo),degyo);
