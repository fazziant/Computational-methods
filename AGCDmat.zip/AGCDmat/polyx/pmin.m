% pmin
%
% Minimum nonzero scalar coefficient of a polynomial matrix
%
% The command
%
%    c = pmin(A)
%
% finds the minimal (in absolute value) but nonzero scalar 
% coefficient that occurs in the polynomial matrix A.

% S. Pejchova, 1995
% $Revision: 1.2 $	$Date: 1995/12/05 11:44:13 $	$State: Exp $

function c = pmin(A)

if nargin ~= 1
   disp('usage: c = pmin(A)')
   return
end

[typeA,rA,cA,degA] = pinfo(A);
C=punpck(A);
if typeA == 'empt'
   c=[];
 else
   [row,col]=find(C);
   if isempty(row)
      c=[];
    else
      c=abs(C(row(1),col(1)));, mr=c;
      for i=1:rA
          MC=find(C(i,:));
          if isempty(MC)==0
             mr=min(abs(C(i,MC)));
          end
          if mr<c
             c=mr;
          end
      end
   end
end
