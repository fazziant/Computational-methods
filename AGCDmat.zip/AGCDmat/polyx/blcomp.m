% blcomp
%
% The commands
%
%    [C,D] = blcomp(A)
%    [C,D] = blcomp(A,'bot')
%
% return for a square polynomial matrix A = A0 + A1*s + ... + AN*s^N
% with nonsingular leading coefficient AN its "bottom" block companion 
% matrix
%
%  C =   |    0        I        0    ...    0      |
%        |    0        0        I    ...    0      |
%        |   ...      ...      ...   ...   ...     |
%        |    0       ...      ...   ...    I      |
%        | -AN\A0    -AN\A1    ...      -AN\A(N-1) |
%
% The matrix D is an identity matrix of the same dimensions as C.
%
% Similarly, the commands
%
%    [C,D] = blcomp(A,'top')
%    [C,D] = blcomp(A,'rgh')
%    [C,D] = blcomp(A,'lft')
% return "top", "right" and "left" versions of the block companion
% matrix, respectively.
%
% If, in addition, the string 'sep' is used as an input argument,
% then the resulting block companion matrix is returned as two 
% separate matrices, for instance
%
%  C = |   0    I    0  ...  0    |     D = | I   0  ...   0  |
%      |   0    0    I  ...  0    |         | 0   I  ...   0  |
%      |  ...  ...  ... ... ...   |         |... ... ...  ... |
%      |   0   ...  ... ...  I    |         | 0  ...   I   0  |
%      | -A0  -A1  ...    -A(N-1) |         | 0  ...   0   AN |
%
% Here AN may be singular.

% functions used: pinfo, pdegco, punpckv

% S. Pejchova, 1996
% $Revision: 1.0 $      $Date: 1996/03/14 14:49:10 $    $State: Exp $

function [C,D] = blcomp(A,s1,s2)

if nargin==1
   s1='bot';, s2='nosep';
elseif nargin==2
   s2='nosep';
   if strcmp(s1,'sep'), s2=s1;, s1='bot';, end
end
test1=0;
if (nargin==0) | (nargin > 3)
   test1=1;
elseif isstr(A) | isstr(s1)==0 | isstr(s2)==0
   test1=1;
end
if  test1 
   disp('usage: C=blcomp(A),                or [C,D]=blcomp(A)')
   disp('or     C=blcomp(A,''sep''),          or [C,D]=blcomp(A,''sep'')')
   disp('or     C=blcomp(A,''bot''),          or [C,D]=blcomp(A,''bot'')')
   disp('or     C=blcomp(A,''bot'',''sep''),    or [C,D]=blcomp(A,''bot'',''sep'')')
   disp('or     C=blcomp(A,''top''),          or [C,D]=blcomp(A,''top'')')
   disp('or     C=blcomp(A,''top'',''sep''),    or [C,D]=blcomp(A,''top'',''sep'')')
   disp('or     C=blcomp(A,''rgh''),          or [C,D]=blcomp(A,''rgh'')')
   disp('or     C=blcomp(A,''rgh'',''sep''),    or [C,D]=blcomp(A,''rgh'',''sep'')')
   disp('or     C=blcomp(A,''lft''),          or [C,D]=blcomp(A,''lft'')')
   disp('or     C=blcomp(A,''lft'',''sep''),    or [C,D]=blcomp(A,''lft'',''sep'')')
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if rA~=cA
   error('blcomp: The input matrix is not square');
end
straux1=strcmp(s1,'bot')|strcmp(s1,'top')|strcmp(s1,'rgh')|strcmp(s1,'lft');
straux2=strcmp(s2,'sep') | strcmp(s2,'nosep');
if straux1 & straux2
   if isnan(degA) | degA<=0
      C=[];, D=[];
      return
   end
   LA=pdegco(A,degA);                                 %leading matrix coeff.
   if strcmp(s2,'nosep') & (abs(det(LA))<=eps*1e4)
      disp('blcomp warning: Singular leading coefficient matrix')
   end

   if degA==1                                          % degree is 1
      C=-pdegco(A,0);
      D=LA;
      if strcmp(s2,'nosep') & (strcmp(s1,'bot') | strcmp(s1,'top'))
         C=D\C;
         D=eye(rA);
      elseif strcmp(s2,'nosep') & (strcmp(s1,'rgh') | strcmp(s1,'lft'))
         C=C/D;
         D=eye(rA);
      end
      return
   end
   CZC=zeros((degA-1)*cA,cA);                         %zeros column block
   CZR=zeros(rA,(degA-1)*cA);                         %zeros row block
   CE=eye((degA-1)*cA);                               %identity block
   D=eye(degA*cA);

  if strcmp(s1,'bot')
     CAB=punpckv(A);
     CAB=CAB(:,1:degA*cA);                            %'bottom' block row
     if strcmp(s2,'nosep')
        CAB=LA\CAB;
     else
        D((degA-1)*rA+1:degA*rA,(degA-1)*cA+1:degA*cA)=LA;
     end
     C=[CZC,CE;-CAB];
     return
  end

  if strcmp(s1,'top')
     CAT=punpckv(A,'rrow');
     CAT=CAT(:,cA+1:(degA+1)*cA);                     %'top' block row
     if strcmp(s2,'nosep')
        CAT=LA\CAT;
     else
        D(1:rA,1:cA)=LA;
     end
     C=[-CAT;CE,CZC];
     return
  end

  if strcmp(s1,'rgh')
     CAR=punpckv(A,'col');
     CAR=CAR(1:degA*rA,:);                            %'right' block column
     if strcmp(s2,'nosep')
        CAR=CAR/LA;
     else
        D((degA-1)*rA+1:degA*rA,(degA-1)*cA+1:degA*cA)=LA;
     end
     C=[[CZR;CE],-CAR];
     return
  end
  if strcmp(s1,'lft')
     CAL=punpckv(A,'rcol');
     CAL=CAL(rA+1:(degA+1)*rA,:);                     %'left' block column
     if strcmp(s2,'nosep')
        CAL=CAL/LA;
     else
        D(1:rA,1:cA)=LA;
     end
     C=[-CAL,[CE;CZR]];
     return
  end
else
  error('blcomp: Illegal input string');
end
