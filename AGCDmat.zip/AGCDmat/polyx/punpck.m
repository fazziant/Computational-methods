%punpck
%
% Unpack a polynomial matrix
%
% The command
%
%    A = punpck(P)
%
% forms the constant matrix A by stripping off the last row and
% column of the polynomial matrix P. Empty and constant matrices
% are returned without any change.

% $Revision: 1.3 $	$Date: 1996/07/19 09:31:34 $	$State: Exp $

function A = punpck(P);

if nargin ~= 1
   disp('usage: A = punpck(P)')
   return
end

[typeP,rP,cP,degP] = pinfo(P);

if typeP == 'empt' | typeP == 'cons'
   A = P;
else
   [rP,cP] = size(P);
   A = P(1:rP-1,1:cP-1);
end
