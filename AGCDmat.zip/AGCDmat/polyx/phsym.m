% phsym
%
% The function
%
%     B = phsym(A)
%     B = phsym(A,J)
%
% constructs the para-Hermitian polynomial matrix 
% 
%    B(s) = A*(s) J A(s) = B*(s),
%
% where * denotes the conjugate of a polynomial matrix and J is 
% a constant symmetric matrix whose default value is the identity
% matrix. If J is not symmetric then it is replaced with (J+J')/2.
%
% If A and J are regular Matlab matrices then the result is the 
% product A'*J*A.

% Henrion D. 2-96
% functions used : pinfo, pmul, cjg
% Modified by Henrion D. 4-97 : (J+J')/2 if J non-symmetric
% Modified by S. Pejchova, June 26, 1997

function B = phsym(A,J)

if nargin < 1
 disp('usage:  B = phsym(A)');
 disp('   or   B = phsym(A,J)');
 return
end

[typeA, rA, cA, degA] = pinfo(A);
if nargin == 1,
  J = eye(rA);
else
  [typeJ, rJ, cJ, degJ] = pinfo(J);
  if degJ > 0,
    error('phsym: The second argument must be a constant matrix');
  elseif rJ ~= cJ,
    error('phsym: The first input argument must be square');
  elseif (rJ ~= rA),
    error('phsym: The input arguments must have the same size');
  end;
  J = punpck(J);
end;

J = (J+J')/2;

if (typeA == 'empt'),
  B = [];
elseif (typeA == 'cons'),
  B = A'*J*A;
elseif isinf(degA),
  B = A;
else
  B = pmul(cjg(A), J, A);
end;

end % function
