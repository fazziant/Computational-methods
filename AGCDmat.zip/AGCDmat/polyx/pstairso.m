% pstairso
%
% Ordered staircase triangular form of a polynomial matrix
%
% The commands
%
%    [D,U,V,UI,VI,rlD] = pstairso(A)
%    [D,U,V,UI,VI,rlD] = pstairso(A[,'z'][,tol][,'menu'][,'movie'])
%    [D,U,V,UI,VI,rlD] = pstairso(A,'low'[,'z'][,tol][,'menu'][,'movie'])
%
% convert the polynomial matrix A to the lower staircase triangular 
% matrix D by elementary column row operations (the unimodular 
% matrix V) and row permutations (the matrix U) such that D = U*A*V.
% The rows are ordered according to ascending row lengths.
%
% The command
%
%    [D,U,V,UI,VI,clD] = pstairso(A,'up'[,'z'][,tol][,'menu'][,'movie']).....(3)
%
% converts D to the upper staircase triangular matrix D by elementary
% row operations (the unimodular matrix V) and column permutations 
% (the matrix U) such that D = V*A*U. The rows are ordered according 
% to ascending column lengths.
%
% UI is the inverse of U and VI is the inverse of V.
%
% For the lower staircase form the vector rlD contains the lengths 
% of the rows of D. The length of each row is defined as the position 
% of the last non-zero element in the row (counted from the left to 
% the right).
%
% For the upper staircase form the vector clD contains the lengths 
% of the columns of D, where we now count from the top to the bottom.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero'). The default value of the tolerance tol is 
% computed from the degree and sizes of A. If 'z' and tol are missing
% then the macro runs without "zeroing". THE USE OF ZEROING IS 
% STRONGLY RECOMMENDED!!!
%
% The argument 'menu' allows to select and control the next step of 
% the reduction.
%
% If the argument 'movie' is used then a 2-D or 3-D animation is
% generated that illustrates the reduction process.

% functions used: pinfo, punpck, ppck, pdegco, psel, pmul, pzero
%                pput, pscl, matplot, matplot3

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.0 $      $Date: 1997/04/16 15:06:05 $    $State: Exp $

function [D,U,V,UI,VI,rlD,step_plot] = pstairso(A,arg2,arg3,arg4,arg5,arg6,arg7)

menu1=0;, mov1=0;, test1=0;, tol=eps;, step_plot=[0 0 0];
method=0; zeroing=0;

if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'menu')
             menu1=1;
          elseif strcmp(argm,'movie')
             mov1=1;
          elseif strcmp(argm,'up')
             method=1;
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; end      
          elseif ~strcmp(argm,'low')
             test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1; ssttgg=[ssttgg,',tol'];
       elseif length(argm)==3
          step_plot=argm;
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: [D,U,V,UI,VI,rlD] = pstairso(A,''z'',tol,''menu'',''movie'') ');
   disp('    or [D,U,V,UI,VI,rlD] = pstairso(A,''low'',''z'',tol,''menu'',''movie'') ');
   disp('    or [D,U,V,UI,VI,clD] = pstairso(A,''up'',''z'',tol,''menu'',''movie'') ');
   disp('THE USE OF ZEROING IS STRONGLY RECOMMENDED !!! ');
   return
end

if method
   A=ptransp(A); step_plot(3)=1;
end
[typeA,rA,cA,degA]=pinfo(A);
U=eye(rA);  V=eye(cA); rlD=zeros(rA,1);
if isempty(A) | isinf(degA) | norm(punpck(A))<tol
   if strcmp(typeA,'poly'), U=ppck(U,0); V=ppck(V,0); end
   D=A;
   if method, D=ptransp(D); XXU=U; U=V; V=XXU; rlD=rlD'; end
   UI=U; VI=V;
   return
end
U=ppck(U,0); V=ppck(V,0); UI=U; VI=V;
if isnan(degA)
   degA=0;, A=ppck(A,degA);
end

if degA < 0
   D=A;
else
   D=ppck(A(1:rA,1:(1+degA)*cA),degA);      %'clearing'
end

[typeD,rD,cD,degD]=pinfo(D);
[DEGD,LCD]=pdegco(D,'ent');
if mov1 & step_plot(2)==0
   step_plot(2)=menu('Type of Graphic Object','2-Dimensional Object',...
           '3-Dimensional Object');
end
[menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
if step_plot(1)>10
   if method, D=ptransp(D); rlD=(rlD)'; end
   return
end
if isinf(degD)
   if strcmp(typeA,'cons')
      D=punpck(D); U=punpck(U); UI=U;
      V=punpck(V);, VI=V;
   end
   return
end
degofdet=degD*(min(rD,cD));
NormD=norm(punpck(D)); if NormD==0, NormD=1; end 
D=pscl(D,1/NormD); 
if zeroing==2
   tol=norm(punpck(D))*(max(size(punpck(D))))*eps*1e2;
elseif zeroing==1
   tol=tol/NormD;
end
loop=2*2*rD*(degD+1);
lu=0;
if cD > 1
   n=min(rD,cD);
   i=1; row=1;
   while (i<=n) & (row<=rD)
          while max(DEGD(row,i+1:cD))>=0 & (lu<loop)

             T=ppck(eye(cD),0);, TI=T;      % reduction to the right
             Min=min(abs(DEGD(row,i:cD)));
             K=find(DEGD(row,i:cD)==Min);
             lK=length(K);
             if lK >1
                LCDr=LCD(row,i:cA);
                Max=max(abs(LCDr(K)));
                 L=find(abs(LCDr(K))==Max);
                 k=K(L(1))+i-1;             % pivot
             else
                 k=K+i-1;
             end

             if k==i
                if isinf(DEGD(row,i))==0
                   ar=fliplr(punpck(psel(D,row,i)));
                   for j=i+1:cD
                      if isinf(DEGD(row,j))==0
                         br=fliplr(punpck(psel(D,row,j)));
                         [qr,rr]=deconv(br,ar);
                         if zeroing > 0
                            q=pzero(qr(length(qr):-1:1),tol);
                         else
                            q=qr(length(qr):-1:1);
                         end
                         T=pput(T,i,j,ppck(-q,length(q)-1));
                         TI=pput(TI,i,j,ppck(q,length(q)-1));
                      end
                   end

                end
             else
                TI=pput(T,[i,k],[i,k],[0,-1; 1,0]);
                T=pput(T,[i,k],[i,k],[0,1; -1,0]);
             end
             if zeroing > 0
                V=pmul(V,T,'z',tol); VI=pmul(TI,VI,'z',tol);
                D=pmul(D,T,'z',tol);
             else
                V=pmul(V,T); VI=pmul(TI,VI);
                D=pmul(D,T);             
             end
             [DEGD,LCD]=pdegco(D,'ent');
             if k==i
                frow=find(DEGD(row,i+1:cD)>=DEGD(row,i));
                if isempty(frow)==0
                   frow=frow+i*ones(1,length(frow));
                   for m=frow
                       nm=(DEGD(row,i)*cD+m):cD:(max(max(DEGD))+1)*cD;
                       D(row,nm)=zeros(1,length(nm));     
                   end
                   D=ppck(punpck(D),pdegco(D));
                   [DEGD,LCD]=pdegco(D,'ent');
                end
             end  %(if k==i)
             lu=lu+1;
             [menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
             if step_plot(1)>10
                if method, D=ptransp(D); UXV=ptransp(U); U=ptransp(V);
                           V=UXV; UXV=ptransp(UI); UI=ptransp(VI);
                           VI=UXV; rlD=(rlD)';
                end
                return
             end

          end  %(while)
          if isinf(DEGD(row,i))
             i=i-1;
          end
          i=i+1; row=row+1;
   end  %(while i<=n & row<=rD)
end  %(if cD>1)
if lu>=loop
   disp('pstairso warning: Triangularization interrupted.');
end
if zeroing > 0, D=pzero(D,tol); end
DEGD=pdegco(D,'ent');
D=pscl(D,NormD);
tol=tol*NormD;
Res=(norm(punpck(psub(D,pmul(A,V)))))/NormD;
if Res > tol*1e4
   disp(' ');
   disp(sprintf('pstairso warning: The relative residue of calculation is  %g',Res));
   disp('                  Try to change tolerance.');
else
   degdiaD=diag(DEGD);
   degdiaD=sum(degdiaD);
   if degdiaD > degofdet
      disp(' ');
      disp('pstairso warning: The resulting degree may not be correct! ');
      disp('                 Try to change the tolerance.');
   end
end
rowlength=zeros(rD,1);
for i=1:rD
    rowlength(i)=cD;
    for j=cD:-1:1
        if isinf(DEGD(i,j))
           rowlength(i)=rowlength(i)-1;
        else
           break;
        end
     end
end

[rlD,indrow]=sort(rowlength);
U=eye(rD); UI=U;
UI(indrow,:)=eye(rD);
U=UI';
D=pmul(U,D);
[menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
if step_plot(1)>10, return, end
if strcmp(typeA,'cons')
   [typeD,rD,cD,degD]=pinfo(D);
   [typeV,rV,cV,degV]=pinfo(V);
   [typeVI,rVI,cVI,degVI]=pinfo(VI);
   if degD <= 0, D=punpck(D);, end
   if degV <= 0, V=punpck(V);, end
   if degVI <= 0, VI=punpck(VI);, end
else
   U=ppck(U,0);, UI=ppck(UI,0);
end
if method, D=ptransp(D); UXV=ptransp(U); U=ptransp(V);
   V=UXV; UXV=ptransp(UI); UI=ptransp(VI);
   VI=UXV; rlD=(rlD)';
end
