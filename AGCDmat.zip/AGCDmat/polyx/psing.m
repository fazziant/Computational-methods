% psing
%
% test whether a polynomial matrix is singular
%
% The function
%
%   psing(A)
%   psing(A,tol)
%
% returns 1 if the polynomial matrix A is singular and 0 otherwise.
%
% The optional tolerance tol has the same meaning as for the standard 
% Matlab routine rank.

% Check singularity by substitution.
% Henrion D. 9-96
% $Revision: 1.5 $	$Date: 1996/10/15 09:40:48 $	$State: Exp $
% Modified by Henrion D. 4-97 : random numbers are chosen distinct
% Modified by S. Pejchova, June 28, 1997

function issingular = psing(A,tol)

if nargin < 1
 disp('usage:  psing(A[,tol])');
 return
end
[typeA, rA, cA, degA] = pinfo(A);

if (rA ~= cA),

  error('psing: The input matrix must be square.');

elseif isinf(degA),

  % zero matrix is singular
  issingular = 1;

elseif isempty(A)

  % empty matrix is not singular
  issingular = 0;

elseif (typeA == 'cons') | (degA == 0),

  % constant matrix
  A = punpck(A);
  if nargin == 1,
    if norm(A) > eps,
      tol = rA*norm(A)*eps;
    else
      issingular = 1; return;
    end;
  end;
  issingular = (min(svd(A)) < tol);

else % polynomial matrix

  i = 0; issingular = 1;
  % maximal number of values to be substituted to avoid zeroes
  imax = rA*degA+1;
  % already selected values to be compared
  oldv = ones(imax,1)*Inf;

  while (i < imax) & issingular,
    i = i+1;
    v = randn;
    % ensure that this value has not been selected previously
    while any(abs(oldv - v) < 1e-3),
      v = randn;
    end;
    oldv(i) = v;
    P = pval(A,v);
    if nargin == 1,
      tol = rA*norm(P)*eps; % default tolerance
    end;
    issingular = (min(svd(P)) < tol);
  end;

end;


