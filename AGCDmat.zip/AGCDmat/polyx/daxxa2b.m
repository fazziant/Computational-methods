%daxxa2b
%
% The function
%
%     X = daxxa2b(A,B[,algorithm][,tol][,flag])
%
% solves the discrete-time symmetric polynomial matrix equation
%
%    A'(1/d)X(d) + X'(1/d)A(d) = Bl(1/d) + Br(d)
%
% where A is a given square polynomial matrix. B is a given 
% "two-sided" para-Hermitian polynomial matrix such that 
% B(d)/d^(degB/2) = Bl(1/d) + Br(d) and Bl'(d) = Br(d).
%
% The parameter algorithm allows to specify the algorithm that is 
% used:
%
% 'res' (default value): resolution of the linear system 
%      corresponding to the reduced resultant matrix formulation. 
%      The degree of X is then expected to be max(degA, degB/2).
% 'euc': resolution by the Euclidean division algorithm, provided 
%      that A is Schur and A'(1/d)^(-1)B(d)A^-1(d) is biproper. 
%      The solution is such that X(d)A^-1(d) is proper.
%
% The optional parameter tol is the tolerance value used to decide 
% whether a solution exists. It has the default value 1e-7.
%
% If flag is set to 'v' then comments are printed during the 
% execution of the function.
%
% The solution is such that X(0) is upper-triangular.
%
% If no solution exists that satisfies the assumptions then X = [].

% Henrion D. May 96
% $Revision: 1.1 $	$Date: 1996/10/07 09:00:55 $	$State: Exp $
% Modified by Henrion D. May 97
% - resultant method also in the scalar case
% - flag 't' and parameter 'tol' added

function X = daxxa2b(A,B,p1,p2,p3)

zeroing = 1; % zeroing always enabled

if (nargin < 2)
  error('usage: X = daxxa2b(A,B[,algorithm][,tol][,flag])');
end;

% input matrices A and B

[typeA,n,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);

if (n ~= cA) | (rB ~= cB),
  error('input matrices must be square');
elseif (n ~= rB),
  error('input matrices must have the same size');
elseif (typeA == 'cons'),
  A = ppck(A, 0); degA = 0;
end;
if psing(A),
  error('first input matrix is singular to working precision');
end;
if (typeB == 'cons'),
  B = ppck(B, 0); degB = 0;
end;

% if B is zero, so is X
if norm(punpck(B)) < eps,
  X = ppck(zeros(n), 0);
  return;
end;

% default input arguments
algorithm = 'res';
verbose = 0;
tol = 1e-7;

% parse input arguments
is_algorithm = 0; is_verbose = 0; is_tol = 0;
for i = 1:nargin-2
 param = eval(['p' int2str(i)]);
 invalid = 0;
 if isstr(param),
  if (strcmp(param, 'euc') | strcmp(param, 'res')) & ~is_algorithm,
   algorithm = param; is_algorithm = 1;
  elseif strcmp(param, 'v') & ~verbose,
   verbose = 1; is_verbose = 1;
  else
   invalid = 1;
  end;
 elseif ~is_tol,
  tol = param; is_tol = 1;
 else
  invalid = 1;
 end;
 if invalid,
  error(['invalid input argument #' num2str(i+2)]);
 end;
end;

if n == 1,
 % -------------------------------------------------------------------------
 % A and B are scalar polynomials
 % -------------------------------------------------------------------------

 % lowercase variable names
 a = A; b = B;
 typea = typeA; typeb = typeB;
 ra = n; ca = cA; rb = rB; cb = cB;
 dega = degA; degb = degB;

 % The degree of b(d) must be even since it is para-Hermitian.
 % However, if may be odd if b(0) = 0.
 % For instance if bl(1/d)+br(d) = 1/d-2+d then
 % b(d) = d-2*d^2+d^3 has odd degree.
 if rem(degb,2),
   if abs(b(1,1)) > eps,
      error('second input argument is not para-Hermitian');
   else
      b = b(1,2:degb+1);
      degbl = (degb-1)/2;
      degB = degB + 1;
    end;
  else
    degbl = degb/2;
    b = b(1,1:2*degbl+1);
  end;

 if strcmp(algorithm, 'euc'),

  % --------------------------------
  % EUCLIDEAN ALGORITHM (SCALAR CASE)
  % --------------------------------

  % construction of bl(d) = br(d)
  br = [b(degbl+1)/2 b(degbl+2:2*degbl+1)];
  bl = [b(degbl+1)/2 b(degbl:-1:1)];
  if (abs(br-bl) > eps),
    error('second input argument is not para-Hermitian');
  end;
  degx = max([dega degbl]);
  a = [punpck(a) zeros(1,degx-dega)];

  % forward construction of coefficients
  backward = []; nit = 0;
  while (dega > 0) | (degbl > 0),
    nit = nit + 1;
    if abs(a(1)) < eps,
      error(['with Euclidean algorithm, first input argument ' ...
             'must be strictly stable']);
    end;
    if degbl > dega,
      coef = bl(degbl+1)/a(1);
      for i = 1:degbl,
        bl(i) = bl(i) - coef*a(degbl+2-i);
      end;
      bl(degbl+1) = 0;
      backward = [backward; 1 coef degbl];
      degbl = degbl - 1;
    else % degbl <= dega
      coef = a(dega+1)/a(1);
      for i = 1:dega,
        an(i) = a(i) - coef*a(dega+2-i);
      end;
      a = [an(1:dega) 0];
      backward = [backward; 3 coef dega];
      dega = dega - 1;
    end;
  end %  while

  % backward substitutions
  x = zeros(1,degx+1); xn = x;
  x(1) = bl(1)/a(1);
  for i = nit:-1:1,
    type = backward(i,1);
    coef = backward(i,2);
    deg = backward(i,3);
    if type == 1,
      x(deg+1) = x(deg+1) + coef;
    else % type == 3
      for j = 1:deg+1,
        xn(j) = x(j) - coef*x(deg+2-j);
      end;
      x = xn;
    end; % if type
  end; % for i

  X = ppck(x, degx);

 else % if algorithm

  % ----------------------------------
  % RESULTANT ALGORITHM (SCALAR CASE)
  % ----------------------------------

  degx = max(dega, degbl);

  % right hand side matrix
  Bs = [zeros(degx-degbl,1); b(1:degbl+1)'];

  % reduced resultant matrix
  Q1 = punpck(dcjg(a))'; Q2 = punpck(a)';
  T = zeros(2*degx+1,degx+1);
  for i = 0:degx,
   T(1+degx-dega+i:degx+i+1,1+i) = Q1;
   T(1+degx-i:degx+dega+1-i,1+i) = T(1+degx-i:degx+dega+1-i,1+i) + Q2;
  end;
  T = T(1:degx+1,:); % reduction
  
  condT = cond(T);
  if (condT > 1e8) & verbose,
    disp('WARNING ! Reduced resultant matrix is ill conditioned');
    disp(['2-norm condition number = ' num2str(condT)]);
  end;

  if rank([T Bs], tol) ~= size(T, 1),
    x = pinv(T) * Bs; % solution in the least-square sense
    % check
    residue = norm(T*x-Bs)
    if (residue > tol) & verbose,
       disp('WARNING ! When solving linear system, ');
       disp(['residue (' num2str(residue) ...
             ') is greater than tolerance (' num2str(tol) ')']);
    end;
  else
    x = T \ Bs; % Gaussian elimination
  end;

  X = ppck(x', degx);

 end; % algorithm

else % scalar or polynomial ?

 % -------------------------------------------------------------------------
 % A and B are polynomial matrices
 % -------------------------------------------------------------------------

 if norm(punpck(pzero(psub(B,dcjg(B))))) > eps,
   error('second input matrix is not para-Hermitian');
 end;

 % permutation matrix for Kronecker product
 n2 = n^2;
 P = zeros(n2);
 for i = 1:n, for j = i:n,
  k = i+(j-1)*n; l = j+(i-1)*n;
  P(k, l) = 1; P(l, k) = 1;
 end; end;

 if (algorithm == 'euc'),

  % ----------------------------
  % ADJOINT + EUCLIDEAN DIVISION
  % ----------------------------

  % transformation into a set of polynomial equations
  if zeroing, 
    detA = pdet(A,'z'); [detAcjg, degdetA] = dcjg(detA);
    T = pzero(adj(A, detA)); [Tcjg, degT] = dcjg(T);
    B2 = pmul(Tcjg, B, T, 'z'); degB2 = 2*degT + degB;
  else
    detA = pdet(A); [detAcjg, degdetA] = dcjg(detA);
    T = adj(A, detA); [Tcjg, degT] = dcjg(T);
    B2 = pmul(Tcjg, B, T); degB2 = 2*degT + degB;
  end;

  % resolution of (n+1)n/2 scalar polynomial equations
  % of the form a* x + y* a = bl + br
  degX2 = max(degA, degB2/2); % maximal possible degree
  X2 = ppck(ones(n, n*(degX2+1)), degX2);
  % diagonal terms
  for i = 1:n,
    xii = daxxa2b(detA, psel(B2, i, i));
    X2 = pput(X2, i, i, xii);
  end;
  % n(n-1) other terms
  if (n > 1),
    for i = 1:n-1,
      for j = i+1:n,
        [xij xji] = daxya2b(detA, psel(B2, i, j), degB2/2);
        X2 = pput(X2, i, j, xij);
        X2 = pput(X2, j, i, xji);
      end;
    end;
  end; % if n

  if zeroing,
    X2 = pzero(X2);
  end;

  if verbose, % compute A(1/d)X(d)+X(1/d)A(d)-B(d)
    % discrete-time multiplication with conjugates :
    % respective degrees must be taken in account
    [X2cjg, degX2] = dcjg(X2);
    m = max([degdetA degX2 degB2/2]);
    p1 = pshift(pmul(detAcjg, X2), m - degdetA);
    p2 = pshift(pmul(X2cjg, detA), m - degX2);
    p3 = pscl(pshift(B2, m - degB2/2), -1);
    residue = norm(punpck(pzero(padd(p1, p2, p3))));
    if residue > tol,
      disp('WARNING ! X'' is not solution :');
      disp(['residue = ' num2str(residue)]);
    end;
  end;

  % recovering of X
  X = xab(T, X2);
  if zeroing,
    X = pzero(X);
  end;

  if verbose,
    [Acjg, degA] = dcjg(A);
    [Xcjg, degX] = dcjg(X);
    m = max([degA degX degB/2]);
    p1 = pshift(pmul(Acjg, X), m - degA);
    p2 = pshift(pmul(Xcjg, A), m - degX);
    p3 = pscl(pshift(B, m - degB/2), -1);
    residue = norm(punpck(pzero(padd(p1, p2, p3))));
    if residue > tol,
      disp('WARNING ! X is not a particular solution :');
      disp(['residue = ' num2str(residue)]);
    end;
  end;

  degX = pdegco(pzero(X));

  % absolute coefficient to be transformed to upper triangular form
  PA = pdegco(A, 0);
  PX = pdegco(X, 0);

  % construction of Q such that strictly lower part of Q PA + PX is 0 :
  % resolution of a LSE of order (n-1)n/2 

  ind = [];
  for i = 1:n-1,
    ind = [ind 1+i+(i-1)*n:i*n]; % indices of lower triangular entries
  end;
  M = kron(PA',eye(n)) * (eye(n2) - P);
  M = M(ind, ind); % reduced Kronecker product
  y = -PX(:); y = y(ind); % reduced right handside -vecPX

  if norm(y) > eps, % if lower triangular entries are not zero

    if rank([M y], tol) ~= size(M, 1),
      x = pinv(M) * y; % least-square solution
      residue = norm(M*x - y);
      if verbose & (residue > tol),
        disp('WARNING ! Problem when computing Q.');
        disp('X can''t be in correct form :');
        disp(['residue ' num2str(residue)]);
      end;
    else
      x = M \ y; % Gaussian elimination
    end;

    R = zeros(n2, 1); R(ind) = x;
    Q = zeros(n); Q(:) = R; Q = Q - Q'; % construction of skew-symmetric Q
    if zeroing,
      X = padd(X, pmul(Q, A, 'z'), 'z');
    else
      X = padd(X, pmul(Q, A));
    end;

  end; % if norm

 elseif strcmp(algorithm, 'res'),

  % ----------------------------------
  % RESULTANT ALGORITHM
  % ----------------------------------

  % reduced permutation indices
  inde = []; indo = [];
  for i = 1:n, for j = 1:n,
    k = i+(j-1)*n; l = j+(i-1)*n;
    if k >= l,
      if k > l,
        indo = [indo l];
      end;
      inde = [inde l];
    end;
  end; end;
  % suppression of linearly dependent rows
  Pe = (eye(n2) + P) / 2; Pe = Pe(inde, :);

  degBr = degB/2;
  degX = max(degA, degBr);

  % right hand side matrix
  V = zeros(n2,1); Bs = [];
  for i = degX:-1:1,
    if i <= degBr,
      V(:) = pdegco(B,degBr-i);
    end;
    Bs = [Bs;V];
  end;
  V(:) = pdegco(B,degBr);
  Bs = [Bs; Pe*V];

  % reduced resultant matrix
  Q1 = punpck(ptransp(pkron(eye(n),dcjg(A))))';
  Q2 = punpck(pmul(pkron(eye(n),A),P))';
  T = zeros((2*degX+1)*n2,(degX+1)*n2);
  for i = 0:degX,
   T(1+(degX-degA+i)*n2:(degX+i+1)*n2,1+i*n2:(i+1)*n2) = Q1;
   T(1+(degX-i)*n2:(degX+degA+1-i)*n2,1+i*n2:(i+1)*n2) = ...
      T(1+(degX-i)*n2:(degX+degA+1-i)*n2,1+i*n2:(i+1)*n2) + Q2;
  end;
  T = [T(1:degX*n2,:); Pe*T(1+degX*n2:(degX+1)*n2,:)];
  
  % n(n-1)/2 additional constraints to force X(degX) triangular
  Td = zeros(n*(n-1)/2, (degX+1)*n2);
  for i = 1:n*(n-1)/2,
    Td(i, indo(i)) = 1;
  end;
  T = [T;Td]; Bs = [Bs; zeros(n*(n-1)/2,1)];

  % LSE resolution
  X = zeros(n, n*(degX+1));
  condT = cond(T);
  if (condT > 1e8) & verbose,
    disp('WARNING ! Reduced resultant matrix is ill conditioned');
    disp(['2-norm condition number = ' num2str(condT)]);
  end;

  if rank([T Bs], tol) ~= size(T, 1),
    sol = pinv(T) * Bs; % solution in the least-square sense
    residue = norm(T*sol-Bs);
    % check
    if (residue > tol) & verbose,
       disp('WARNING ! When solving linear system,');
       disp(['residue (' num2str(residue) ...
	     ') is greater than tolerance (' num2str(tol) ')']);
    end;
  else
    sol = T \ Bs; % Gaussian elimination
  end;

  X(:) = sol;
  X = ppck(X, degX);

 else,

  error('invalid algorithm');

 end; % if algorithm
 
end; % if n == 1

if zeroing,
 X = pzero(X);
end;

% final check

[Acjg, degA] = dcjg(A);
[Xcjg, degX] = dcjg(X); 
m = max([degA degX degB/2]);
p1 = pshift(pmul(Acjg, X), m - degA);
p2 = pshift(pmul(Xcjg, A), m - degX);
p3 = pscl(pshift(B, m - degB/2), -1);
residue = norm(punpck(pzero(padd(p1, p2, p3))));
if residue > tol,
   if verbose,
     disp('No solution :');
     disp(['residue (' num2str(residue) ...
	   ') is greater than tolerance (' num2str(tol) ')']);
   end;
   X = [];
end;




