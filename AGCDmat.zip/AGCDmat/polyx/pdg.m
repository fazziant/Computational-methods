%pdg
%
% Diagonalization of a polynomial matrix
%
% The commands
%
%    [D,U,V,UI,VI] = pdg(A)
%    [D,U,V,UI,VI] = pdg(A[,'z'][,tol][,'menu'][,'movie'])
%
% convert the polynomial matrix A to a diagonal matrix D by 
% elementary operations so that U*A*V = D. U and V are unimodular 
% transformation matrices. The inverse matrices UI = U^(-1) and 
% VI = V^(-1) are also computed.
%
% The optional input arguments 'z' and tol are used in "zeroing" 
% (see the function 'pzero'). The default value of tol is computed 
% from the degree and sizes of A. If 'z' and tol are missing then
% the macro runs without "zeroing". THE USE OF ZEROING IS STRONGLY 
% RECOMMENDED !!!
%
% The optional argument 'menu' allows to select and control the next
% step of the reduction.
%
% If the argument 'movie' is used then a 2-D or 3-D animation is
% generated that illustrates the reduction process.

% function used: pinfo, punpck, ppck, pdegco, pmul, pput,
%                psel, pzero, pscl, matplot, matplot3

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.2 $      $Date: 1997/01/21 16:13:22 $    $State: Exp $

function [D,U,V,UI,VI] = pdg(A,arg2,arg3,arg4,arg5)

menu1=0;, mov1=0;, test1=0;, tol=eps;, step_plot=[0 0 0];
zeroing=0;
if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'menu')
             menu1=1;
          elseif strcmp(argm,'movie')
             mov1=1;
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; end
          else
             test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1;
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: [D,U,V,UI,VI] = pdg(A,''z'',tol,''menu'',''movie'') ');
   disp('THE USE OF ZEROING IS STRONGLY RECOMMENDED!!!');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if isempty(A) | isinf(degA)
   D=A;
   U=ppck(eye(rA),0);, UI=U;
   V=ppck(eye(cA),0);, VI=V;
   return
end
if isnan(degA)
   degA=0;, A=ppck(A,degA);
end

U=ppck(eye(rA),0);, UI=U;
V=ppck(eye(cA),0);, VI=V;
if degA < 0
   D=A;, degD=degA;
else
   D=ppck(A(1:rA,1:(1+degA)*cA),degA);      %'clearing'
end
[typeD,rD,cD,degD]=pinfo(D);

if mov1
   step_plot(2)=menu('Type of Graphic Object','2-Dimensional Object',...
           '3-Dimensional Object');
end
[menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
if step_plot(1)>10, return, end

if isinf(degD)
   if strcmp(typeA,'cons')
      D=punpck(D);, U=punpck(U);, UI=punpck(UI);
      V=punpck(V);, VI=punpck(VI);
   end
   return
end
degofdet=degD*(min(rD,cD));
NormD=norm(punpck(D));
D=pscl(D,1/NormD);
if zeroing==2
   tol=norm(punpck(D))*(max(size(punpck(D))))*eps*1e2;
elseif zeroing==1
   tol=tol/NormD;
end

loop=2*2*rD*(degD+1);
lu=0;
n=min(rD,cD);

if n >= 1
   [DEGD,LCD]=pdegco(D,'ent');
   for i=1:n                                % reduction of i-row and i-column
          xcol=0;, xrow=0;
          if cD>i & (max(DEGD(i,i+1:cD))>=0)
             xcol=1;
          end
          if rD>i & (max(DEGD(i+1:rD,i))>=0)
             xrow=1;
          end

          while (xcol | xrow) & (lu<loop)
             TU=ppck(eye(rD),0);, TUI=TU;   % reduction to down
             TV=ppck(eye(cD),0);, TVI=TV;   % reduction to the right
             Min=min(min(abs(DEGD(i:rD,i:cD))));
             [I,J]=find(DEGD(i:rD,i:cD)==Min);
             if length(I) >1
                LCDmat=LCD(i:rD,i:cD);
                LCDv=LCDmat(I(1),J(1));
                for t=2:length(I), LCDv=[LCDv,LCDmat(I(t),J(t))];, end
                [M,l]=max(abs(LCDv));
                ki=I(l(1))+i-1;             % pivot
                kj=J(l(1))+i-1;
             else
                ki=I+i-1;
                kj=J+i-1;
             end
             if (ki==i) & (kj==i)
                if isinf(DEGD(i,i))==0
                   ar=fliplr(punpck(psel(D,i,i)));
                   if rD > i
                      for row=i+1:rD
                          if isinf(DEGD(row,i))==0
                             br=fliplr(punpck(psel(D,row,i)));
                             [qr,rr]=deconv(br,ar);
                             if zeroing > 0
                                q=pzero(qr(length(qr):-1:1),tol);
                             else
                                q=qr(length(qr):-1:1);
                             end
                             TU=pput(TU,row,i,ppck(-q,length(q)-1));
                             TUI=pput(TUI,row,i,ppck(q,length(q)-1));
                          end
                      end
                   end
                   if cD > i
                      for col=i+1:cD
                          if isinf(DEGD(i,col))==0
                             cr=fliplr(punpck(psel(D,i,col)));
                             [sr,rr]=deconv(cr,ar);
                             if zeroing > 0
                                s=pzero(sr(length(sr):-1:1),tol);
                             else
                                s=sr(length(sr):-1:1);
                             end
                             TV=pput(TV,i,col,ppck(-s,length(s)-1));
                             TVI=pput(TVI,i,col,ppck(s,length(s)-1));
                          end
                      end
                   end
                end
             
             else
                if ki~=i
                   TUI=pput(TU,[ki,i],[ki,i],[0,-1; 1,0]);
                   TU=pput(TU,[ki,i],[ki,i],[0,1; -1,0]);
                end
                if kj~=i
                   TVI=pput(TV,[i,kj],[i,kj],[0,-1; 1,0]);
                   TV=pput(TV,[i,kj],[i,kj],[0,1; -1,0]);
                end

             end
             if zeroing > 0
                U=pmul(TU,U,'z',tol); V=pmul(V,TV,'z',tol);
                UI=pmul(UI,TUI,'z',tol); VI=pmul(TVI,VI,'z',tol);
                D=pmul(TU,D,TV,'z',tol);
             else
                U=pmul(TU,U); V=pmul(V,TV);
                UI=pmul(UI,TUI); VI=pmul(TVI,VI);             
                D=pmul(TU,D,TV);
             end
             [DEGD,LCD]=pdegco(D,'ent');
             if (ki==i) & (kj==i)
                degD=pdegco(D);
                if cD>i
                   frow=find(DEGD(i,i+1:cD)>=DEGD(i,i));
                   if isempty(frow)==0
                      frow=frow+i*ones(1,length(frow));
                      for m=frow
                          mm=(DEGD(i,i)*cD+m):cD:(degD+1)*cD;
                          D(i,mm)=zeros(1,length(mm));
                      end
                   end
                end
                if rD>i
                   fcol=find(DEGD(i+1:rD,i)>=DEGD(i,i));
                   if isempty(fcol)==0
                      nn=(DEGD(i,i)*cD+i):cD:(degD*cD+i);
                      D(i+1:rD,nn)=zeros(rD-i,length(nn));
                   end
                end
                D=ppck(punpck(D),degD);
                [DEGD,LCD]=pdegco(D,'ent');
             end  %(if k==i)
             lu=lu+1;

             if rD>i &(max(DEGD(i+1:rD,i))>=0)
                xrow=1;
             else
                xrow=0;
             end
             if cD>i & (max(DEGD(i,i+1:cD))>=0)
                xcol=1;
             else
                xcol=0;
             end
             [menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,D);
             if step_plot(1)>10, return, end
         end  %(while lu<loop)
   end  %(for i=1:n)
end  %(if n>1)
if lu>=loop
   disp('pdg warning: Diagonalization interrupted.');
end
if zeroing > 0, D=pzero(D,tol); end
DEGD=pdegco(D,'ent');
D=pscl(D,NormD);
Res=(norm(punpck(psub(D,pmul(U,A,V)))))/NormD;
if Res > tol*1e6
   disp(' ');
   disp(sprintf('pdg warning: The relative residue of calculation is  %g',Res));
   disp('             Try to change the tolerance.');
else
   degdiaD=diag(DEGD);
   degdiaD=sum(degdiaD);
   if degdiaD > degofdet
      disp(' ');
      disp('pdg warning: The resulting degree may not be correct!');
      disp('             Try to change the tolerance.');
   end
end
if strcmp(typeA,'cons')
   [typeD,rD,cD,degD]=pinfo(D);
   [typeU,rU,cU,degU]=pinfo(U);
   [typeUI,rUI,cUI,degUI]=pinfo(UI);
   [typeV,rV,cV,degV]=pinfo(V);
   [typeVI,rVI,cVI,degVI]=pinfo(VI);
   if degD <= 0, D=punpck(D);, end
   if degU <= 0, U=punpck(U);, end
   if degUI <= 0, UI=punpck(UI);, end
   if degV <= 0, V=punpck(V);, end
   if degVI <= 0, VI=punpck(VI);, end
end
