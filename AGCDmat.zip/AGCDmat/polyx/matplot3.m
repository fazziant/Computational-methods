%matplot3
%
% The command
%
%   f = matplot3(A)
%
% creates a 3-D graphics object from the polynomial matrix A.
% The height of each bar corresponds to the degree of the
% corresponding entry of A.

% function used: pinfo, pdegco

% S. Pejchova, 1997
% $Revision: 1.1 $      $Date: 1997/06/28 12:33:00 $    $State: Exp $

function f = matplot3(A)

if nargin~=1
   disp('usage: f = matplot3(A) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if isempty(A)
   disp('matplot3: Input matrix is empty ');
   return
end
%if isnan(degA), degA=0;, end
if isnan(degA)|isinf(degA), degA=0;, end
[DEGA,LCA]=pdegco(A,'ent');
Xo=[cA-1:-1:0; cA-1:-1:0; cA:-1:1; cA:-1:1];
Yo=[zeros(1,cA); ones(2,cA); zeros(1,cA)];
X=Xo;, Y=Yo;
if rA > 1
   for i=1:rA-1
       X=[X, Xo];
       Y=[Y, i*ones(4,cA)+Yo];
   end
end

Zau=(fliplr(DEGA))';, Zo=(Zau(:))';
I=isinf(Zo);

Z=[Zo ; Zo ; Zo ; Zo];

Cau=abs(LCA);
Cm=max(max(Cau));
Cau=(fliplr(Cau))';, Co=(Cau(:))';
if Cm~=0, Cr=Co/Cm; else, Cr=Co; end
C=[Cr ; Cr ; Cr ; Cr];
if isempty(I)==0
   Zo(:,I)=[];
   Z(:,I)=[];
   C(:,I)=[];
   X(:,I)=[];
   Y(:,I)=[];
end
if isempty(X)==0
   X1=X(1,:);, X3=X(3,:);
   Y1=Y(1,:);,  Y2=Y(2,:);
   XLL=[X1; X1; X1; X1];
   YLL=[Y1; Y2; Y2; Y1];
   XRR=[X1; X3; X3; X1];
   YRR=[Y2; Y2; Y2; Y2];

   ZLL=[zeros(2,length(Zo)); Zo; Zo];
end
clf;
axes('position',[.1 .1 .8 .1]);
if Cm > 10
   x=[0:0.1*Cm:Cm; 0:0.1*Cm:Cm];
   y=[zeros(1,11); 0.2*ones(1,11)];
   Cc=[0:0.1:1; 0:0.1:1];
else
   x=[0:Cm+1; 0:Cm+1];
   y=[zeros(1,Cm+2); 0.2*ones(1,Cm+2)];
   if Cm~=0
      Cc=[0:(1/Cm):1, 1; 0:(1/Cm):1, 1];
   else
      Cc=zeros(2);
   end
end
axis('off');
pcolor(x,y,Cc);

xlabel('Absolute value of leading coefficients');
colormap(cool);
axes('position',[.1 .3 .8 .7]);
axis('on');
if isempty(X)==0
   fill3([XLL(:,1),XRR(:,1),X(:,1)], [YLL(:,1),YRR(:,1),Y(:,1)],...
          [ZLL(:,1),ZLL(:,1),Z(:,1)], [C(:,1),C(:,1),C(:,1)]);
end
Xr=[1:cA, zeros(1,rA); 1:cA, cA*ones(1,rA)];
Yr=[zeros(1,cA), 0:rA-1; rA*ones(1,cA), 0:rA-1];
Zr=zeros(size(Xr));
plot3(Xr,Yr,Zr,'w-');
axis('ij');
view(-20, 75);
axis([0 cA+1 0 rA  0  max(1,degA)]);
axis(axis);

hold on;
if isempty(X)==0
  for k=1:length(Zo)
    fill3([XLL(:,k),XRR(:,k),X(:,k)], [YLL(:,k),YRR(:,k),Y(:,k)],...
          [ZLL(:,k),ZLL(:,k),Z(:,k)], [C(:,k),C(:,k),C(:,k)]);
  end
end
ylabel('ROWS');
xlabel('COLUMNS');
zlabel('DEGREES');
hold off
