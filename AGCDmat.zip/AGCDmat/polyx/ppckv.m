%ppckv
%
% Pack a constant matrix in polynomial toolbox format
% with possibility to specify various formats
%
% The command
% 
%    P = ppckv(A,degA [,'r'])
% 
% constructs the polynomial matrix P by extending the matrix A with
% an extra row and column and placing the polynomial marker NaN and 
% the degree degA in the proper places.
%
% The option 'r' specifies reversed order of the coefficients. 

% $Revision: 1.3 $	$Date: 1996/07/19 09:20:21 $	$State: Exp $

function P = ppckv(A,degA,opt);

if nargin < 2
   disp('usage: P = ppckv(A,degA [,[r]])')
   return
end

[typeA,rA,cA,dummy] = pinfo(A);
if typeA == 'empt'
   P = A;
   return
end
if degA == -Inf
   normA = norm(A,inf);
   if normA ~= 0
      error('ppckv: The matrix is not full of zeros and the degree is -Inf');
   end
   temp = cA + 1;
   degpA = -Inf;
else

% Check consistency of degA
   if floor(degA) ~= ceil(degA) | degA < 0
      error('ppckv: The degree of the polynomial matrix not a nonnegative integer');
   elseif  rem(cA,degA+1) 
      error('ppckv: The degree of the matrix is inconsistent with the number of columns');
   end
   cpA = cA / (degA + 1);
   degpA = degA;
   while degpA >= 0
      if norm(A(:,degpA*cpA+1:(degpA+1)*cpA),inf) == 0
         degpA = degpA - 1;
      else
         break
      end
   end
   if degpA >= 0
      temp = cpA*(degpA+1)+1;
   else
      temp = cpA + 1;
      degpA = -Inf;
   end
end

if (nargin == 3) & (opt == 'r')
  % reverse the order of the coefficients
  Arev  = zeros(size(A(:,1:temp-1)));
  point = temp-1;
  cpA   = point/(degpA+1);
  for i = 1:degpA+1
    Arev(:,(i-1)*cpA+1:i*cpA) = A(:,point-cpA+1:point);
    point = point - cpA;
  end
  P = [ Arev zeros(rA,1) ; zeros(1,temp)];
  P(1,temp) = degpA;
  P(rA+1,temp) = NaN;
else  
  P = [ A(:,1:temp-1) zeros(rA,1) ; zeros(1,temp)];
  P(1,temp) = degpA;
  P(rA+1,temp) = NaN;
end

