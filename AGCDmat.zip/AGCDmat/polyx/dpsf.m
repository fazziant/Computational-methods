% dpsf
%
% The function
%
%     A = dpsf(B[,algorithm[,verbose]])
%
% solves the discrete-time matrix spectral factorization problem.
%
% Given an n-by-n real "two-sided" diagonally reduced matrix 
%
%     Bd(d) = Bl(1/d) + Br(d) 
%
% satisfying 
%
%     Bl'(d) = Br(d)	                        (symmetry)
%     Bd(exp(sqrt(-1)*w)) > 0 for all real w    (positiveness)
%
% the function returns an n-by-n real polynomial matrix A(d) such that
%
%     Bd(d) = A'(1/d)A(d)
%     detA(d) ~=0, |d|<=1     (stability).
%
% Bd(d) depends on 1/d and d, and is given by
%
%     Bd(d) = B(d)/d^{degB/2)
%
% where degB is the degree of B(d), the input polynomial matrix.
%
% The solution has its absolute coefficient matrix A(0) upper 
% triangular with positive diagonal entries.
%
% The parameter 'algorithm' allow to specify the algorithm used in
% function daxxa2b that is called by the macro. Its default value 
% is 'res'.
%
% If the parameter 'verbose' is present and non-zero then some tests
% are made and some information is printed.

% Henrion D. 5-96
% $Revision: 1.1 $	$Date: 1996/10/07 09:09:09 $	$State: Exp $

function A = dpsf(B,algorithm,verbose)

if (nargin < 1),
  disp('usage: A = psf(B[,algorithm[,verbose]])');
  return;
end;
if (nargin < 2),
  algorithm = 'res'; verbose = 0;
elseif (nargin < 3),
  verbose = 0;
end;

[typeB, n, cB, degB] = pinfo(B);
if (typeB == 'empt'),
  A = [];
  return;
elseif (n ~= cB),
  error('dpsf: The input matrix must be square.');
elseif (typeB == 'cons'),
  if min(svd(B)) < eps,
    error('dpsf: The input matrix is singular to working precision');
  else
    A = chol(B)';
    return;
  end;
elseif psing(B),
  error('dpsf: The input is singular to working precision');
elseif finite(pdegco(pzero(psub(dcjg(B),B)))) | (rem(degB, 2)),
  error('dpsf: The input matrix must be para-Hermitian');
end;

% initial matrix A0

Bs0 = pdegco(B, degB/2); % absolute coefficient matrix
if min(eig(Bs0)) < eps,
  error('dpsf: The input matrix must verify the condition of positiveness');
end;
newA = ppck(chol(Bs0), 0);

% Newton recursion

if verbose,
  format compact;
end;

stop = 0; it = 0;
while ~stop,

  it = it + 1;
  A = newA;
  up = pmax(psub(pmul(dcjg(A),A),B));
  stop = (up < eps*1e10);

  if verbose,
    disp(['dpsf: iteration #' int2str(it) ...
          ' error max(A*A-B) =' num2str(up)]);
  end;

  if ~stop,
    if verbose,
      X = daxxa2b(A, pscl(B,2), algorithm, 'v');
    else
      X = daxxa2b(A, pscl(B,2), algorithm);
    end;
    newA = pzero(pscl(padd(A, X), .5));
    stop = 2*pschur(newA);
  end;

end;

if verbose,
  if stop == 2,
    disp('dpsf: Last factor not stable');
  end;
  format;
end;

A = pzero(A);


