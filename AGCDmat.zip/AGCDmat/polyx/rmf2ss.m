% rmf2ss
%
% Observer-form realization from right matrix fraction description.
%
% Given two polynomial matrices Ne and De such that
%
%    De(s) is column reduced 
%    H(s) = Ne(s)*inv(De(s)) is proper
%
% the function
%
%    [A,B,C,D] = rmf2ss(Ne,De[,tol])
%
% returns the observer-form realization (A,B,C,D) of 
% H(s) = Ne(s)*inv(De(s)):
%
%    H(s) = D + C*inv(sI-A)*B.
%
% If Ne(s) and De(s) are right coprime then the realization is minimal.
% The tolerance tol (with default value eps) is used in testing whether
% De is column reduced.

% Henrion D. 6-96
% $Revision: 1.1 $	$Date: 1996/10/07 14:22:25 $	$State: Exp $
% Modified by Henrion D. May 22, 1997
% - tolerance added
% - statement about minimality corrected
% Modified by S. Pejchova, June 28, 1997

% From T. Kailath "Linear Systems" Prentice-Hall 1980, pp. 406-407

function [A,B,C,D] = rmf2ss(Ne,De,tol)

if nargin < 2
 disp('usage:  [A,B,C,D] = rmf2ss(Ne,De[,tol])');
 return
end

[typeNe, rNe, cNe, dNe] = pinfo(Ne);
[typeDe, rDe, cDe, dDe] = pinfo(De);
if isempty(Ne) | isempty(De)
  A=[]; B=[]; C=[]; D=[];
  return
end

if (cNe ~= rDe) | (rDe ~= cDe),
  error('input matrices have inconsistent sizes');
elseif nargin > 2
  if max(size(tol)) > 1,
    error('third argument must be scalar');
  end;
else
  tol = eps; % default tolerance
end;

dcolNe = pdegco(Ne, 'col');
[dcolDe, colDe] = pdegco(De, 'col'); % controllability indices
ifdcolNe = isinf(dcolNe); dcolNe(ifdcolNe) = zeros(1,sum(ifdcolNe));
ifdcolDe = isinf(dcolDe); dcolDe(ifdcolDe) = zeros(1,sum(ifdcolDe));

if min(svd(colDe)) < tol,
  error('rmf2ss : De(s) is not column reduced.');
elseif max(dcolNe - dcolDe) > 0,
  error('rmf2ss : H(s) = Ne(s)*inv(De(s)) is not proper.');
end;

n = sum(dcolDe); p = rDe; m = rNe;
A = zeros(n); B = zeros(n,p); C = zeros(m,n);
% computation of block indices in A
ind = [1 dcolDe]; ind = cumsum(ind);

% extraction of the constant matrix D such that Ne(s) = D*De(s) + Hsp(s)
% where Hsp(s) is strictly proper
invDhc = inv(colDe);
colNe = zeros(m,p);
for j = 1:p,
 for i = 1:m,
  [deg,coef] = pdegco(psel(Ne,i,j));
  if deg == dcolDe(j),
    colNe(i,j) = coef;
  end;
 end;
end;
D = colNe*invDhc;

% numerator of Hsp(s)
Ne = psub(Ne, pmul(D, De));

% lower degree coefficient matrices Dlc and C = Nlc
Dlc = zeros(p, n);
for j = 1:p,
 for i = 1:p,
  pol = punpck(psel(De,i,j)); pol = [pol zeros(1,dcolDe(j)+1-length(pol))];
  Dlc(i,ind(j):ind(j+1)-1) = fliplr(pol(1:length(pol)-1));
 end;
 for i = 1:m,
  pol = punpck(psel(Ne,i,j)); pol = [pol zeros(1,dcolDe(j)+1-length(pol))];
  C(i,ind(j):ind(j+1)-1) = fliplr(pol(1:length(pol)-1));
 end;
end;

% A and B
K = invDhc*Dlc;
for j = 1:p,
 if dcolDe(j) > 1,
  A(ind(j):ind(j+1)-1,ind(j):ind(j+1)-1) = diag(ones(1,dcolDe(j)-1),-1);
 end;
 if dcolDe(j) > 0,
  A(ind(j),:) = - K(j,:);
  B(ind(j),:) = invDhc(j,:);
 end;
end;








