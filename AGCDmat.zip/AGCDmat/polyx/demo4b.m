%demo4b
%
% Application: SISO mixed sensitivity problem, Part 2

% H. Kwakernaak, June, 1997

disp('Demo4: SISO mixed sensitivity problem')

% Define the various polynomials

c = 1; r = 1;
n = ppck(1,0); d = ppck([0 0 1],2); m = ppck([1 sqrt(2) 1],2);
a1 = ppck(1,0); b1 = a1; b2 = a1; a2 = ppck([c c*r],1);


% Define the various polynomial matrices

D1 = ppck(zeros(3,2),0); D1 = pput(D1,1,1,b1); D1 = pput(D1,2,2,b2);
D2 = ppck(zeros(3,1),0); D2 = pput(D2,1,1,a1); D2 = pput(D2,3,1,d);
N1 = ppck(zeros(3,1),0); N1 = pput(N1,3,1,pscl(m,-1));
N2 = ppck(zeros(3,1),0); N2 = pput(N2,2,1,a2); N2 = pput(N2,3,1,pscl(n,-1));


% Left-to-right conversion

Q = ppck(eye(3),0); 
Q = pput(Q,1,1,b1); Q = pput(Q,2,2,b2); Q = pput(Q,3,3,m);
N2D2 = pcoljoin(N2,D2);
[Del,Lam] = lr(N2D2,Q);


% Prepare the search

gmin = 1; gmax = 10; accuracy = 1e-4;
if gmin > gmax
   error('Lower bound of gamma exceeds upper bound')
end


% Check existence and stability for gamma = gmax

Jgamma = eye(3); Jgamma(3,3)= -gmax^2;
DelDel = pmul(cjg(Del),Jgamma,Del);
tol = eps*norm(punpck(DelDel),1);
if any(abs(real(proots(DelDel,'eig','all')))<tol)
   error('No solution exists at the upper bound')
end
[Gam,J] = pjsf(DelDel,'ext',1);
xy = rl(pmul([1 0],Gam),Lam);
x = psel(xy,1,1); y = psel(xy,1,2);
phi = padd(pmul(n,y),pmul(d,x));
if ~phurwitz(phi)
   error('No stabilizing solution exists at the upper bound')
end

% Retain stabilizing solution
xopt = x; yopt = y; gopt = gmax;


% Check existence and stability for gamma = gmin

Jgamma = eye(3); Jgamma(3,3)= -gmin^2;
DelDel = pmul(cjg(Del),Jgamma,Del);
tol = eps*norm(punpck(DelDel),1);
if all(abs(real(proots(DelDel,'eig','all')))>tol)
   [Gam,J] = pjsf(DelDel,'ext',1);
   xy = rl(pmul([1 0],Gam),Lam);
   x = psel(xy,1,1); y = psel(xy,1,2);
   phi = padd(pmul(n,y),pmul(d,x));
   if phurwitz(phi)
      error('A stabilizing solution exists at the lower bound')
   end
end


% Binary search

while gmax-gmin > accuracy
   gamma = (gmin+gmax)/2;
   Jgamma = eye(3); Jgamma(3,3)= -gamma^2;
   DelDel = pmul(cjg(Del),Jgamma,Del);
   tol = eps*norm(punpck(DelDel),1);
   if any(abs(real(proots(DelDel,'eig','all')))<tol)
      gmin = gamma;
   else
      [Gam,J] = pjsf(DelDel,'ext',1);
      xy = rl(pmul([1 0],Gam),Lam);
      x = psel(xy,1,1); y = psel(xy,1,2);
      phi = padd(pmul(n,y),pmul(d,x));
      if ~phurwitz(phi)
         gmin = gamma;
      else
         gmax = gamma;
         xopt = x; yopt = y; gopt = gmax;
      end
   end
disp(gamma)
end

pdp(y),pdp(x)

% Cancel any common roots of xopt and yopt

tol = 1e-4;

rootsy = roots(punpckv(yopt,'rrow'));
xo = punpck(xopt); degxo = length(xo)-1;
yo = punpck(yopt); degyo = length(yo)-1;

for i = 1:length(rootsy)
   z = rootsy(i);

   % Divide xo(s) by s-z

   q = zeros(1,degxo);
   q(degxo) = xo(degxo+1);
   for j = degxo-1:-1:1
      q(j) = xo(j+1)+z*q(j+1);
   end

   % If the remainder is small then cancel
   % the factor s-z both in xo and in yo

   if abs(xo(1)+z*q(1)) < tol*norm(xo,1)
      xo = q; degxo = degxo-1;
      p = zeros(1,degyo);
      p(degyo) = yo(degyo+1);
      for j = degyo-1:-1:1
         p(j) = yo(j+1)+z*p(j+1);
      end
      yo = p; degyo = degyo-1;
   end  
end

xo = ppck(real(xo),degxo);
yo = ppck(real(yo),degyo);

pdp(yo),pdp(xo)