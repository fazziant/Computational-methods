% pjsf
%
% Polynomial J-spectral factorization
%
% The function
%
%     [A,J] = pjsf(B)
%     [A,J] = pjsf(B[,algorithm][,flag])
%
% solves the polynomial J-spectral factorization problem.
%
% Given a para-Hermitian polynomial matrix B(s) = B'(-s) the 
% function returns a polynomial matrix A and a constant diagonal
% matrix J such that
%
%     B(s) = A'(-s) J A(s)
%     A is Hurwitz
%
% The signature matrix J is diagonal of the form 
%
%    diag(J) = [1, 1, .., 1, -1, -1, .., -1].
%
% The parameter algorithm allows to specify the algorithm that 
% is used:
%
%    'ext' (default)          factor extraction by interpolation;
%    'are'                    state-space solution by solution of an
%                             algebraic Riccati equation;
%    'euc', 'res' and 'int'   Newton-Raphson iterative scheme based 
%                             on the corresponding implementations 
%                             of the function axxa2b.
%
% If the optional input argument 'flag' is present and is nonzero 
% then 
%
%     for the options 
%     'ext' and 'are'         a nearly non-canonical factorization 
%                             of the form 
%
%                                B(s) = A'(-s)*inv(J)*A(s)
%
%                             is computed, with J diagonal but not 
%                             a signature matrix;
%    for the other options    information on the convergence of the
%                             process is displayed.
%
% If B is a constant symmetric matrix then A is also constant and is
% obtained together with J from the Schur decomposition of B.

% Henrion D. 7-96
% modified by Henrion D. 4-97 :
% . critical cases are now handled and error messages displayed
% . nearly non-canonical factorization implemented with 'are' and 'ext'
% . 'res' and 'int' handle the semi-definite positive case
% Modified by H. Kwakernaak, April 10, 1997. Various bugs fixed. Accuracy test added.
% Modified by Henrion D., June 23, 1997. 'euc' replaces 'adj'.
% Modified by S. Pejchova, June 28, 1997

% functions used :
%     pinfo,psing,pzero,psub,cjg,pdiagred,schur
% for 'ext' :
%     pdegco,pput,psel,pscl,pmul,blcomp,schurst   
% for 'are' :
%     pdegco,ppck,punpck,pput,axxa2b,pscl,prowjoin,rmf2ss,
%     schurst,axb,padd,pmul
% and for 'euc', 'res', 'int' :
%     pdegco,pdiag,pput,ppck,pmax,axxa2b,pscl,padd,phurwitz,
%     schurst

function [A,J] = pjsf(B,algorithm,flag)

if nargin < 1
 disp('usage:  [A,J] = pjsf(B[,algorithm][,flag])');
 return
end
if (nargin < 3),
 flag = 0;
 if (nargin < 2),
  algorithm = 'ext';
 end;
end;

[typeB, n, cB, degB] = pinfo(B);
if (typeB == 'empt'),
  A = []; J = [];
  return;
elseif (n ~= cB),
  error('pjsf: The input matrix must be square.');
elseif finite(pdegco(pzero(psub(cjg(B),B)))),
  error('pjsf: The input matrix must be para-Hermitian');
elseif (degB == 0),
  B = punpck(B);
  typeB = 'cons';
end;
if psing(B)
   error('pjsf: The input matrix is singular')
end
if (typeB == 'cons'),

 % --------------------------------------------------------------
 % J-factorization of a constant matrix : B = A'*J*A
 % --------------------------------------------------------------

 [A,U] = schur(B); A = A';
 D = diag(U); J = diag(sign(D));
 for i = 1:n,
   if abs(D(i)) > eps,
    A(i,:) = A(i,:) * sqrt(abs(D(i)));
   end;
 end;
 [J,I] = sort(diag(-J)); 
 J = -diag(J); A = A(I,:);
 return

else

 % J-factorization of a polynomial matrix

 if any(abs(real(proots(B,'eig','all')))<eps*norm(punpck(B),1))
   error('pjsf: The input matrix has roots on the imaginary axis')
 end

 % B must be diagonally reduced
 [B, void, Udiagred] = pdiagred(B);

 if (algorithm == 'ext')

  % --------------------------------------------------------
  % factor extraction by interpolation
  % --------------------------------------------------------

  % Bm(s) = D'(-s)B(s)D(s) monic
  [D,ZL] = pdegco(B, 'dia');
  m = max(D); Bm = B;
  for i = 1:n,
    d = m - D(i);
    Bm = pput(Bm,i,':',pscl(pshift(psel(Bm,i,':'), d), (-1)^d));
  end;
  for i = 1:n,
    d = m - D(i);
    Bm = pput(Bm,':',i,pshift(psel(Bm,':',i),d));
  end;
  B2m = pdegco(Bm, 2*m);
  Bm = pmul(inv(B2m), Bm);
  % block companion matrix
  C = blcomp(Bm); rC = size(C, 1);

  % ordered Complex Schur decomposition C = RUR', R unitary.
  [U,R] = schurst(C,1e3*eps*norm(C,1));
  ind = 1:(rC/2-n*m+sum(D));

  % extraction of eigenvalues with negative real parts
  E = R(:, ind);

  % active row indices
  indices = 1:n*(m+1);
  for i = 1:n,
   for k = 0:m-D(i)-1,
    indices = indices(indices ~= i+k*n);
   end;
  end;
  Eh = E(indices, :);

  % interpolation
  Th = null(Eh')';

  % if T(s) is not unique...
  if size(Th,1) ~= n,
    error(['pjsf, option ext: No full rank factor found']);
  end;

  % recovering of extraction factor T(s)
  T2 = zeros(n, n*(m+1)); T = T2;
  T2(:, indices) = Th;
  for i = 1:n,
   for k = 0:D(i),
     T(:, i+k*n) = T2(:, i+(m-D(i)+k)*n); % remove spurious zeros
   end;
  end;
  
  T = ppck(real(T), m);
  [void,TL] = pdegco(T, 'col');
  if ~flag, % canonical factorization

    if min(svd(TL)) < 1e-5,
       disp('pjsf, option ext:');
       disp('pjsf warning: The factorization is close to noncanonical');
       disp('              Consider nearly non-canonical factorization');
    end;
    T = pmul(inv(TL), T);
    [K1,J] = pjsf(ZL); % constant J-factorization
    A = pmul(K1,T);

  else % "nearly" non-canonical factorization

    [Q,J] = schur((TL/ZL)*TL');
    [J,I] = sort(diag(-J)); 
    J = -diag(J); Q = Q(:,I);
    A = pmul(Q',T);
  end;
  
 elseif (algorithm == 'are'),

  % ----------------------------------------------------------
  % by solution of an Algebraic Riccati Equation
  % ----------------------------------------------------------

  % prefactorization

  [degZ, ZL] = pdegco(B, 'dia');
  N = ppck(zeros(n), 0);
  k = sqrt(norm(punpck(B), 'inf'))/n;
  for i = 1:n, % construction of stable N(s)
   pol = diag(fliplr(pascal(degZ(i)+1))); % stable polynomial
   N = pput(N, i, i, ppck(k*pol'/pol(degZ(i)+1), degZ(i))); % correct scaling
  end;

  % N*(s)M(s) + M*(s)N(s) = B(s)
  % with column degrees of M(s) equal to half diagonal degrees of B(s)
  M = axxa2b(N, pscl(B, .5), 'int', degZ);

  Q = prowjoin(N, M);
  delta = pdegco(Q, 'col');
  E = ppck(zeros(n), 0);
  for i = 1:n,
    E = pput(E, i, i, ppck([zeros(1,delta(i)) 1], delta(i)));
  end;

  % minimal realization of H=Q/E
  [As,Bs,Cs,Ds] = rmf2ss(Q, E);

  % Hamiltonian
  W = [zeros(n) eye(n); eye(n) zeros(n)];
  L = Ds'*W*Ds;
  if min(svd(L)) < eps,
    disp('pjsf: The term L=D''WD in the ARE is singular');
    error(['The input matrix may be singular']);
  end;
  Li = inv(L); S = Cs'*W*Ds;
  H = [As-Bs*Li*S' -Bs*Li*Bs'; -Cs'*W*Cs+S*Li*S' -(As-Bs*Li*S')'];
  [R,U,ind] = schurst(H);
  order = size(As,1);
  if sum(ind) ~= order,
    disp(['pjsf: Incorrect dimension of the stable invariant ' ...
          'subspace of the Hamiltonian']);
    error(['The input matrix may have purely imaginary zeros ']);
  end;
  X1 = U(1:order,ind); X2 = U(order+1:2*order,ind);
  
  % solution of ARE
  R = psub(ppck([zeros(order) eye(order)], 1), As); % R(s) = sI-A
  K = axb(R, pmul(Bs, E)); % (sI-A)K(s)=BE(s)

  if ~flag, % canonical factorization

    if min(svd(X1)) < 1e-5,
       disp('pjsf warning! X1 is close to singular');
       disp('Try nearly non-canonical factorization');
    end;

    X = real(X2/X1);
    F = Li*(Bs'*X+S');
    T = padd(E, pmul(F, K));

    [L,J] = pjsf(L); % constant J-factorization
    A = pmul(L, T);
 
  else % "nearly" non-canonical factorization

   N = null([Bs'*X2+S'*X1;X1]')';
   m = size(Bs,2);
   X1h = N(:,1:m); Gh = -N(:,m+1:m+order);
   T = padd(pmul(X1h*L,E), pmul(Gh,K));
   [void,TL] = pdegco(T, 'col');
   [Q,J] = schur((TL/ZL)*TL');
   [J,I] = sort(diag(-J)); 
   J = -diag(J); Q = Q(:,I);
   A = pmul(Q',T);

  end;


 elseif (algorithm == 'euc') | (algorithm == 'int') | (algorithm == 'res'),

  % ---------------------------------------------------------------
  % Newton-Raphson iterative scheme with axxa2b
  % ---------------------------------------------------------------

  % initial matrix A0

  Bs0 = pdegco(B, 0); % absolute coefficient matrix 
  % halves of diagonal degrees of B(s) and leading coefficient matrix
  [p, Bsh] = pdegco(B, 'dia'); 
  p = pdegco(pdiag(B), 'row')/2; 

  if (min(eig(Bs0)) < -eps) | (min(eig(Bsh)) < -eps),
     error('pjsf: The input matrix must verify the condition of positiveness');
  else
    e0 = min(eig(Bs0)); eh = min(eig(Bsh));
    if (min([e0 eh]) <= eps) & (algorithm == 'euc'),
      error('pjsf: The input matrix must verify the condition of positiveness');
    end;
    if e0 <= eps, % Bs0 only semi-definite positive
       % Schur form should be diagonal : positive eigenvalues first
       [S,Psi,ind] = schurst(-Bs0); S = -S;
       Psi(:,ind) = Psi(:,ind) * diag(sqrt(diag(S(ind,ind))));
       Psi(:,sum(ind)+1:n) = zeros(n,n-sum(ind));
    else
       Psi = chol(Bs0);
    end;
    if eh <= eps, % Bsh only semi-definite positive
       % Schur form should be diagonal : positive eigenvalues first
       [S,Phi,ind] = schurst(-Bs0); S = -S;
       Phi(:,ind) = Phi(:,ind) * diag(sqrt(diag(S(ind,ind))));
       Phi(:,sum(ind)+1:n) = zeros(n,n-sum(ind));
    else
       Phi = chol(Bsh);
    end;
  end;

  degA = max(p);
  newA = []; 
  for i = 1:n,
    for j = 1:n,
     if (i == j), % diagonal terms
      % coefficients of the polynomial (a+bs)^p(i)
      % aii(s) = (psi(i,i)^(1/p(i))+phi(i,i)^(1/p(i))*s)^p(i)
      if abs(Phi(i,i)) < eps,
       newA = pput(newA, i, i, Psi(i,i));
      else
       root = (Psi(i,i)/Phi(i,i))^p(i);
       coef = fliplr(poly(-ones(1,p(i))*root));
       newA = pput(newA, i, i, ppck(coef, p(i)));
      end;
     else % non-diagonal terms
      a = [zeros(1,p(j)) Phi(i,j)];
      a(1) = a(1) + Psi(i,j);
      % aij(s) = psi(i,j) + phi(i,j)*s^p(j)
      newA = pput(newA, i, j, ppck(a, p(j))); % non diagonal terms
     end; % if i
    end;
  end;

  % Newton recursion
 
  if flag,
    format compact;
  end;

  stop = 0; it = 0;
  while ~stop,

   it = it + 1;
   A = newA;
   up = pmax(psub(pmul(cjg(A),A),B));
   % 1st stopping criterion : when B is factorized
   stop = (up < eps*1e10);

   if flag,
    disp(['pjsf: iteration #' int2str(it) ...
          ' error max(A*A-B) =' num2str(up)]);
   end;

   if ~stop,
    % solution with columnwise leading coefficient matrix triangular
    if (algorithm == 'euc'),
     if flag, % comments
      X = axxa2b(A, B, algorithm, 'v');
     else
      X = axxa2b(A,B, algorithm);
     end;
    else
      X = axxa2b(A, B, algorithm, 't');
    end;
    newA = pzero(pscl(padd(A, X), .5));
    % 2nd stopping criterion : A becomes unstable
    stop = 2*(~phurwitz(newA));
   end;

  end;

  if flag,
    if stop == 2,
      disp('pjsf: Last A not stable');
    end;
    format;
  end;

  % computation of J : zero diagonal elements correspond to zero rows in A
  J = eye(n);
  for i = 1:n,
    row = punpck(psel(A, i, ':'));
    if norm(row) < eps,
      J(i,i) = 0;
    end;
  end;

 else

  error('pjsf: Invalid algorithm');

 end;  % if algorithm

 % multiplication by the unimodular matrix
 % corresponding to the diagonal reduction
 A = pzero(pmul(A,Udiagred));

end; % if typeB == 'cons'


% Final check

if (strcmp(algorithm,'ext') | strcmp(algorithm,'are')) & flag
   B0 = pval(B,0); A0 = pval(A,0);
   Eps = J-(A0/B0)*A0';
   Eps = norm(Eps,1)/norm(B0,1);
else 
   Eps = psub(B,pmul(cjg(A),J,A)); 
   Eps = norm(punpck(Eps),1)/norm(punpck(B),1);
end

if Eps > 1e-6
   disp(sprintf('pjsf warning: Relative residue %g',Eps));
end
