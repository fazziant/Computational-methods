% phurwitz
%
% Test whether a polynomial marix is Hurwitz
% 
% The function
%
%   phurwitz(A)
%
% returns 1 if the polynomial matrix A is strictly Hurwitz, that 
% is, all its zeros have strictly negative real parts. Otherwise 
% the function returns 0.
%
% If the matrix is a constant matrix, then it is considered not to be 
% Hurwitz.

% Henrion D. 3-96
% Modified by S. Pejchova, June 26, 1997
% function used: pdet, pinfo, pdegco, punpck

function s = phurwitz(a)

if nargin < 1
 disp('usage:  phurwitz(A)');
 return
end
s = 0;
[typea, ra, ca, dega] = pinfo(a);

if (typea == 'poly') & (dega > 0),
  if (ra > 1) | (ca > 1),
    if ra ~= ca,
      error('phurwitz: The input matrix is not square')
    end;
    a = pdet(a);
    dega = pdegco(a);
  end;

  % Routh array on det(A)

  if finite(dega) & (dega > 0),
    a = sign(a(1,1)) * punpck(a);
    if all(a > 0),
      a = [a 0];
      size = ceil((dega+1)/2);
      if size > 1,
        R = [a(1+2*(0:size-1)); a(2*(1:size))];
        j = 1;
        while size > 1,
          p = R(j, 1); q = R(j+1, 1);
          for i = 2:size,
            m = R(j+1, i);
            if abs(m) > eps,
              k = - (m * p - R(j, i) * q) / q;
              if k <= eps,
                return;
              end;
            else
              k = R(j, i);
            end;
            R(j+2, i-1) = k;
          end; % for i
          j = j + 1;
          if abs(m) < eps,
            size = size - 1;
          end;
        end; % while size
      end; % if size
      s = 1;
    end; % if all
  end; % if finite
end; % if typea




