%pkron
%
% Kronecker product of polynomial matrices
%
% The command
%
%    C = pkron(A,B)
%
% produces the Kronecker tensor product of two polynomial matrices 
% A and B. 
%
% If one of the input matrices is a regular Matlab matrix then it is 
% considered to be a polynomial matrix with degree 0. If both input 
% matrices are regular Matlab matrices then C is of the same type.

% Henrion D. 2-96
% functions used : kron, pinfo, pdegco, psel, pmul
% Modified by S. Pejchova, 28.06.1997.

function C = pkron(A, B)

if nargin ~= 2
   disp('usage: C = pkron(A,B)');
   return;
end

[typeA, rA, cA, degA] = pinfo(A);
[typeB, rB, cB, degB] = pinfo(B);
if isempty(A)|isempty(B)
   C=[]; return
end
if (degA<=0|isnan(degA))&(degB<=0|isnan(degB))
   C=kron(punpck(A),punpck(B));
   if strcmp(typeA,'poly')|strcmp(typeB,'poly')
      C=ppck(C,0);
   end
   return
else
 if degA == 0, A = punpck(A); typeA == 'cons'; end;
 if degB == 0, B = punpck(B); typeB == 'cons'; end;
 if (typeA == 'cons'), degA = 0; end;
 if (typeB == 'cons'), degB = 0; end;
 if degA<0, degA=0; end
 if degB<0, degB=0; end
 if (typeA == 'cons') & (typeB == 'cons'),
  C = kron(A, B);
 else
  if (typeA == 'cons') & (rA == cA),
   if (max(eye(rA) - A) < eps),
    % A is identity, C has a simple structure
    C = zeros(rA*rB, cA*cB*(degB+1));
    for deg = 0:degB,
     Bdeg = pdegco(B, deg);
     for i = 1:rA
      C(1+(i-1)*rB:i*rB, 1+(i-1)*cB+deg*cA*cB:i*cB+deg*cA*cB) = Bdeg;
     end;
    end;
    C = ppck(C, degB);
    return;
   end; % if (max(eye(rA) - ...
  end;
  % polynomial Kronecker product with constant Kronecker products
  C = []; degC = degA + degB;
  for deg = 0:degC,
    if deg > degB,
      dmin = deg-degB;
    else
      dmin = 0;
    end;
    if deg < degA,
      dmax = deg;
    else
      dmax = degA;
    end;
    Cdeg = zeros(rA*rB, cA*cB);
    for i = dmin:dmax,
      Cdeg = Cdeg + kron(A(1:rA,1+i*cA:(i+1)*cA), ...
                         B(1:rB,1+(deg-i)*cB:(deg-i+1)*cB));
    end;
    C = [C Cdeg];
  end; % for deg ...
  C = ppck(C, degC);
 end; % if (typeA == 'cons') & (typeB == 'cons') ...
end;



