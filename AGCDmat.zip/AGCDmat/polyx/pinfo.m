%pinfo
%
% Provides matrix information
%
% The function 
%
%    [mattype,rQ,cQ,degQ] = pinfo(Q)
%
% first detects the type of the input matrix and returns in mattype 
% the string 'cons', 'poly' or 'empt' if the input matrix is a regular 
% Matlab matrix, a polynomial matrix or an empty matrix, respectively.
%
% The integer rQ is the number of rows and cQ the number of columns. 
%
% If Q is a polynomial matrix then degQ is its degree; otherwise, NaN
% is returned.

% $Revision: 1.3 $	$Date: 1996/07/19 09:16:31 $	$State: Exp $

function [mattype,rQ,cQ,degQ] = pinfo(Q)

if nargin ~= 1
   disp('usage: [mattype,rQ,cQ,degQ] = pinfo(Q)')
   return
end

[rQ,cQ] = size(Q);

degQ = NaN;

if isempty(Q) 
   mattype = 'empt';
   return
end
mark = Q(rQ,cQ);
degree = Q(1,cQ);
if rQ == 1 | ~isnan(mark) 
   mattype = 'cons';
else
   normQ = norm(Q(1:rQ-1,1:cQ-1),inf);
   test1 = norm(Q(rQ,1:cQ-1));
   test2 = norm(Q(2:rQ-1,cQ));
   if isnan(test2)
      test2 = 0; 
   end
   test3 = (floor(degree) ~= ceil(degree)) | (degree ~= -Inf & degree < 0);
   test4 = (degree == -Inf & normQ) | (degree ~= -Inf & ~normQ);
   if degree ~= -Inf
      test5 = rem(cQ-1,degree+1);
   else
      test5 = 0;
   end
   if test1 | test2 | test3 | test4 | test5
      mattype = 'cons';
   else
      mattype = 'poly';
      rQ = rQ - 1;
      if degree ~= -Inf
	 cQ = (cQ -1) / (degree + 1);
      else
	 cQ = cQ - 1;
      end
      degQ = degree;
   end
end
