% p2sym
%      
% The command
%
%    Asym = p2sym(Apoly[,var])
%
% converts the polynomial matrix Apoly in the Polynomial Toolbox 
% format to the symbolic matrix Asym in the Symbolic Toolbox format.
%
% The optional parameter 'var' is the indeterminate (with default 
% value: 's')

% Henrion D. 5-97
% Modified by S. Pejchova, June 26, 1997
%
% functions used :
% Symbolic Toolbox : symmul, sym
% Polynomial Toolbox : pinfo, psel, punpck

function Asym = p2sym(Apoly,var)

if nargin < 1
 disp('usage:  Asym = p2sym(Apoly[,var])');
 return
end
if nargin == 1,
  var = 's';
elseif ~isstr(var),
  error('p2sym: The second input argument must be a string');
end;

[type,nr,nc,deg] = pinfo(Apoly);

% build the string '[a11,..,a1c;a21,..,a2c;...;ar1,...arc]'
% where the aij are symbolic polynomial entries
Asym = [];
for r = 1:nr,
 row = [];
 for c = 1:nc,
  p = psel(Apoly, r, c); % extract polynomial entry
  degp = pdegco(p);
  if isinf(degp),
    s = '0'; % zero polynomial
  else
    % symbolic polynomial from its coefficients
    s = symmul(sym(1,degp+1,[var '^(j-1)']), sym(punpck(p).'));
  end;
  row = [row s ','];
 end; % for each column
 Asym = [Asym row(1:length(row)-1) ';'];
end; % for each row
Asym = Asym(1:length(Asym)-1);

Asym = sym(Asym);
