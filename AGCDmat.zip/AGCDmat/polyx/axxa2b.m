%axxa2b
%
% If A and B are polynomial matrices then the function
%
%     X = axxa2b(A,B[,algorithm][,coldeg][,flag])
%
% solves the symmetric matrix polynomial equation
%
%      A'(-s)X(s) + X'(-s)A(s) = 2B(s)
%
% where A is a given square polynomial matrix and B a given 
% para-Hermitian polynomial matrix (B(s) = B'(-s)).
%
% The parameter 'algorithm' allows to specify the algorithm used:
%
%  'int' (default): interpolation;
%  'res': resolution of the linear system corresponding to the 
%     reduced resultant matrix formulation;
%  'euc': post- and premultiplication by the adjoint of A and 
%     resolution of scalar polynomial equations by Euclidean 
%     division.
%
% With the options 'int' and 'res' a solution X of column degrees 
% coldeg is computed. The default is 
%
%   coldeg(i) = degB(s) - degA(s) for all i.
%
% If flag is 't', then a solution with upper-triangular columnwise 
% leading coefficient matrix is returned.
%
% With the option 'euc' and under the assumptions that A is 
% Hurwitz and A'^-1(-s)B(s)A^-1(s) is biproper, the macro computes
% a solution with upper-triangular columnwise leading coefficient 
% matrix and such that X(s)A^-1(s) is proper. If flag is set to 'v' 
% then comments are printed during the execution of the macro.
%
% If no solution exists that satisfies the assumptions then X = [].
%
% If A and B are scalar polynomials then the function
%
%    X = axxa2b(A,B[,algorithm][,degree])
%
% solves the symmetric polynomial equation 
%
%    A(-s)X(s) + X(-s)A(s) = 2B(s).
%
% If the algorithm is 'euc' (the default case), A is Hurwitz and
% degB <= 2*degA then the Euclidean division algorithm is applied
% to find a solution X such that degX <= degA.
%
% If the algorithm is 'res' then the resultant method is used to
% obtain a solution X of degree less than or equal to the value of 
% the optional input argument degree. The default value of the
% degree is degB - degA.
%
% If no solution exists that satisfies the assumptions then X = [].

% Henrion D. 3/5-96
%
% for A and B matrices, functions used : pdet, adj, axya2b, xab
% and also : pinfo, ppck, psing, pdegco, pmul, cjg, pput, padd, pscl, pzero
%
% for A and B polynomials, functions used : pinfo, ppck (euclidean algorithm)
% presult, / (resultant formulation)
%
% $Revision: 1.4 $	$Date: 1996/10/07 06:53:49 $	$State: Exp $
%
% Modified by Henrion D. on May 13, 97
% - distinct column degrees handled
% - input argument 'coldeg' added
% - flags 't' and 'v' added
% Modified by Henrion D. June 97
% - additional checks are made for 'euc' algorithm

function X = axxa2b(A,B,p1,p2,p3)

zeroing = 1; % zeroing always enabled
tol = 1e-7; % fixed tolerance

if (nargin < 2),
  disp('usage: X = axxa2b(A,B[,algorithm][,coldeg][,flag])');
  return;
end;

[typeA,n,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);

if (n ~= cA) | (rB ~= cB),
  error('input matrices must be square');
elseif (n ~= rB),
  error('input matrices must have the same size');
elseif norm(punpck(pzero(psub(B,cjg(B))))) > tol,
  error('second input matrix is not para-Hermitian');
elseif (typeA == 'cons'),
  A = ppck(A, 0); degA = 0;
end;
if psing(A),
  error('first input matrix is singular to working precision');
end;
if (typeB == 'cons'),
  B = ppck(B, 0); degB = 0;
end;
if isinf(degB),
  degB = 0;
end;

if (n == 1) & (cA == 1) & (rB == 1) & (cB == 1),

% ------------------------------------------------------------------------
% A and B are scalar polynomials
% ------------------------------------------------------------------------

algorithm = 'res'; % default algorithm
verbose = 0; % no messages
coldeg = []; % degree not given

% parse input arguments

if nargin >= 3,
 if strcmp(p1, 'euc') | strcmp(p1, 'res'),
  algorithm = p1;
  if nargin > 3,
   if nargin > 4,
    error('invalid number of arguments');    
   elseif strcmp(p1, 'euc'),
    error('no argument allowed with algorithm ''euc''');
   elseif isstr(p2),
    error('fourth argument should be a scalar');
   else
    if min(p2) >= 0,
     coldeg = p2;
    else
     error('negative degrees not allowed');
    end;
   end;
  end;
 else
  error('with scalar polynomials valid algorithms are ''euc'' or ''res''');
 end;
end;

a = A; b = B; % lowercase variable names
typea = typeA; typeb = typeB;
ra = n; ca = cA; rb = rB; cb = cB;
dega = degA; degb = degB;

if b == 0,
  X = ppck(0,0);
  return;
end;

if (algorithm == 'euc'),

  % EUCLIDEAN ALGORITHM

  % separation of odd and even parts of a and b

  na = floor(dega/2)+1; nb = floor(degb/2)+1; m = max(na, nb);
  ae = zeros(1,m); ao = ae; be = ae;
  a(1, dega+2) = 0; b(1, degb+2) = 0;

  for i = 1:na,
    ae(i) = a(1, (i-1)*2+1);
    ao(i) = a(1, 2*i);
  end;
  for i = 1:nb,
    be(i) = b(1, (i-1)*2+1); % odd coefs supposed to be zero
  end;

  % forward construction of coefficients

  coefs = []; nit = 1;

  while length(find(ao)) > 0, % while polynomial ao(s) is not zero
    a1 = ao(1); a2 = ae(1);
    if (abs(a1) < eps) | (abs(a2) < eps),
      error(['with Euclidean algorithm, first input polynomial ' ...
             'must be strictly stable']);
    end;
    coefs = [coefs; a2/a1 be(1)/a2];
    be = [be(2:m) - coefs(nit,2)*ae(2:m) 0];
    aen = ao; ao = [ae(2:m) - coefs(nit,1)*ao(2:m) 0]; ae = aen;
    nit = nit + 1;
  end;

  % backward substitutions

  ue = zeros(1,m); uo = ue;
  ue(1:length(be)) = be/ae(1);

  for i = nit-1:-1:1,
    uon = ue - coefs(i,1)*uo;
    ue = [coefs(i,2) uo(1:m-1)]; uo = uon;
  end;

  % construction of solution x(s)

  x = [];
  for i = 1:m,
    x = [x ue(i) -uo(i)];
  end;

  degx = 2*m - 1;

else % algorithm == 'res'

  % RESULTANT FORMULATION

  if isempty(coldeg),
   degx = degb - dega;
  else
   if coldeg < degb - dega,
     error(['expected solution degree does not verify' ...
	    ' the required inequality (see documentation)']);
   else
     degx = coldeg;
   end;
  end;

  RA = presult(a, degx);
  b = [punpck(b) zeros(1,dega+degx-degb)];

  be = []; R = [];
  for i = 1:2:dega+degx+1,
    R = [R RA(:, i)];
    be = [be b(i)];
  end;

  if rank(R, tol) ~= size(R, 2),
    x = be * pinv(R); % solution in the least-square sense
    % check
    if norm(x*R-be) > tol,
      X = [];
      return; % no solution
    end;
  else
    x = be / R; % exact solution
  end;

  for i = 2:2:degx+1,
    x(i) = -x(i);
  end;

end; % if algorithm

if zeroing,
 X = pzero(ppck(x, degx));
else
 X = ppck(x, degx);
end;

else % if (n == 1) & ...

% --------------------------------------------------------------------------
% A and B are polynomial matrices
% --------------------------------------------------------------------------

algorithm = 'int'; % default algorithm
triang = 0; % columnwise leading matrix not triangular
coldeg = []; % column degrees not given

% parse input arguments

if nargin >= 3,

 algorithm = p1;
 if strcmp(p1, 'int') | strcmp(p1, 'res'),

  if nargin >= 4,
   if isstr(p2),
    if ~strcmp(p2, 't'),
     error('fourth argument should be ''t''');
    else
     triang = 1;
    end;
   else
    if (min(size(p2)) ~= 1) | (length(p2) ~= n),
     error('fourth argument has invalid size');
    else
     if min(p2) >= 0,
      coldeg = p2;
     else
      error('negative degrees not allowed');
     end;
    end;
   end;
   if nargin == 5,
    if isstr(p3),
     if ~strcmp(p3, 't'),
      error('fifth argument should be ''t''');
     else
      triang = 1;
     end;
    else
     if (min(size(p3)) ~= 1) | (length(p3) ~= n),
      error('fifth argument has invalid size');
     else
      if min(p3) >= 0,
       coldeg = p3;
      else
       error('negative degrees not allowed');
      end;
     end;
    end;
   end;
  end;

 elseif strcmp(p1, 'euc'),

  if nargin > 3,
   if ~strcmp(p2, 'v'),
    error('fourth argument should be ''v''');
   else
    verbose = 1;
   end;
  end;

 else
  error('invalid algorithm');
 end;
end;

% permutation matrix for Kronecker product
n2 = n^2;
P = zeros(n2);
for i = 1:n, for j = i:n,
  k = i+(j-1)*n; l = j+(i-1)*n;
  P(k, l) = 1; P(l, k) = 1;
end; end;

% reduced permutation indices
inde = []; indo = [];
for i = 1:n, for j = 1:n,
  k = i+(j-1)*n; l = j+(i-1)*n;
  if k >= l,
    if k > l,
      indo = [indo l];
    end;
    inde = [inde l];
  end;
end; end;

if (algorithm == 'int'),

  % INTERPOLATION

  if isempty(coldeg),
   coldeg = max(degB-degA,0) * ones(1,n); % default values
  end;
  degX = max(coldeg);
  
  % condition on column degrees
  entB = pdegco(B,'ent');
  colA = pdegco(A,'col');
  for i = 1:n, for j = 1:n,
   if entB(i,j) > max(colA(i)+coldeg(j), colA(j)+coldeg(i)),
    error(['column degrees do not verify the required inequalities' ...
           ' (see documentation)']);
   end;
  end; end;

  X = zeros(n, (degX+1)*n);

  % matrix Delta* and number of points
  D = zeros(n);
  k = (degX+degA+1)/2;
  for j = 1:n,
    D(j,j) = ceil(k);
    for i = j+1:n,
      D(i,j) = ceil(k);
      D(j,i) = floor(k);
    end;
  end;
  D = D(:); ne = max(D); q = sum(D);

  % Q(s) and L(s)
  Qm = pkron(eye(n), cjg(A)); Qp = pmul(P, pkron(eye(n), ptransp(A)));
  Lp = padd(Qm, Qp); Lm = psub(Qm, Qp);

  % construction of LSE : Lq vecX = Bq
  Lq = []; Bq = [];
  for i = 1:ne,
    ind = (D >= i);
    s = 1; Lv = [];
    pt = i/ne;
    for d = 0:degX,
      if rem(d, 2), % odd degree
         Lv = [Lv s*pval(Lm, pt)];
      else
         Lv = [Lv s*pval(Lp, pt)];
      end;
      s = s*pt;
    end;
    Lq = [Lq; Lv(ind, :)];
    Bv = pval(B, pt); Bv = Bv(:); Bq = [Bq; 2*Bv(ind)];
  end;

  if triang,
   % additional constraints to force X(degX) triangular
   Ad = zeros(n*(n-1)/2, n2*(degX+1));
   i = 1;
   for col = 1:n, for row = col+1:n,
    Ad(i, row+(col-1)*n+coldeg(col)*n2) = 1;
    i = i + 1;
   end; end;
   Lq = [Lq; Ad]; Bq = [Bq; zeros(n*(n-1)/2,1)];
  end;

  % suppression of zero components corresponding to distinct column degrees
  if any(coldeg - degX),
   active_indices = [];
   i = 0;
   for deg = 0:degX,
    for col = 1:n,
     if coldeg(col) >= deg,
      active_indices = [active_indices [n*i + (1:n)]];
     end;
     i = i + 1;
    end;
   end;
   Lq = Lq(:, active_indices);
  else
   active_indices = 1:n2*(degX+1);
  end;

  % resolution of augmented LSE
  sol = zeros(n2*(degX+1),1); 
  if rank(Lq, tol) ~= size(Lq, 1),
    v = pinv(Lq) * Bq;
    % check
    if norm(Lq*v-Bq) > tol,
      X = [];
      return; % no solution
    else
      sol(active_indices) = v;
    end;
  else
    sol(active_indices) = Lq \ Bq; % Lq * vecX = Bq
  end;
  X(:) = sol;
  X = ppck(X, degX);

  if zeroing,
    X = pzero(X);
  end;

elseif (algorithm == 'res'),

  % REDUCED RESULTANT METHOD

  if isempty(coldeg),
   coldeg = max(degB-degA,0) * ones(1,n); % default values
  end;
  degX = max(coldeg);
  
  % condition on column degrees
  entB = pdegco(B,'ent');
  colA = pdegco(A,'col');
  if max(coldeg) < degB - degA,
    error(['column degrees do not verify the required inequality' ...
           ' (see documentation)']);
  end;

  X = zeros(n, n*(degX+1));

  % suppression of linearly dependent rows
  % even (1+P) : n^2 rows -> n(n+1)/2 independent rows
  % odd  (1-P) : n^2 rows -> n(n-1)/2 independent rows
  Pe = eye(n2) + P; Po = eye(n2) - P;
  Pe = Pe(inde, :); Po = Po(indo, :);

  % generator of the extended resultant matrix
  KA = zeros(n2, (degA+2*degX+1)*n2);
  for i = 0:degA,
    KA(:, 1+(degA+degX-i)*n2:(degA+degX-i+1)*n2) = ...
      (-1)^i * kron(eye(n), pdegco(A, i)');
  end;

  % construction of the reduced resultant matrix (left hand-side)
  % and the reduced B vector (right hand-side)
  R = []; Bv = [];
  for i = 0:degA+degX,
    if i <= degB,
      Bi = 2 * pdegco(B, i);
      Bi = Bi(:); % vec(Bi)
    else
      Bi = zeros(n2, 1); % if 2*degA > degB
    end;
    if rem(i,2) % odd
      R = [R; Po * KA(:, 1+(degA+degX-i)*n2:(degA+2*degX-i+1)*n2)];
      Bv = [Bv; Bi(indo, :)];
    else % even
      R = [R; Pe * KA(:, 1+(degA+degX-i)*n2:(degA+2*degX-i+1)*n2)];
      Bv = [Bv; Bi(inde, :)];
    end;
  end; % for i

  if triang,
   % additional constraints to force X(degX) triangular
   Ad = zeros(n*(n-1)/2, n2*(degX+1));
   i = 1;
   for col = 1:n, for row = col+1:n,
     Ad(i, row+(col-1)*n+coldeg(col)*n2) = 1;
     i = i + 1;
   end; end;
   R = [R;Ad]; Bv = [Bv;zeros(n*(n-1)/2,1)];
  end;

  % suppression of zero components corresponding to distinct column degrees
  if any(coldeg - degX),
   active_indices = [];
   i = 0;
   for deg = 0:degX,
    for col = 1:n,
     if coldeg(col) >= deg,
      active_indices = [active_indices [n*i + (1:n)]];
     end;
     i = i + 1;
    end;
   end;
   R = R(:, active_indices);
  else
   active_indices = 1:n2*(degX+1);
  end;

  % resolution of augmented LSE
  sol = zeros(n2*(degX+1),1); 
  if rank(R, tol) ~= size(R, 1),
    v = pinv(R) * Bv;
    % check
    if norm(R*v-Bv) > tol,
      X = [];
      return; % no solution
    else
      sol(active_indices) = v;
    end;
  else
     sol(active_indices) = R \ Bv; % R * vecX = Bv
  end;
  X(:) = sol;
  X = ppck(X, degX);

  if zeroing,
    X = pzero(X);
  end;

else % algorithm == 'euc'

  % ADJOINT ALGORITHM

  % transformation into a set of polynomial equations
  if zeroing,
    detA = pdet(A, 'z');  degdA = pdegco(detA);
    T = pzero(adj(A, detA));
    B2 = pmul(cjg(T), B, T, 'z');
  else
    detA = pdet(A); degdA = pdegco(detA);
    T = adj(A, detA);
    B2 = pmul(cjg(T), B, T);
  end;

  % resolution of (n+1)n/2 scalar polynomial equations
  % of the form a* x + y* a = 2b
  X2 = ppck(ones(n, n*(degdA+1)), degdA);
  % diagonal terms
  for i = 1:n,
    xii = axxa2b(detA, psel(B2, i, i), 'euc');
    % X*inv(A) is not proper
    if pdegco(pzero(xii, tol)) > degdA,
      if verbose,
        disp('WARNING: X*A^-1 is not proper.');
      end;
      X = []; return;
    end;
    X2 = pput(X2, i, i, xii);
  end;
  % n(n-1) other terms
  if (n > 1),
    for i = 1:n-1,
      for j = i+1:n,
       [xij xji] = axya2b(detA, psel(B2, i, j), 'euc');
       if max(pdegco(pzero(xji,tol)), pdegco(pzero(xij, tol))) > degdA,
        if verbose,
          disp('WARNING: X*A^-1 is not proper.');
        end;
        X = []; return;
       end;
       X2 = pput(X2, i, j, xij);
       X2 = pput(X2, j, i, xji);
      end;
    end;
  end; % if n

  if zeroing,
    X2 = pzero(X2);
  end;

  if verbose,
    R = pzero(padd(pmul(cjg(detA),X2),pmul(cjg(X2),detA),pscl(B2,-2)));
    if finite(pdegco(R)),
      disp('axxa2b: WARNING ! X'' is not solution to working precision');
      disp(['        residue = ' num2str(pmax(R))]);
    end;
  end;

  % recovering of X
  X = xab(T, X2, 1e4*tol);
  if isempty(X),
   if verbose,
     disp(['WARNING: recovering of X failed with tolerance = ' ...
        num2str(1e4*tol)]);
   end;
   return;
  end;
  if zeroing,
    X = pzero(X);
  end;

  if verbose,	
    R = pzero(padd(pmul(cjg(A),X),pmul(cjg(X),A),pscl(B,-2)));
    if finite(pdegco(R)),
      disp('axxa2b: WARNING ! X is not solution to working precision');
      disp(['        residue = ' num2str(pmax(R))]);
    end;
  end;

  degX = pdegco(pzero(X));

  PA = pdegco(A, degA);
  PX = pdegco(X, degX);

  % construction of Q such that strictly lower part of Q PA + PX is 0 :
  % resolution of a LSE of order (n-1)n/2 

  ind = [];
  for i = 1:n-1,
    ind = [ind 1+i+(i-1)*n:i*n]; % indices of lower triangular entries
  end;
  M = kron(PA',eye(n)) * (eye(n2) - P);
  M = M(ind, ind); % reduced Kronecker product
  y = -PX(:); y = y(ind); % reduced right hand-side -vecPX

  if norm(y) > tol, % if lower triangular entries are not zero

    if (rank(M, tol) ~= size(M, 1)),
      x = pinv(M) * y;
    else
      x = M \ y; % column vector of elements of Q
    end;

    R = zeros(n2, 1); R(ind) = x;
    Q = zeros(n); Q(:) = R; Q = Q - Q'; % construction of skew-symmetric Q
    if zeroing,
      X = padd(X, pmul(pshift(Q, degA - degX), A, 'z'), 'z');
    else
      X = padd(X, pmul(pshift(Q, degA - degX), A));
    end;
  end; % if norm

end % if algorithm

if verbose,
  R = pzero(padd(pmul(cjg(A),X),pmul(cjg(X),A),pscl(B,-2)));
  if finite(pdegco(R)),
    disp('axxa2b: WARNING ! bad unique solution X to working precision');
    disp(['        residue = ' num2str(pmax(R))]);
  end;
end;

end; % if (n == 1) & ...
