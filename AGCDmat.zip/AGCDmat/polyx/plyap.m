% plyap
%
% Solution of a two-sided equation with matrix pencil coefficients
%
% The command
%
%   [X,Y] = plyap(A,B,C)
%   [X,Y] = plyap(A,B,C,tol)
%
% solves the "pencil" equation
%
%   A*X + Y*B = C
%
% with A and B square polynomial matrices of degree 1, for the 
% constant matrices X and Y. 
%
% If A and B have no common zeros then a unique solution exists. If 
% this condition is not satisfied then the solution may be inaccurate.
%
% The optional parameter tol is a tolerance that is used in testing 
% whether any of the pencils A or B is upper or lower triangular.

% Huibert Kwakernaak, November 1, 1996
% Revised December 30, 1996
% Revised April, 1997
% Modified by S. Pejchova, June 26, 1997

function [X,Y] = plyap(A,B,C,tol)


% Initialize and convert to the equation
%  (s*E1-A1)*X + Y*(s*E2-A2) = s*E3-A3

if nargin < 3
 disp('usage:  [X,Y] = plyap(A,B,C[,tol])');
 return
end
[mattype,rA,cA,degA] = pinfo(A);
if ~strcmp(mattype,'poly') | rA~=cA | degA>1
   error('plyap: The first input argument is not a square pencil')
else
   P = punpck(A); n1 = rA; 
   A1 = -P(:,1:n1); 
   if degA == 1
      E1 = P(:,n1+1:2*n1);
   else
      E1 = zeros(n1);
   end
end
[mattype,rB,cB,degB] = pinfo(B);
if ~strcmp(mattype,'poly') | rB~=cB | degB>1
   error('plyap: The second input argument is not a square pencil')
else
   P = punpck(B); n2 = rB; 
   A2 = -P(:,1:n2); 
   if degB == 1
      E2 = P(:,n2+1:2*n2);
   else
      E2 = zeros(n2);
   end
end
[mattype,rC,cC,degC] = pinfo(C);
if ~strcmp(mattype,'poly') | rC~=n1 | n2~=cC | degC>1
   error('plyap: The third input argument is not a pencil of the correct dimensions')
else
   P = punpck(C); 
   A3 = -P(:,1:n2); 
   if degC == 1
      E3 = P(:,n2+1:2*n2);
   else
      E3 = zeros(n1,n2);
   end
end
if nargin == 3
   tol = sqrt(eps);
end


EE1 = E1; AA1 = A1; EE2 = E2; AA2 = A2; EE3 = E3; AA3 = A3;


% Check if the problem has any complex inputs

if any(any(imag(E1))) | any(any(imag(A1))) ...
   | any(any(imag(E2))) | any(any(imag(A2))) ...
   | any(any(imag(E3))) | any(any(imag(A3)))
   real_flg = 0;
else
   real_flg = 1;
end


% Test if s*E1-A1 or s*E2-A2 is upper or lower triangular

case = 0;  % Neither pencil is upper or lower triangular

e = zeros(n1); a = e;
for i = 1:n1, for j = 1:i-1
   e(i,j) = E1(i,j); a(i,j) = A1(i,j);
end, end
if norm(e,1) < tol*norm(E1) & norm(a,1) < tol*norm(A1)
   case = 1;  % s*E1-A1 is upper triangular
end

e = zeros(n1); a = e;
for i = 1:n1, for j = i+1:n1
   e(i,j) = E1(i,j); a(i,j) = A1(i,j);
end, end   
if norm(e,1) < tol*norm(E1) & norm(a,1) < tol*norm(A1)
   case = 2;  % s*E1-A1 is lower triangular
end 

e = zeros(n1); a = e;
for i = 1:n2, for j = 1:i-1
   e(i,j) = E2(i,j); a(i,j) = A2(i,j);
end, end
if norm(e,1) < tol*norm(E2) & norm(a,1) < tol*norm(A2)
   case = 3;  % s*E2-A2 is upper triangular
end

e = zeros(n2); a = e;
for i = 1:n2, for j = i+1:n2
   e(i,j) = E2(i,j); a(i,j) = A2(i,j);
end, end   
if norm(e,1) < tol*norm(E1) & norm(a,1) < tol*norm(A1)
   case = 4;  % s*E2-A2 is lower triangular
end 


% Arrange s*E2-A2 to be upper triangular

if case == 0
   [E2,A2,Q,Z] = qz(E2,A2); E3 = E3*Z; A3 = A3*Z;
elseif case == 1          % s*E-A1 is UT
   e = E1; a = A1;
   E1 = E2'; A1 = A2'; E3 = fliplr(E3'); A3 = fliplr(A3');
   E2 = flipud(fliplr(e')); A2 = flipud(fliplr(a')); 
elseif case == 2          % s*E1-A1 is LT
   e = E1; a = A1; 
   E1 = E2'; A1 = A2'; E3 = E3'; A3 = A3';
   E2 = e'; A2 = a';
elseif case == 4          % s*E2-A2 is LT
   E2 = flipud(fliplr(E2)); A2 = flipud(fliplr(A2)); 
   E3 = fliplr(E3); A3 = fliplr(A3);
end
n1 = length(E1); n2 = length(E2);


% Solve for X and Y column by column from left to right

X = zeros(n1,n2); Y = X;

for j = 1:n2
   e = E2(j,j); a = A2(j,j);
   X(:,j) = (a*E1-e*A1)\(a*E3(:,j)-e*A3(:,j)-Y*(a*E2(:,j)-e*A2(:,j)));
   Y(:,j) = e'*E3(:,j)+a'*A3(:,j)-(e'*E1+a'*A1)*X(:,j) ...
            -Y*(e'*E2(:,j)+a'*A2(:,j));
   Y(:,j) = Y(:,j)/(abs(e)^2+abs(a)^2);
end


% Reconstruct the solution

if case == 0
   X = X/Z; Y = Y*Q;
elseif case == 1
   X = fliplr(X); Y = fliplr(Y);
   x = X; X = Y'; Y = x';
elseif case == 2
   x = X; X = Y'; Y = x';
elseif case == 4
   X = fliplr(X); Y = fliplr(Y);
end


% Make the result real

if real_flg == 1
   X = real(X); Y = real(Y);
end


% Check

Eps1 = EE1*X + Y*EE2 - EE3;
Eps2 = AA1*X + Y*AA2 - AA3;
Eps = max(norm(Eps1,1),norm(Eps2,1));
a = punpck(A); b = punpck(B); c = punpck(C);
Nrm = max([norm(a,1),norm(b,1),norm(c,1)]);
Eps = Eps/Nrm;
if Eps > 1e-6
   disp(sprintf('plyap warning: Relative residue %g',Eps));
end
