% lr
%
% Left-to-right conversion. 
%
% Given a square polynomial matrix D and a polynomial matrix N with 
% the same number of rows the command
%
%    [P,Q] = lr(N,D[,tol])
%
% computes a square polynomial matrix Q and a polynomial matrix P
% such that
%
%    D^{-1}*N = P*Q^{-1}
%
% P and Q are right coprime and Q is column reduced.
% The optional parameter tol is a tolerance.

% Huibert Kwakernaak, May, 1997
% Modified by S. Pejchova, June 16, 1997


function [P,Q] = lr(N,D,tol);

% Checks
if nargin < 2
 disp('usage:  [P,Q] = lr(N,D[,tol])');
 return
end
[mattypeN,rN,cN,degN] = pinfo(N);
[mattypeD,rD,cD,degD] = pinfo(D);
if ~strcmp(mattypeN,'poly') | ~strcmp(mattypeD,'poly')
   error('lr: Wrong type of input')
elseif rD ~= rN | rD ~= cD
   error('lr: Inconsistent dimensions of input')
end
   

% Compute the right nullspace of [D -N]

DN = pcoljoin(D,pscl(N,-1));
if nargin == 2
   PQ = axb(DN,0);
else
   PQ = axb(DN,0,tol);
end


% Identify P and Q

P = psel(PQ,1:cD,':');
Q = psel(PQ,cD+1:cD+cN,':');


% Numerical check

E = pmul(DN,PQ);
Eps = norm(punpck(E),1)/norm(punpck(DN),1);
if Eps > 1e-6
   disp(sprintf('lr warning: Relative residue %g',Eps));
end
