%ptrace
%
% Trace of a polynomial matrix
%
% The command
%
%    trA = ptrace(A)
%
% computes the trace of the square polynomial matrix A.

% functions used: pinfo, punpck, ppck 

% S. Pejchova, 1997
% $Revision: 1.1 $       $Date: 1997/06/28 13:05:24 $     $State: Exp $

function trA = ptrace(A)

if nargin ~= 1
   disp('usage: trA = ptrace(A) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if rA~=cA
   error('ptrace: The nput matrix is not square');
end

if isempty(A), trA=[];, return, end
if norm(punpck(A))< eps*1e4, trA=0; return, end
if isnan(degA)|degA==0
   trA=trace(punpck(A));
   return
end
P=punpck(A);
trA=zeros(1,degA+1);
for i=1:degA+1
    trA(i)=trace(P(:,((i-1)*cA+1):i*cA));
end
trA=ppck(trA,degA);

