%axb
%
% The function
%
%  [X0,K] = axb(A,B[,tol][,'minimal'])
%  [X0,K] = axb(A,B[,tol],'res'[,'minimal'])
%  [X0,K] = axb(A,B[,tol],'elo'[,'minimal')
%  [X0,K] = axb(A,B[,tol],'int'[,'minimal'][,degx][,sj[,alpha]])
%
% solves the polynomial matrix equation
%
%   AX = B
%
% where A has r columns.
%
% If only one output argument X0 is present then the macro computes 
% only a particular solution. If B is a zero matrix then the columns
% of this solution form a minimal polynomial basis for the right null 
% space of A. If no polynomial solution exists then  X0 = [].
%
% If both output arguments are present then a polynomial basis for 
% the right null space of A is computed and returned as K. All 
% possible solutions to AX = B may be parametrized as
% 
%    X = X0 + KT
%
% where T is an arbitrary polynomial matrix of compatible dimensions.
% If A has full column rank, then K = [].
%
% The optional parameter tol allows to specify the tolerance used to
% decide whether a solution exists or not and to decide whether the
% rows of A are linearly dependent or not. If tol is negative then it 
% takes its default value.
%
% The string 'res' indicates that the solution is computed by the
% resultant method. This is the default method.
%
% The string 'elo' indicates that elementary row operations are used.
%
% The string 'int' means that the solution is computed via polynomial 
% interpolation. In this case the optional input argument degx is 
% the expected degree of X0; sj is a vector containing k distinct 
% interpolation points, and alpha contains k nonzero vectors, each
% with length rA. The minimum number of interpolation points is 
% k = sum(di)+rA(degx+1), where di are row degrees of A. If degx, sj
% or alpha is missing then the  program uses simple formulas for their
% constructions.
%
% If the option 'minimal' is present then the function minimizes the 
% degrees of several down-most rows in X0.
%
% The routine axb is the dual of xab. 

% functions used: xab, ptransp

% COPYRIGHT S. Pejchova, D. Henrion, M. Sebek 1997
% $Revision: 1.1 $      $Date: 1997/06/09 13:03:08 $    $State: Exp $

function [X0,K] = xab(A,B,arg3,arg4,arg5,arg6,arg7,arg8)

method='res'; test1=0; tol=-1; minim=0; argm=[];
if nargin<2
   test1=1;
elseif isstr(A) | isstr(B)
   test1=1;
elseif nargin > 2
   if ~isstr(arg3)
      if length(arg3)==1, tol=arg3;
      else, test1=1;
      end
   end
   for i=3:min([5,nargin])
       stg=['arga=arg',int2str(i),';'];
       eval(stg);
       if strcmp(arga,'elo'), method='elo'; argm=i;
       elseif strcmp(arga,'int'), method='int'; argm=i;
       elseif strcmp(arga,'res'), argm=i;
       elseif strcmp(arga,'minimal'), minim=1; argm=i;
       elseif isstr(arga), test1=1;
       end
   end
end 
if test1
 disp('usage: [X0,K] = axb(A,B[,tol]) ');
 disp('   or: [X0,K] = axb(A,B[,tol],''res''[,''minimal'']) ');
 disp('   or: [X0,K] = axb(A,B[,tol],''elo''[,''minimal'')  ');
 disp('   or: [X0,K] = axb(A,B[,tol],''int''[,''minimal''][,degx][,sj][,alpha])');
 return
end

strout=['=xab(ptransp(A),ptransp(B),tol,method'];
if minim, strout=[strout,',''minimal''']; end
if ~isempty(argm)
   if nargin>argm
     for i=argm+1:nargin
       strout=[strout,',arg',int2str(i)];
     end
   end
end
strout=[strout,');'];
if nargout==2
   strout=['[XT,KT]',strout];
else
   strout=['XT',strout];
end
eval(strout,'error(lasterr)');
X0=ptransp(XT);
if nargout==2
   K=ptransp(KT);
end
