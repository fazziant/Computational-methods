%demo3a
%
% Solution of a SISO LQG problem with the macro plqg

% H. Kwakernaak, June, 1997

disp('Demo 3: Solution of the SISO LQG problem')

% Define the problem

n1 = ppck([10004 4 1],2); n2 = ppck([90036 12 1],2); n = pmul(n1,n2);
d1 = ppck([0 0 1],2); d2 = ppck([2501 2 1],2); 
d3 = ppck([22509 6 1],2); d = pmul(d1,d2,d3);


% Scale the polynomials

d = pscale(d,1/100); n = pscale(n,1/100);
[degd,dd] = pdegco(d); 
d = pscl(d,1/dd); n = pscl(n,1/dd);

p = n; q = n;
rho = 1; mu = 1e-6;


% Solve the LQG problem

[y,x,regpoles,obspoles] = plqg(d,n,p,q,rho,mu);


% Plot the closed-loop step response

phi = padd(pmul(d,x),pmul(n,y));
Z = pval(phi,0)/pval(n,0); nZ = pmul(n,Z);
figure(2), step(punpckv(nZ,'rrow'),punpckv(phi,'rrow')), grid