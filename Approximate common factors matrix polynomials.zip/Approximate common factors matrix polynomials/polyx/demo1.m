%demo1
%
% Pole assignment demo

% H. Kwakernaak, June, 1997

disp('Demo 1: Solution of a SISO pole assignment problem')

% Define d, n and phi

d = ppck([0 0 1],2); n = 1;
r = (-1+sqrt(-1))/sqrt(2); 
phi = real(poly([r r' 10*r 10*r']));
phi = ppck(fliplr(phi),4); 


% Solve for x and y with y of minimal degree

[x,y] = axbyc(d,n,phi,'minimal');


% Compute and plot the sensitivity functions

omega = logspace(-2,2); j = sqrt(-1);
dx = pmul(d,x); ny = pmul(n,y);
numS = pval(dx,j*omega); numT = pval(ny,j*omega); Phi = pval(phi,j*omega);
S = numS./Phi; T = numT./Phi;
figure(1)
loglog(omega,abs(S),'c'); hold on
loglog(omega,abs(T),'y'); grid on
xlabel('omega')


% Plot the closed-loop step response

Z = pval(phi,0)/pval(n,0); nZ = pmul(n,Z);
figure(2), step(punpckv(nZ,'rrow'),punpckv(phi,'rrow')), grid