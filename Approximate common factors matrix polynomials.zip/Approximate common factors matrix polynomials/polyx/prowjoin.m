%prowjoin
%
% Join two polynomial matrices rowwise
%
% The command
%
%    P = prowjoin(P1,P2)
%
% results in the polynomial matrix P given by
%
%    P = [ P1 |
%        | P2 ]

% $Revision: 1.3 $	$Date: 1996/07/19 09:24:13 $	$State: Exp $

function P = prowjoin(P1,P2)

if nargin ~= 2
   disp('usage: P = prowjoin(P1,P2)')
   return
end

[typeP1,rP1,cP1,degP1] = pinfo(P1);
[typeP2,rP2,cP2,degP2] = pinfo(P2);

if typeP1 == 'poly' | typeP2 == 'poly'
   P1 = punpck(P1);
   P2 = punpck(P2);
   if isempty(P1)
      P = P2;
      degP = degP2;
   elseif isempty(P2)
      P = P1;
      degP = degP1;
   else
      if isnan(degP1)
	 degP1 = 0;
      end
      if isnan(degP2)
	 degP2 = 0;
      end
      if cP1 ~= cP2
         error('prowjoin: `The input matrices have different numbers of columns');
      end
      rP = rP1+rP2; cP = cP1;
      if degP1 == -Inf
	 degP1 = 0;
      end
      if degP2 == -Inf;
	 degP2 = 0;
      end
      if degP1 >= degP2
         degP = degP1;
      else
         degP = degP2;
      end
   
      P(1:rP1,1:(degP1+1)*cP1) = P1;
      P(rP1+1:rP,1:(degP2+1)*cP2) = P2;
   end
   P = ppck(P,degP);
else
   P = [ P1 ; P2];
end
