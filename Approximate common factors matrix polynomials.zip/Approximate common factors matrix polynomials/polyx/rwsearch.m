% rwsearch
%
% Row-searching algorithm by column Householder transformations
% to extract the left null-space basis of a constant matrix.
%
% Given a m-by-n constant matrix A, the function 
%
%   [D, dpr] = rwsearch(A[,tol])
%
% returns the unique q-by-n matrix D in row-echelon form such that 
% D*A = 0.
%
% D consists of q rows containing the coefficients of dependency of
% the rows of A. Hence, D' is a basis for the left kernel of A and 
% q is the algorithm's idea of the nullity of A.
%  
% The output argument dpr is a q-by-1 vector containing the indices 
% of the dependent rows of A.
%
% The optional tolerance tol, with default value max(size(A))*norm(A)*1e6*eps),
% is used to decide whether a row is linearly dependent or not.

% Henrion D. 4-96
% Modified by S. Pejchova, June 26, 1997

function [D,dpr] = rwsearch(A,tol)

if nargin < 1
 disp('usage:  [D,dpr] = rwsearch(A[,tol])');
 return
end
D = []; dpr = [];
[m, n] = size(A);

if nargin < 2,
  tol = -1;
end;

if tol < 0,
  tol = max(size(A))*norm(A)*1e6*eps;
end;

if rank(A,tol) < m,

 idpr = []; % independent rows indices
 ndpr = 0; % number of dependent rows
 nidpr = 0; % number of independent rows

 j = 1; dep = 0;
 Al = A;
 for i = 1:m,

  % first row = Householder vector

  if ~dep,
    row = Al(1, :); l = length(row);
    mu = norm(row);
  end;

  if ~dep & (mu > tol), % non zero row

    if l > 1,
      r = row(1);
      if abs(r) < tol, % partial column pivoting
        [void, i1] = max(abs(row)); i1 = i1(1);
        col = Al(:, i1); Al(:, i1) = Al(:, 1); Al(:, 1) = col;
        r = row(i1); row(i1) = row(1);
      end;
      beta = r + sign(r) * mu;
      v = 1; v(2:l) = row(2:l) / beta;

      % Householder transformation : zeroes the row but its first component 
      beta = -2/(v*v');
      w = beta * Al * v';
      A(i:m, j:n) = Al + w * v;
    end;

    nidpr = nidpr + 1;
    idpr(nidpr) = i; % new independent row
    j = j + 1;

  else % new dependent row

    ndpr = ndpr + 1;
    % triangular LSE
    D(ndpr, m) = 0; % consistent size
    D(ndpr, [idpr i]) = [-A(i, 1:nidpr) / A(idpr, 1:nidpr) 1];
    dpr(ndpr, 1) = i; % row index

  end;

  if j <= n,
    Al = A(i+1:m, j:n); % new submatrix
  else
    dep = 1; % the following rows (only scalars) are dependent
  end;

 end; % for i

end; % if rank A

