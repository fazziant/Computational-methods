%ptransp
%
% Transpose of a polynomial matrix
%
% The function call
%
%    P = ptransp(Q)
%
% produces the transpose P of the polynomial matrix Q.

% $Revision: 1.0 $	$Date: 1995/04/21 14:22:32 $	$State: Exp $

function P = ptransp(Q)

if nargin ~= 1
   disp('usage: P = ptransp(Q)')
   return
end

[typeQ,rQ,cQ,degQ] = pinfo(Q);

if typeQ == 'poly'
   Q = punpck(Q);
   degP = degQ;
   if isempty(Q)
      P = Q;
   else
      rP = cQ; cP = rQ;
      P = zeros(rP,(degP+1)*cP);
      for i = 1:max(0,degP)+1
         P(:,(i-1)*cP+1:i*cP) = Q(:,(i-1)*cQ+1:i*cQ)';
      end
   end
   P = ppck(P,degP);
else
   P = Q';
end
