%matplot
%
% The command
%
%    f = matplot(A)
%
% creates a 2-D graphics object from the polynomial matrix A.
% The color of each cell corresponds to the degree of the 
% corresponding entry of A.

% function used: pinfo, pdegco

% COPYRIGHT S. Pejchova, M. Sebek 1996
% $Revision: 1.1 $      $Date: 1996/09/27 14:30:00 $    $State: Exp $

function f = matplot(A)

if nargin~=1
   disp('usage: f = matplot(A) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if isempty(A)
   disp('matplot: Input matrix is empty ');
   return
end
if isnan(degA)|isinf(degA), degA=0;, end

[DEGA,LCA]=pdegco(A,'ent');
Xo=[cA-1:-1:0; cA-1:-1:0; cA:-1:1; cA:-1:1];
Yo=[zeros(1,cA); ones(2,cA); zeros(1,cA)];
X=Xo;, Y=Yo;
if rA > 1
   for i=1:rA-1
       X=[X, Xo];
       Y=[Y, i*ones(4,cA)+Yo];
   end
end

Zau=(fliplr(DEGA))';, Zo=(Zau(:))';
I=isinf(Zo);
if isempty(I)==0
   Zo(:,I)=[];
   X(:,I)=[];
   Y(:,I)=[];
end
if isempty(Zo)
   Z=[];, Zm=0;
else
   Zm=max(abs(Zo));
   if Zm~=0, Zo=Zo/Zm;, end
   Z=[Zo ; Zo; Zo; Zo];
end

clf;
axes('position',[.1 .1 .8 .1]);
x=[0:Zm+1; 0:Zm+1];
y=[zeros(1,Zm+2); 0.3*ones(1,Zm+2)];
if Zm~=0
   Cc=[0:(1/Zm):1, 1; 0:(1/Zm):1, 1];
else
   Cc=zeros(2);
end
pcolor(x,y,Cc);
xlabel('Degrees of leading coefficients');
colormap(cool);
axes('position',[.1 .3 .8 .6]);
Xr=[1:cA, zeros(1,rA); 1:cA, cA*ones(1,rA)];
Yr=[zeros(1,cA), 0:rA-1; rA*ones(1,cA), 0:rA-1];
plot(Xr,Yr,'w-');
ylabel('ROWS');
xlabel('COLUMNS');
axis('ij');
axis(axis);
hold on;
if isempty(Z)==0
   fill(X,Y,Z);
end
hold off
