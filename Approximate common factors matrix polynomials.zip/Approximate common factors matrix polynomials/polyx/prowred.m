%prowred
%
% Row reduced form of a polynomial matrix
%
%
% The function 
%
%    [D,U,UI,residue] = prowred(A[,'z'][,tol])
%
% brings a polynomial matrix A into row reduced form D by 
% elementary row operations such that D = U*A. U is a square 
% unimodular transformation matrix. The rows of D are arranged 
% according to descending degree. If the input matrix A does 
% not have full row rank then it is reduced to the form  
%
%   D = [ D~ | 
%       | 0  ]
%
% with D~ row reduced.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero') and in determining the rank of the leading 
% coefficient matrix. The default value of the tolerance tol is 
% computed from the degree and sizes of A. If 'z' and tol are 
% missing then the macro runs without "zeroing".
%
% The inverse matrix  UI of V is also computed.
%
% The output argument residue is the relative residue of calculation.

% functions used: pcolred, ptransp

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.4 $      $Date: 1997/04/08 10:17:02 $    $State: Exp $

function [D,U,UI,residue] = prowred(A,arg2,arg3)

test1=0;
if nargin==0
   test1=1;
elseif isstr(A)   
   test1=1;
end
if  test1
   disp('usage: [D,U,UI,residue] = prowred(A,''z''tol)')
   return
end
AT=ptransp(A);
stg='[DAT,UAT,UIAT,residue]=pcolred(AT';
stg1=[];
if nargin > 1
   for i=2:nargin
       stg1=[stg1,',arg',int2str(i)];
   end
end
stg=[stg,stg1,');'];
eval(stg);

D=ptransp(DAT);
U=ptransp(UAT);
UI=ptransp(UIAT);


