% rl
%
% Right-to-left conversion. 
%
% Given a square polynomial matrix D and a polynomial matrix N 
% with the same number of columns the command
%
%    [P,Q] = rl(N,D[,tol])
%
% computes a square polynomial matrix Q and a polynomial matrix P
% such that
%
%    N*D^{-1} = Q^{-1}*P
%
% with P and Q right coprime.
%
% If N*D^{-1} is proper and D row reduced then Q is column reduced.
% The optional parameter tol is a tolerance.

% Huibert Kwakernaak, May, 1997
% Modified by S. Pejchova, June 26, 1997


function [P,Q] = rl(N,D,tol);


% Checks
if nargin < 2
 disp('usage:  [P,Q] = rl(N,D[,tol])');
 return
end
[mattypeN,rN,cN,degN] = pinfo(N);
[mattypeD,rD,cD,degD] = pinfo(D);
if ~strcmp(mattypeN,'poly') | ~strcmp(mattypeD,'poly')
   error('rl: Wrong type of input')
elseif cD ~= cN | rD ~= cD
   error('rl: Inconsistent dimensions of input')
end
   

% Compute the left nullspace of [  D
%                                 -N ]

DN = prowjoin(D,pscl(N,-1));
if nargin == 2
   PQ = xab(DN,0);
else
   PQ = xab(DN,0,tol);
end


% Identify P and Q

P = psel(PQ,':',1:rD);
Q = psel(PQ,':',rD+1:rD+rN);


% Numerical check


E = pmul(PQ,DN);
Eps = norm(punpck(E),1)/norm(punpck(DN),1);
if Eps > 1e-6
   disp(sprintf('rl warning: Relative residue %g',Eps));
end
