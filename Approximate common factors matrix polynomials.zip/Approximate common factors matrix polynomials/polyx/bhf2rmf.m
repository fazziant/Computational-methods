% bhf2rmf
%
%    [N,D] = bhf2rmf(F,G,H,bsizes)
%
% This macro obtains a right coprime matrix fraction description of a 
% minimal state-space realization (A,B,C) in upper block Hessenberg 
% form. Use the macro bhf.m first to bring any observable state-space 
% realization in the appropriate upper block Hessenberg form.
%

% Rens C.W. Strijbos, 1996
% Modified by S. Pejchova, June 26, 1997
% $Revision: 1.1 $	$Date: 1995/08/21 10:16:24 $	$State: Exp $

function [N,D] = bhf2rmf(F,G,H,bsizes)

% Initialisation of variables

if nargin~=4
 disp('usage:  [N,D] = bhf2rmf(F,G,H,bsizes)');
 return
end
[rG,cG]=size(G);
[rH,cH]=size(H);
mu=length(bsizes);
[Gtemp,T,rankG]=hhr(G);

% Begin Main Loop Here 

V=zeros(rG,cG*mu);
cumbsizes=cumsum(bsizes);
Vstart=bsizes(mu);
Vtemp = [eye(bsizes(mu)) zeros(bsizes(mu),cG-bsizes(mu))];	% Assign V_mu
iter=1;
while iter <= mu
   dmu = mu -iter;
   if dmu == 0
      rowstart = 1;
   else
      rowstart = cumbsizes(dmu)+1;
   end
   rowend = cumbsizes(dmu+1);
   V(rowstart:rowend,1:cG*iter) = Vtemp;
   RHS = [zeros(bsizes(dmu+1),cG) Vtemp];
   RHS = ppck(RHS,iter);
   for k = 1 : iter
      if k<mu
	 colstart = cumbsizes(mu-k)+1;
      else
	 colstart = 1;
      end
      colend = cumbsizes(mu+1-k);
      Ftemp = F(rowstart:rowend,colstart:colend);
      Vtemp = ppck(V(colstart:colend,1:cG*iter),iter-1);
      RHS = psub(RHS,pmul(Ftemp,Vtemp));
   end
   RHS = punpck(RHS);
   if dmu ~= 0
      if dmu == 1
         colstart = 1;
      else
         colstart = cumbsizes(dmu-1)+1;
      end
      colend = cumbsizes(dmu);
      offset = bsizes(dmu)-bsizes(dmu+1);
      Ftemp = F(rowstart:rowend,colstart+offset:colend);
   else
      offset = cG-rankG;
      Ftemp = Gtemp(1:rankG,cG-rankG+1:cG);
   end
   Vtemp = [];
   if dmu ~= 0
      kstart = bsizes(dmu+1);
   else
      kstart = rankG;
   end
   for k = kstart : -1 : 1
      Vkk = zeros(1,cG*(1+iter));
      for kk = k+1 : kstart
	 Vkk = Vkk + Ftemp(k,kk) * Vtemp(kk-k,:);
      end
      Vtemp = [(RHS(k,:) - Vkk)/Ftemp(k,k) ; Vtemp];
   end
   for k = offset:-1:1
      Vkk = zeros(1,cG*(1+iter));
      Vkk(1,Vstart+k)=1;
      Vtemp = [ Vkk ; Vtemp];
   end
   iter = iter + 1;
   Vstart=Vstart+offset;
end

%End main Loop
   
D = ppck(Vtemp,mu);
D = pmul(T,D);
V=ppck(V,mu-1);
N=pmul(H,V);
