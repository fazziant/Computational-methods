% Polynomial Toolbox
% Version 1.5   30-June-97
% Copyright (c) 1997 by the Polynomial Toolbox Team
% Didier Henrion, Ferda Kraffer, Huibert Kwakernaak, 
% Sonja Pejchov�, Michael Sebek, Rens C. W. Strijbos
%
% Basic operations    
%   adj        - Adjoint of a polynomial matrix
%   cjg        - Conjugate of a polynomial matrix
%   dcjg       - Discrete-time conjugate of a polynomial matrix
%   padd       - Addition of polynomial matrices
%   pkron      - Kronecker product of polynomial matrices
%   pmul       - Multiplication of polynomial matrices
%   pscl       - Multiplication of a polynomial matrix by a scalar
%   pshift     - Modification of the degree of a polynomial matrix
%   psub       - Subtraction of polynomial matrices
%   ptransp    - Transpose a polynomial matrix
%
% Canonical and reduced forms
%   echelon    - Polynomial echelon form of a polynomial matrix
%   hermite    - Hermite form of a polynomial matrix
%   pcolred    - Column reduced form of a polynomial matrix
%   pdg        - Diagonal form of a polynomial matrix
%   pdiagred   - Diagonally reduced form of a para-Hermitian 
%                polynomial matrix
%   prowred    - Row reduced form of a polynomial matrix
%   pstairs    - Staircase triangular form of a polynomial matrix
%   pstairso   - Ordered staircase triangular form 
%   smith      - Smith form of a polynomial matrix
%
% Control routines
%   mixed      - Solution of a SISO mixed sensitivity problem
%   plqg       - Polynomial solution of SISO LQG problems
%
% Discrete-time routines
%   dcjg       - Discrete-time conjugate of a polynomial matrix
%   dphsym     - Discrete-time para-Hermitian polynomial matrix
%   dpsf       - Discrete-time matrix spectral factorization
%   pschur     - Test if a polynomial matrix is Schur
%
% Equation solvers
%   axb        - Solution of the matrix polynomial equation AX = B
%   axbc       - Matrix polynomial equation AXB = C
%   axbyc      - Matrix polynomial equation AX + BY = C
%   axxa2b     - Symmetric polynomial matrix equation A*X + X*A = 2B
%   axya2b     - Scalar polynomial equation a*x + y*a = 2b
%   axybc      - Matrix polynomial equation AX + YB = C
%   daxxa2b    - Discrete-time matrix equation A*X + X*A = B
%   daxya2b    - Discrete-time scalar equation a*x + y*a = bl* + br
%   xab        - Matrix polynomial equation XA = B
%   xaybc      - Matrix polynomial equation XA + YB = C
%
% Factorizations
%   dpsf       - Discrete-time matrix spectral factorization
%   pjsf       - Polynomial matrix J-spectral factorization
%
% Handling polynomial matrices
%   graphobj   - Ancillary routine for matplot and matplot3
%   matplot    - Create a 2-D graphic object from a polynomial matrix
%   matplot3   - Create a 3-D graphic object from a polynomial matrix
%   p2sym      - Conversion of a polynomial matrix of the Polynomial 
%                Toolbox into a symbolic matrix of the Symbolic 
%                Toolbox
%   pcoljoin   - Join polynomial matrices columnwise
%   pdegco     - Various degrees and corresponding leading coefficient 
%                matrices
%   pdp        - Print polynomial matrix on screen in symbolic form
%   pinfo      - Provide matrix information
%   ppck       - Convert constant to polynomial matrix
%   pput       - Substitute specified entries of polynomial matrix 
%                by entries of another polynomial matrix
%   prowjoin   - Join polynomial matrices rowwise
%   psel       - Select specified rows and columns
%   pshow      - Print a polynomial matrix on screen in a well-
%                arranged form
%   psort      - Sort columns of polynomial matrix in descending 
%                order of column degrees
%   punpck     - Unpack polynomial matrix
%   punpckv    - Convert a polynomial matrix to a regular matrix 
%                arranged in various ways
%   sym2p      - Conversion of a symbolic matrix of the Symbolic 
%                Toolbox into a polynomial matrix of the Polynomial 
%                Toolbox
%
% Matrix pencil routines
%   pencan     - Transformation of a nonsingular matrix pencil to 
%                Kronecker canonical form
%   plyap      - Solution of a two-sided equation with matrix pencil 
%                coefficients
%
% Modeling functions
%   lmf2ss     - Observer-form realization of a left matrix 
%                fraction description
%   rmf2ss     - Controller-form realization of a right matrix 
%                fraction description
%   ss2lmf     - Left coprime polynomial matrix fraction 
%                representation of a state space system
%   ss2rmf     - Right coprime polynomial matrix fraction 
%                representation of a state space system
%
% Numerical routines
%   bhf        - Convert the controllable part of a state space 
%                realization to upper block Hessenberg form
%   bhf2rmf    - Obtain a right coprime polynomial matrix fraction 
%                description of a minimal state-space realization 
%                in upper block Hessenberg form
%   blcomp     - Block companion matrix
%   cgivens1   - Complex Givens rotation
%   hhl        - Householder transformation from the left 
%   hhr        - Householder transformation from the right
%   newtpol    - Newton representation of a polynomial
%   pinterp    - Interpolation of polynomial matrices
%   presult    - Sylvester resultant matrix of a polynomial matrix
%   qzord      - Ordered QZ transformation
%   rwsearch   - Left null-space of a constant matrix
%   schurst    - Ordered Schur decomposition
%
% Polynomial division and divisors
%   exfac      - Extraction of a given factor from a polynomial matrix
%   gld        - Greatest left divisor of polynomial matrices
%   grd        - Greatest right divisor of polynomial matrices
%   lr         - Left-to-right conversion of a polynomial matrix 
%                fraction
%   pdiv       - Polynomial matrix division
%   rl         - Right-to-left conversion of a polynomial matrix 
%                fraction
%
% Roots, determinant and trace
%   pdet       - Determinant of a square polynomial matrix
%   proots     - Roots of a square polynomial matrix
%   ptrace     - Trace of a square polynomial matrix
%
% Useful functions
%   pdiag      - Diagonals of a polynomial matrix and diagonal 
%                polynomial matrices
%   phsym      - Para-Hermitian polynomial matrix
%   phurwitz   - Test if a polynomial matrix is Hurwitz
%   pmax       - Maximum scalar coefficient
%   pmin       - Minimum nonzero scalar coefficient
%   prandm     - Random polynomial matrix with integer coefficients
%   prank      - Rank of a polynomial matrix
%   pscale     - Scale a polynomial matrix
%   pschur     - Test if a polynomial matrix is Schur
%   psing      - Test the singularity of a polynomial matrix
%   pval       - Polynomial matrix evaluation
%   pzero      - Set small scalar coefficients of a polynomial 
%                matrix equal to zero
