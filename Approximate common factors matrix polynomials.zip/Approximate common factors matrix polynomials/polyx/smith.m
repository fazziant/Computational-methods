%smith
%
% Computation of the Smith form of a polynomial matrix
%
% The command
%
%    [S,U,V,UI,VI] = smith(A[,'z'][,tol][,'menu'][,'movie'])
%
% uses elementary operations to convert the polynomial matrix A to 
% its Smith form
%
%                    [ a11   0  ... ... ...  0  |
%                    |  0   a22 ... ... ...  0  |
%        S = U*A*V = | ...  ... ... ... ... ... |
%                    |  0    0  ... arr ... ... |
%                    | ...  ... ... ...  0  ... |
%                    |  0.  ... ... ... ... ... ]
%
% U and V are unimodular transformation matrices and r is the 
% rank of A. The polynomial a(k,k) divides a(k+1,k+1) for 
% k = 1, 2, .., r-1.
%
% The inverse matrices UI=U^(-1) and VI=V^(-1) are also computed.
%
% The input arguments 'z' and tol are used in "zeroing" (see the
% function 'pzero'). The default value of the tolerance tol is 
% computed from the degree and sizes of A. If 'z' and tol are missing
% then the macro runs without "zeroing". THE USE OF ZEROING IS 
% STRONGLY RECOMMENDED!!!
%
% The fourth argument 'menu' allows to select and control the next
% step of the reduction.
%
% The fifth argument allows to create a 2-D or 3-D graphics object
% from the reduced matrix.

% functions used: pinfo, punpck, ppck, pdegco, psel, pmul, pscl, gld
%                pput, pzero, matplot, matplot3

% COPYRIGHT S. Pejchova, M. Sebek 1997
% $Revision: 1.2 $      $Date: 1997/01/29 09:45:17 $    $State: Exp $

function [S,U,V,UI,VI] = smith(A,arg2,arg3,arg4,arg5)

menu1=0;, mov1=0;, test1=0;, tol=eps;, step_plot=[0 0 0];
zeroing=0;

if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'menu')
             menu1=1;
          elseif strcmp(argm,'movie')
             mov1=1;
          elseif strcmp(argm,'z')
             if zeroing==0, zeroing=2; end          
          else
             test1=1;
          end
       elseif length(argm)==1
          tol=argm; zeroing=1;
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: [S,U,V,UI,VI] = smith(A,''z'',tol,''menu'',''movie'') ');
   disp('THE USE OF ZEROING IS STRONGLY RECOMMENDED!!! ');
   return
end
[typeA,rA,cA,degA]=pinfo(A);
if isempty(A) | isinf(degA)
   S=A;
   U=ppck(eye(rA),0);, UI=U;
   V=ppck(eye(cA),0);, VI=V;
   return
end
if isnan(degA)
   degA=0;, A=ppck(A,degA);
end

U=ppck(eye(rA),0);, UI=U;
V=ppck(eye(cA),0);, VI=V;

if degA < 0
   S=A;, degS=degA;
else
   S=ppck(A(1:rA,1:(1+degA)*cA),degA);      %'clearing'
end
[typeS,rS,cS,degS]=pinfo(S);
if isinf(degS)
   if strcmp(typeA,'cons')
      S=punpck(S);, U=punpck(U);, UI=punpck(UI);
      V=punpck(V);, VI=punpck(VI);
   end
   return
end
degofdet=degS*(min(rS,cS));
NormS=norm(punpck(S));
S=pscl(S,1/NormS);
if zeroing==2
   tol=norm(punpck(S))*(max(size(punpck(S))))*eps*1e2;
elseif zeroing==1
   tol=tol/NormS;
end
[DS,LS]=pdegco(S,'ent');
if mov1
  step_plot(2)=menu('Type of Graphic Object','2-Dimensional Object',...
           '3-Dimensional Object');
end
[menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,S);
if step_plot(1)>10, return, end

loop=3*2*rS*(degS+1);
lu=0;
n=min(rS,cS);

if n >= 1
   i=1;
   while i<=n                               % reduction of i-row and i-column
          xcol=0;, xrow=0;
          if cS>i & (max(DS(i,i+1:cS))>=0)
             xcol=1;
          end
          if rS>i & (max(DS(i+1:rS,i))>=0)
             xrow=1;
          end

          while (xcol | xrow) & (lu<loop)
             TU=ppck(eye(rS),0);, TUI=TU;   % reduction to down
             TV=ppck(eye(cS),0);, TVI=TV;   % reduction to the right
             Min=min(min(abs(DS(i:rS,i:cS))));
             [I,J]=find(DS(i:rS,i:cS)==Min);
             if length(I) >1
                LSmat=LS(i:rS,i:cS);
                LSv=LSmat(I(1),J(1));
                for t=2:length(I), LSv=[LSv,LSmat(I(t),J(t))];, end
                [M,l]=max(abs(LSv));
                ki=I(l(1))+i-1;             % pivot
                kj=J(l(1))+i-1;
             else
                ki=I+i-1;
                kj=J+i-1;
             end
             if (ki==i) & (kj==i)
                if isinf(DS(i,i))==0
                   ar=fliplr(punpck(psel(S,i,i)));
                   if rS > i
                      for row=i+1:rS
                          if isinf(DS(row,i))==0
                             br=fliplr(punpck(psel(S,row,i)));
                             [qr,rr]=deconv(br,ar);
                             if zeroing > 0
                                q=pzero(qr(length(qr):-1:1),tol);
                             else
                                q=qr(length(qr):-1:1);
                             end
                             TU=pput(TU,row,i,ppck(-q,length(q)-1));
                             TUI=pput(TUI,row,i,ppck(q,length(q)-1));
                          end
                      end
                   end
                   if cS > i
                      for col=i+1:cS
                          if isinf(DS(i,col))==0
                             cr=fliplr(punpck(psel(S,i,col)));
                             [sr,rr]=deconv(cr,ar);
                             if zeroing > 0
                                s=pzero(sr(length(sr):-1:1),tol);
                             else
                                s=sr(length(sr):-1:1);
                             end
                             TV=pput(TV,i,col,ppck(-s,length(s)-1));
                             TVI=pput(TVI,i,col,ppck(s,length(s)-1));
                          end
                      end
                   end
                end
             
             else
                if ki~=i
                   TUI=pput(TU,[ki,i],[ki,i],[0,-1; 1,0]);
                   TU=pput(TU,[ki,i],[ki,i],[0,1; -1,0]);
                end
                if kj~=i
                   TVI=pput(TV,[i,kj],[i,kj],[0,-1; 1,0]);
                   TV=pput(TV,[i,kj],[i,kj],[0,1; -1,0]);
                end

             end
             if zeroing > 0
                U=pmul(TU,U,'z',tol); V=pmul(V,TV,'z',tol);
                UI=pmul(UI,TUI,'z',tol); VI=pmul(TVI,VI,'z',tol);
                S=pmul(TU,S,TV,'z',tol);
             else
                U=pmul(TU,U); V=pmul(V,TV);
                UI=pmul(UI,TUI); VI=pmul(TVI,VI);             
                S=pmul(TU,S,TV);
             end
             [DS,LS]=pdegco(S,'ent');

             if (ki==i) & (kj==i)
                degS=pdegco(S);
                if cS>i
                   frow=find(DS(i,i+1:cS)>=DS(i,i));
                   if isempty(frow)==0
                      frow=frow+i*ones(1,length(frow));
                      for m=frow
                          mm=(DS(i,i)*cS+m):cS:(degS+1)*cS;
                          S(i,mm)=zeros(1,length(mm));
                      end
                   end
                end
                if rS>i
                   fcol=find(DS(i+1:rS,i)>=DS(i,i));
                   if isempty(fcol)==0
                      nn=(DS(i,i)*cS+i):cS:(degS*cS+i);
                      S(i+1:rS,nn)=zeros(rS-i,length(nn));
                   end
                end
                S=ppck(punpck(S),degS);
                [DS,LS]=pdegco(S,'ent');
             end  %(if k==i)
             lu=lu+1;

             if rS>i &(max(DS(i+1:rS,i))>=0)
                xrow=1;
             else
                xrow=0;
             end
             if cS>i & (max(DS(i,i+1:cS))>=0)
                xcol=1;
             else
                xcol=0;
             end
          [menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,S); 
          if step_plot(1)>10, return, end

          end  %(while lu<loop)
          if i > 1
             u=psel(S,i-1,i-1);
             ur=fliplr(punpck(u));
             w=psel(S,i,i);
             wr=fliplr(punpck(w));
             if norm(ur,inf) > tol
                [ddr,rrr]=deconv(wr,ur);
                if norm(rrr,inf) > tol
                   [g,W]=gld(u,w);
                   p=psel(W,1,1);
                   Z=pput([0,1;1,0],1,1,p);
                   ZI=pput([0,1;1,0],2,2,pscl(p,-1));

                   TU=pput(eye(rS),[i-1,i],[i-1,i],Z);
                   TUI=pput(eye(rS),[i-1,i],[i-1,i],ZI);
                   q=psel(W,2,1);
                   TV=pput(eye(cS),i,i-1,q);
                   TVI=pput(eye(cS),i,i-1,pscl(q,-1));
                   if zeroing > 0
                      U=pmul(TU,U,'z',tol); V=pmul(V,TV,'z',tol);
                      UI=pmul(UI,TUI,'z',tol); VI=pmul(TVI,VI,'z',tol);
                      S=pmul(TU,S,TV,'z',tol);
                   else
                      U=pmul(TU,U); V=pmul(V,TV);
                      UI=pmul(UI,TUI); VI=pmul(TVI,VI);             
                      S=pmul(TU,S,TV);
                   end
                   S=pput(S,i-1,i-1,g);
                   [DS,LS]=pdegco(S,'ent');
                   i=i-2;
                end %(if norm(rrr))
             end %(if norm(ur)
          end %(if i>1)
          i=i+1;
          [menu1,mov1,step_plot]=graphobj(menu1,mov1,step_plot,S);
          if step_plot(1)>10, return, end
   end  %(while i<=n)
end  %(if n>1)
if lu>=loop
   disp('smith warning: Diagonalization interrupted');
end
if zeroing > 0, S=pzero(S,tol); end
DS=pdegco(S,'ent');
S=pscl(S,NormS);
Res=(norm(punpck(psub(S,pmul(U,A,V)))))/NormS;
if Res > tol*1e6
   disp(' ');
   disp(sprintf('smith warning: The relative residue of calculation is  %g',Res));
   disp('                Try to change the tolerance.');
else
   degdiaS=diag(DS);
   degdiaS=sum(degdiaS);
   if degdiaS > degofdet
      disp(' ');
      disp('smith warning: The resulting degree may not be correct!');
      disp('               Try to change the tolerance.');
   end
end
if strcmp(typeA,'cons')
   [typeS,rS,cS,degS]=pinfo(S);
   [typeU,rU,cU,degU]=pinfo(U);
   [typeUI,rUI,cUI,degUI]=pinfo(UI);
   [typeV,rV,cV,degV]=pinfo(V);
   [typeVI,rVI,cVI,degVI]=pinfo(VI);
   if degS <= 0, S=punpck(S);, end
   if degU <= 0, U=punpck(U);, end
   if degUI <= 0, UI=punpck(UI);, end
   if degV <= 0, V=punpck(V);, end
   if degVI <= 0, VI=punpck(VI);, end
end
