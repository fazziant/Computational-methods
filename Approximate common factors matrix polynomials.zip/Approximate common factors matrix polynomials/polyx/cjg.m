% cjg
%
% The function 
%
%   Astar = cjg(A)
%
% returns the conjugate A*(s) = A'(-s) of the polynomial matrix A.
% If the input matrix is a regular Matlab matrix then Astar = A'.

% Henrion D. 2-96
% Modified by S. Pejchova, June 26, 1997
% functions used : pinfo, ppck, pdegco
% $Revision: 1.4 $	$Date: 1996/10/07 06:46:24 $	$State: Exp $

function Astar = cjg(A)

if nargin~=1
 disp('usage:  Astar = cjg(A)');
 return
end
[typeA, rA, cA, degA] = pinfo(A);

if (typeA == 'empt')
  Astar = [];
elseif (typeA == 'cons'),
  Astar = A';
elseif isinf(degA),
  Astar = ppck(punpck(A)', 0);
else
 
  Astar = [];
  for i = 0:degA,
    Astar = [Astar (-1)^i * pdegco(A, i)'];
  end;
  Astar = ppck(Astar, degA);

end % if typeA

end % function
