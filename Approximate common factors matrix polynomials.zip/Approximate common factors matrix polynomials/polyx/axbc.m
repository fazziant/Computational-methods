%axbc
% 
% The function
%
%    [X0,K] = axbc(A,B,C[,tol])
%
% solves the polynomial matrix equation AXB = C.
%
% If only one output argument X0 is present then the macro computes 
% only a particular solution X0. If C is a zero matrix then this
% solution is a matrix  
%    X0 = K = [ K1 |
%             | K2 |
%             | .. |
%             | Kp ]
% where the Ki are solutions of the homogeneous equation AXB = 0. 
% If no polynomial solution exists then X0 = [].
%
% If both output argumens are used then the function computes a 
% matrix K = [ K1 |
%            | K2 |
%            | .. |
%            | Kp ]
% such that the Ki are solutions of the homogenoeus equation AXB = 0.
% All possible solutions to AXB = C may be parametrized as
% 
%    X = X0 + t1*K1 + t2*K2 + ... + tp*Kp
%
% where the ti are arbitrary scalar polynomials. If a kernel does 
% not exist then K = [].
%
% The optional argument tol is used to decide whether a solution
% exists or not. If tol is negative then it takes a default value.

% functions used: xab, pinfo, prowjoin, pkron, ptransp,  pdegco, punpck,
%                 ppck, psel


% COPYRIGHT D. Henrion, S. Pejchova, M. Sebek 1997
% $Revision: 1.2 $      $Date: 1997/06/28 16:40:08 $    $State: Exp $

function [X0,K] = axbc(A,B,C,arg4)

test1=0; tol=-1; gnrl=0;
if nargin<3
   test1=1;
elseif isstr(A) | isstr(B) | isstr(C)
   test1=1;
elseif nargin > 3
   if isstr(arg4) | length(arg4)~=1
      test1=1;
   else, tol=arg4;
   end
end
 
if test1
 disp('usage: [X0,K] = axbc(A,B,C[,tol]) ');
 return
end


[typeA,rA,cA,degA] = pinfo(A);
[typeB,rB,cB,degB] = pinfo(B);
[typeC,rC,cC,degC] = pinfo(C);
if isempty(A)|isempty(B)|isempty(C)
   X0=[]; K=[];
   return
end
zeroC=0;
if norm(punpck(C))<eps, zeroC=1;  end

if ~zeroC & ((cB ~= cC) | (rA ~= rC))
  error('axbc: Inconsistent dimensions of the input matrices.');
end;
if nargout==2, gnrl=1; end

if ~zeroC | (zeroC & max(rC,cC)>1)
   vecC = [];
   for i = 1:cC,
     vecC = prowjoin(vecC, psel(C, ':', i));
   end;
else, vecC=0; end 

newA = pkron(B,ptransp(A));
newB = ptransp(vecC);

% call xab with transposed arguments

if gnrl | zeroC
   strout=['[XT,KT]'];
else
   strout=['XT'];
end
strout = [strout,'=xab(newA,newB,tol);'];
eval(strout,'error(lasterr)');
vecX=ptransp(XT);
if gnrl | zeroC, vecK=ptransp(KT); end
if isempty(vecX),

  X0 = [];
  
else                            % PARTICULAR SOLUTION
  degX = max(0, pdegco(vecX));
  X = zeros(cA, rB*(degX+1));
  if ~zeroC
     X(:) = punpck(vecX);
  end
  if degX>0|strcmp(typeA,'poly')|strcmp(typeB,'poly')|strcmp(typeC,'poly')
     X0 = ppck(X, degX);
  else, X0=X;  end
end
if gnrl | zeroC                 % HOMOGENEOUS SOLUTION
 if isempty(vecK)
    K=[];
 else
    [void,void,cK,degK] = pinfo(vecK);
    K = []; Ki = zeros(cA, rB);
    for i = 1:cK,
      Kc = psel(vecK,':',i);
      degKc = pdegco(Kc);
      Kj = [];
      for j = 0:degKc,
        Ki(:) = pdegco(Kc, j);
        Kj = [Kj Ki];
      end;
      Kj = ppck(Kj, degKc);
      K = prowjoin(K,Kj);
    end;
 end;
 [typeK,rK,cK,degK]=pinfo(K);
 if degK<=0&~strcmp(typeA,'poly')&~strcmp(typeB,'poly')&~strcmp(typeC,'poly')
    K=punpck(K);
 end
 if ~gnrl, X0=K; end
end;

