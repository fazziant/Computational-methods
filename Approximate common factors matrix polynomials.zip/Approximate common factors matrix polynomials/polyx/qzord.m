% qzord  
%
% Ordered qz transformation
%
% The command
%
%    [AA,BB,Q,Z] = qzord(A,B[,method][,tol])
%
% produces the ordered qz transformation of the matrices A and B.
% AA and BB are upper triangular matrices and Q and Z nonsingular
% matrices such that Q*A*Z = AA, and Q*B*Z = BB. The generalized 
% eigenvalues of the matrix pair (A,B) are the ratios of the 
% diagonal entries of AA and BB.
%
% The arguments method and tol are optional.
% - If method = 'partial' then the generalized eigenvalues are ordered 
%   such that the infinite generalized eigenvalues come last. This
%   is the default method.
% - If method = 'full' then the generalized eigenvalues are ordered 
%   according to increasing real parts with the infinite generalized 
%   eigenvalues last.
% The input argument tol sets the tolerance in determining whether a 
% generalized value is infinite.

% Huibert Kwakernaak. Last modified April 11, 1997
% Modified by S. Pejchova, June 26, 1997       


function [AA,BB,Q,Z] = qzord(A,B,method,tol);


% Initialization

if nargin<2
 disp('usage:  [AA,BB,Q,Z] = qzord(A,B[,method][,tol])');
 return
end
[rA,cA] = size(A); [rB,cB] = size(B);
if rA ~= cA | rB ~= cB | rA ~= rB
   error('qzord: Inconsistent dimensions of input')
end

if nargin == 2
   method = 'partial'; epp = eps;
elseif nargin == 3
   epp = eps;
elseif nargin == 4
   epp = tol;
elseif nargin > 4
   error('qzord: Too many input arguments')
end
if ~(strcmp(method,'partial') | strcmp(method,'full'))
   error('qzord: Unknown method')
end


n = rA;
[AA,BB,Q,Z] = qz(A,B);


% Order the diagonal entries of AA/BB 

a = diag(AA); b = diag(BB);
for i = 1:n
   if abs(b(i)) < epp*norm(BB)*max(size(BB))^2
      d(i) = Inf;
   else
      if strcmp(method,'partial')
         d(i) = 0;
      else
         d(i) = real(a(i)/b(i));
      end
   end
end
d = d';  

for i = 1 : n*n/4
% [a b d],keyboard
   if sort(d) == d
      break               % done ordering
   end
   for k = 1:n-1
      a11 = AA(k,k); a12 = AA(k,k+1); a22 = AA(k+1,k+1);
      b11 = BB(k,k); b12 = BB(k,k+1); b22 = BB(k+1,k+1);
      if d(k) > d(k+1)
         [c1,s1] = cgivens1(a11*b12-a12*b11,a11*b22-a22*b11);
         [c2,s2] = cgivens1(a12*b22-a22*b12,a11*b22-a22*b11);
         AA(:,k:k+1) = AA(:,k:k+1)*[c2 s2;-s2' c2];
         AA(k:k+1,:) = [c1 s1;-s1' c1]*AA(k:k+1,:);
         BB(:,k:k+1) = BB(:,k:k+1)*[c2 s2;-s2' c2];
         BB(k:k+1,:) = [c1 s1;-s1' c1]*BB(k:k+1,:);
         Z(:,k:k+1) = Z(:,k:k+1)*[c2 s2;-s2' c2];
         Q(k:k+1,:) = [c1 s1;-s1' c1]*Q(k:k+1,:);
         tt = a(k); a(k) = a(k+1); a(k+1) = tt;
         tt = b(k); b(k) = b(k+1); b(k+1) = tt;
         tt = d(k); d(k) = d(k+1); d(k+1) = tt;
      end
   end
end
