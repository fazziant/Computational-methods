% daxya2b
%
% The function
%
%   [x,y] = daxya2b(a,b[,shift])
%
% solves the discrete-time polynomial equation
%
%   a(1/d)x(d) + y(1/d)a(d) = bl(1/d) + br(d)
%
% where a(d) is a polynomial without zeros in abs(d)>=1 (i.e.,
% it is Schur). The input argument b is such that
%
%   b(d) = d^shift [bl(1/d) + br(d)]
%
% If the degree 'shift' is not specified then it is set equal
% to ceil(degb/2).

% Henrion D. March 96
% $Revision: 1.1 $	$Date: 1996/10/07 09:02:33 $	$State: Exp $
% Modified by Henrion D. May 14, 1997
% - input arguments degbl and degbr left out
% Modified by Henrion D. May 28, 1997
% - input argument shift added
% Modified by S. Pejchova, June 26, 1997

% functions used : pinfo, ppck, punpck

function [x,y]=daxya2b(a,b,shift)

if nargin<2
 disp('usage:  [x,y]=daxya2b(a,b[,shift])');
 return
end
[typea, ra, ca, dega] = pinfo(a);
[typeb, rb, cb, degb] = pinfo(b);
if (ra ~= 1) | (ca ~= 1) | (rb ~= 1) | (cb ~= 1),
  error('input arguments must be polynomials');
elseif isinf(dega),
  error('first input argument is the zero polynomial');
end;
if isinf(degb),
  x = ppck(0,0); y = ppck(0,0);
  return;
end;
if strcmp(typeb, 'cons'),
  degb = 0;
end;

% construction of bl(d) = br(d)
if nargin == 2,
  shift = ceil(degb/2);
elseif shift < 0,
  error('the third argument must be non-negative');
end;

degbl = max(shift, degb-shift);
br = b(1,shift+1)/2; bl = br;
if shift < degb, br = [br b(1,shift+2:degb+1)]; end;
br = [br zeros(1,degbl-degb+shift)];
if shift > 0, bl = [bl b(1,shift:-1:1)]; end;
bl = [bl zeros(1,degbl-shift)];

degx = max([dega degbl]);
a = [punpck(a) zeros(1,degx-dega)];
degbr = degbl;

% forward construction of coefficients

backward = []; nit = 0;

while (dega > 0) | (degbr > 0) | (degbl > 0),
  nit = nit + 1;
  if abs(a(1)) < eps,
    error('first input matrix must be strictly stable');
  end;
  if degbr > dega,
    coef = br(degbr+1)/a(1);
    for i = 1:degbr,
      br(i) = br(i) - coef*a(degbr+2-i);
    end;
    br(degbr+1) = 0;
    backward = [backward; 1 coef degbr];
    degbr = degbr - 1;
  elseif degbl > dega,
    coef = bl(degbl+1)/a(1);
    for i = 1:degbl,
      bl(i) = bl(i) - coef*a(degbl+2-i);
    end;
    bl(degbl+1) = 0;
    backward = [backward; 2 coef degbl];
    degbl = degbl - 1;
  else % degbl <= dega  and  degbr <= dega
    coef = a(dega+1)/a(1);
    for i = 1:dega,
      an(i) = a(i) - coef*a(dega+2-i);
    end;
    a = [an(1:dega) 0];
    backward = [backward; 3 coef dega];
    dega = dega - 1;
  end;

end %  while

% backward substitutions

x = zeros(1,degx+1); y = x; xn = x; yn = y;
x(1) = br(1)/a(1);
y(1) = bl(1)/a(1);
for i = nit:-1:1,
  type = backward(i,1);
  coef = backward(i,2);
  deg = backward(i,3);
  if type == 1,
    x(deg+1) = x(deg+1) + coef;
  elseif type == 2,
    y(deg+1) = y(deg+1) + coef;
  else % type == 3
    for j = 1:deg+1,
      xn(j) = x(j) - coef*y(deg+2-j);
      yn(j) = y(j) - coef*x(deg+2-j);
    end;
    x = xn; y = yn;
  end; % if type
end; % for i

% zeroing because the degrees of x and y were over-estimated
% to make easier the vector operations
x = pzero(ppck(x, degx));
y = pzero(ppck(y, degx));












