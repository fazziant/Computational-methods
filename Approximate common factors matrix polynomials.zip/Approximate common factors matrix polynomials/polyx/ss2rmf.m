%ss2rmf
%
% State space to right matrix fraction
%
% The commands
%
%    [N,D] = ss2rmf(a,b,c)
%    [N,D] = ss2rmf(a,b,c,d)
%    [N,D] = ss2rmf(a,b,c,d,tol)
%
% convert the transfer matrix c*(sI-a)^{-1}*b+d of the state
% space system
%
%    dx/dt = ax + bu,  y = cx+du,
%
% to a right coprime polynomial matrix fraction representation 
%
%    D^{-1}*N
%
% The input parameters d and tol are optional.
%
% The parameter tol is a tolerance that is used in determining 
% the controllability indexes (that is, the column degrees of D).

% R.C.W. Strijbos, 1996
% $Revision: 1.1 $       $Date: 1995/12/05 14:31:12 $     $State: Exp $

function [N,D] = ss2rmf(a,b,c,d,tol)

if nargin~=3 & nargin ~=4 & nargin~=5
   disp('usage: [N,D] = ss2rmf(a,b,c[,d[,tol]])');
   return
end

[typea,ra,ca,dega]=pinfo(a);
[typeb,rb,cb,degb]=pinfo(b);
[typec,rc,cc,degc]=pinfo(c);
if nargin==3   
   d = zeros(rc,cb);
end
[typed,rd,cd,degd]=pinfo(d);
if ~isnan(dega) | ~isnan(degb) | ~isnan(degc) | ~isnan(degd)
   error('ss2lmf: The input matrices should be constant matrices');
end
if ra~=ca | ra~=rb | ra~=cc | cb~=cd | rc~=rd
   error('ss2lmf: The input matrices have incompatible sizes');
end

if nargin == 5
   [f,g,h,n] = bhf(a',c',b',tol);
   [F,G,H,n] = bhf(f',h',g',tol);
else
   [f,g,h,n] = bhf(a',c',b');
   [F,G,H,n] = bhf(f',h',g');
end
if length(n) == 0
   D=ppck(eye(cb),0);
   N=ppck(zeros(rc,cb),0);
else
   [N,D]= bhf2rmf(F,G,H,n);
end
N=padd(N,pmul(d,D));
