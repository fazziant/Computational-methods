%hhr
%
% This macro carries out a sequence of Householder transformations
% from the right to bring the constant input matrix in the form
%
%      | 0 0 .......0 * * * * |
%      | 0 0 .......0 0 * * * |
%      | 0 0 .......0 0 0 * * |
%      | 0 0 .......0 0 0 0 * |
%
% The command
%
%    [V,T,rankV] = hhr(U)
%
% returns the output matrix V, the transformation matrix T with 
% V = U*T and the rank of the input matrix U.

% Rens C.W. Strijbos, 1996
% $Revision: 1.1 $	$Date: 1995/08/21 10:16:24 $	$State: Exp $

function[V,T,rankV] = hhr(U,tol)

if nargin < 1
   disp('usage: [V,T,rankV] = hhr(U)')
   return
end
   
[typeu,ru,cu,degu]=pinfo(U);
if typeu == 'poly'
   error('hhr: The input matrix should be of the constant type')
end   
T=eye(cu);
V=U';
rankV=0;

if nargin == 1
   tol = 1e5*eps;
end
rowoffset=0;
for i=ru:-1:1
   inter=cu-ru+i+rowoffset;
   u=V(1:inter,i);
   lengthu=length(u);
   k = norm(u);
   if k>tol & lengthu>1
      if u(inter)>0
      	k = -k;
      end
      w = u;
      w(inter) = w(inter)-k;
      W = w/norm(w);
      Tloc = eye(lengthu)-2*W*W';
      T(1:inter,:)=Tloc*T(1:inter,:);
      V=T*U';
      rankV=rankV+1;
   else
      if k>tol
	 rankV=rankV+1;
	 break;
      end
      if length(u)>=1
	 rowoffset=rowoffset+1;
      end
   end
end
T=T';
V=V';

