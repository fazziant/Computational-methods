% pdet
%
% Determinant of a polynomial matrix
%
% The commands
%
%    detA = pdet(A)
%    detA = pdet(A,'z')
%    detA = pdet(A,'z',tol)
%    detA = pdet(A,method)
%    detA = pdet(A,method,'z')
%    detA = pdet(A,method,'z',tol)
%
% calculate the determinant of the square polynomial matrix A.
%
% The (default) method 'eig' computes the determinant as the 
% characteristic polynomial of the block companion matrix 
% corresponding to A.
% The method 'int' uses polynomial interpolation with complex 
% interpolation points.
% The method 'mfl' uses a modified Fadeev-Leverrier algorithm.
% The method 'tri' is based on triangularization of A.
%
% The input arguments 'z' and tol are used in "zeroing" (see the 
% function 'pzero'). The default value of tol is computed from the 
% degree and sizes of A. If 'z' and tol are missing then the macro 
% runs without "zeroing".

% functions used: pinfo, punpck, punpckv, ppck, pval, newtpol, pmul,
%                pdegco, ptrace, proots, pstairs, psel, pscl, pzero

% COPYRIGHT S. Pejchova, M. Sebek, 1997
% $Revision: 1.6 $      $Date: 1997/04/25 12:52:17 $    $State: Exp $

function detA = pdet(A,arg2,arg3,arg4)

test1=0;, zeroing=0;, method='mfl';, tol=eps;, n=[];

if nargin==0
   test1=1;
elseif isstr(A)
   test1=1;
elseif nargin>1
   for i=2:nargin
       stg=['argm=arg',int2str(i),';'];
       eval(stg);
       if isstr(argm)
          if strcmp(argm,'z')
              if zeroing==0, zeroing=2; end
          elseif strcmp(argm,'mfl') | strcmp(argm,'eig') |...
              strcmp(argm,'int') | strcmp(argm,'tri')
              method=argm;
          else
              test1=1;
          end
       elseif length(argm)==1
          tol=argm;
          zeroing=1;
       else
          test1=1;
       end
   end
end

if test1
   disp('usage: detA = pdet(A)                or  detA = pdet(A,''z'') ');
   disp('    or detA = pdet(A,''z'',tol) ');
   disp('    or detA = pdet(A,''eig'')          or  detA = pdet(A,''eig'',''z'') ');
   disp('    or detA = pdet(A,''eig'',''z'',tol) ');
   disp('    or detA = pdet(A,''int'')          or  detA = pdet(A,''int'',''z'') ');
   disp('    or detA = pdet(A,''int'',''z'',tol) ');
   disp('    or detA = pdet(A,''mfl'')          or  detA = pdet(A,''mfl'',''z'') ');
   disp('    or detA = pdet(A,''mfl'',''z'',tol) ');
   disp('    or detA = pdet(A,''tri'')          or  detA = pdet(A,''tri'',''z'') ');
   disp('    or detA = pdet(A,''tri'',''z'',tol) ');
   return
end

[typeA,rA,cA,degA]=pinfo(A);
if rA~=cA
   error('pdet: The input matrix is not square');
end
if isnan(degA), detA=det(A);, return, end
if degA==0 | isinf(degA)
   detA=det(punpckv(A));
   detA=ppck(detA,0);
   return
end

NormA=norm(punpck(A));
if NormA~=0
   A=pscl(A,1/NormA); 
end
if zeroing==2  % default value for zeroing
    tol=norm(punpck(A))*(max(size(punpck(A))))*eps; 
    ttol=1/tol;
elseif zeroing==1
   tol=tol/(NormA^rA);
   ttol=1/tol;
end
coldegA=pdegco(A,'col'); rowdegA=pdegco(A,'row');
degofdet=min(sum(coldegA),sum(rowdegA));
if degofdet < 0
   detA=ppck(0,-inf);
   return
end

[DA,LA]=pdegco(A,'ent'); LAR=rot90(LA);
if norm(triu(LA,1))==0 | norm(tril(LA,-1))==0  % INPUT MATRIX IS
   detA=psel(A,1,1);                           %      TRIANGULAR
   if rA > 1
      for k=2:rA
          detA=pmul(detA,psel(A,k,k));
      end
   end

   if zeroing > 0 
      detA=pzero(detA,tol);
   end
   detA=pscl(detA,(NormA)^rA);
   return
elseif norm(triu(LAR,1))==0 | norm(tril(LAR,-1))==0
   detA=psel(A,1,rA);
   if rA > 1
      for k=2:rA
          detA=pmul(detA,psel(A,k,rA-k+1));
      end
   end

   if zeroing > 0 
      detA=pzero(detA,tol);
   end
   detA=pscl(detA,-(NormA)^rA);
   return
end

if strcmp(method,'int')                   % INTERPOLATION
   k=ceil((degofdet+1)/2);
   Om1=0.1*(k:-1:1);
   SJ=-1*(Om1.^2);
   Om=sqrt(-1)*Om1;
   d=zeros(1,k);
   for j=1:k
       Aj=pval(A,Om(j));
       d(j)=det(Aj);
   end
   R=real(d);
   I=imag(d)./Om1;

   ar=newtpol(R,SJ);
   ai=newtpol(I,SJ);
   for n=k-1:-1:1
       for j=n:k-1
           ar(j)=ar(j)-ar(j+1)*SJ(n);
           ai(j)=ai(j)-ai(j+1)*SJ(n);
       end
   end
   a=zeros(1,degofdet+2);
   a(1:2:degofdet+1)=ar;
   a(2:2:degofdet+2)=ai;
   a=a(1:degofdet+1);
   detA=ppck(a,degofdet);

   if zeroing>0 
      detA=pzero(detA,tol);
   end
   detA=pscl(detA,(NormA)^rA);
   return
end

if strcmp(method,'mfl')                   % MODIFIED FADEEV-LEVERRIER
   B=ppck(eye(rA),0);
   for k=1:rA
       B=pmul(B,A);
       d=(-punpck(ptrace(B)))/k;
       [typeB,rB,cB,degB]=pinfo(B);
       if isinf(degB), degB=0;, end
       d=[d,zeros(1,(degB+1-length(d)))];
       Baux=punpckv(B);
       for i=1:rA
           for l=1:degB+1
               Baux(i,(l-1)*rA+i)=Baux(i,(l-1)*rA+i)+d(1,l);
           end
       end
       B=ppck(Baux,degB);
   end
   if rem(rA,2)~=0, d=-d;, end
   detA=ppck(d,degB);
   if zeroing>0 
      detA=pzero(detA,tol);
   end

   detA=pscl(detA,(NormA)^rA);
   return
end

if strcmp(method,'eig')                   % BY EIGENVALUES
   z=proots(A,'eig','all');               % zeros of polynomial matrix
   if sum(isnan(real(z)))
      detA=ppck(0,0);
      return                              % singular matrix
   end
   kinf=find(isinf(z)==0);
   if isempty(kinf), z=[];
   else,  z=z(kinf);
   end
   % first zeroing to cut "almost infinite" eigenvalues
   if zeroing > 0
      n=find(abs(z) > ttol);
   end;
   if isempty(n)==0, z(n)=[];, end
   if isempty(z)
      d=1;, degd=0;
      zet=0;
   else
      d=poly(z);
      degd=length(d)-1;
      d=d(degd+1:-1:1);

      % choice of zet which is not a zero
      f = 0;
      while ~isempty(f),
         zet = randn / norm(punpck(A));
         f = find(abs(z - zet) < eps);
      end;
   end
   Az=pval(A,zet);
   Azd=det(Az);
   if Azd==0
      detA=ppck(0,0);
      return
   end
   dz=pval(ppck(d,degd),zet);
   k=Azd/dz;
   D=k*d;
   if norm(imag(punpck(A)))<eps*1e4
      D=real(D);
   end
   detA=ppck(D,degd);

   if zeroing>0 % second zeroing to cut leading-coefficients
      detA=pzero(detA,tol);
   end
   detA=pscl(detA,(NormA)^rA);
   return
end

if strcmp(method,'tri')                   % TRIANGULARIZATION
   if zeroing > 0
      TRA = pstairs(A,tol);
   else
      TRA = pstairs(A);
   end
   detA=psel(TRA,1,1);
   if rA > 1
      for k=2:rA
          detA=pmul(detA,psel(TRA,k,k));
      end
   end

   if zeroing > 0 
      detA=pzero(detA,tol);
   end
   detA=pscl(detA,(NormA)^rA);
   return
end

