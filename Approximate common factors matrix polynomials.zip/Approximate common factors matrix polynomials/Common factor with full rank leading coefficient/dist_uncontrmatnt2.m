function [ dist,eps0,A,E,Phat,epsval,sval ] = dist_uncontrmatnt2(P,dim,deg,tol,w,met,itmax,output)

%w=2;
% default
if nargin<8
    output=0;
end
if nargin<7
    itmax=40;
end
if nargin<6
    met=1;
end

h0=1e-4;
threshold1=1e-10;
threshold2=1e-10;
c=0.8;
epsval=[];
sval=[];

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;
% w=(size(P,2)/dim-1)*(1+dim);
%w=3;

%construction of A
%A=readmatpol(P,dim);
P1=P(1:dim,:);
P2=P(dim+1:end,:);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);
svd(A)


if output==1
    A
    pause(3)
end

% estimate interval for distance
S=svd(A);
%epsmin=S(end+1-dim*deg);    %prova
epsmin=1e-3;

   epsmax=norm(A,'fro')
%     epsmax=S(end-dim*deg);
%  epsmax=sqrt(deg)*norm(P1-P2,'fro')
%eps0=min(2*epsmin,(epsmin+epsmax)/2);
 eps0=epsmin;
% [epsmin,epsmax,eps0]
% pause


if met==1
    [zvec,x,y,A,B,E]=controlodematimp(P,dim,deg,eps0,w,h0);
  
elseif met==2    
[zvec,x,y,A,B,E]=controlodematord2t(P,dim,deg,eps0,w,h0);
 else
  [zvec,x,y,A,B,E]=controlodematord2mp(P,dim,deg,eps0,h0);
end

for it=1:itmax
    
    epsval(it)=eps0;
    sval(it)=zvec(end);
    if output==1
        format short e
        [it,epsmin,epsmax,eps0,abs(zvec(end))];
%       pause
    end
    abs(zvec(end))
    if (zvec(end)) > threshold2 %&& it<=10
        
%       Eold=E;%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%era commentato
   %%%%% Newton's method
        epsmin=eps0;
            
     %     [evec,lambda]=eig(B'*B);
%     x=evec(:,deg*dim);
     [U,Sigma,V]=svd(B);
     sigma=diag(Sigma);
     l=length(sigma);
%      
          x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
    xT=x';
  
    % y=B*x;
     z = sigma(end+1-dim*deg); 
    %   newproj((y*xT),nP-1,dim,w+1)
%     y
%     xT
         drho=norm(newproj((y*xT),nP-1,dim,w+1),'fro');
         
         %%%%%%%%   Newton
%                       eps1=eps0+ (z/drho);
           
     %%%%%%%%%%%%  add a constant      
          eps1=eps0+.005;
   
       
   
         svd(A+eps1*E);
        %eps1=(epsmin+epsmax)/2;

     
% % %         epsmin=eps0
% % %         delta=(epsmax-epsmin)/9
% % %         epsilon=[epsmin:delta:epsmax]
% % %          eps11=epsilon(2);eps12=epsilon(8);
% % %          eps13=epsilon(4);eps14=epsilon(6);
% % %          sigma1=svd(A+eps11*E); sigma2=svd(A + eps12*E);
% % %          
% % %          lambda11=sigma1(end+1-deg*dim); lambda12=sigma2(end+1-dim*deg);
% % %      
% % %          inteps=interp1([eps11, eps12], [lambda11, lambda12], epsilon, 'pchip')
% % %          [val, i]=min(abs(inteps))
% % % % % %          xx=find(inteps>0);  xy=min(epsilon(xx)); xz=find(epsilon==xy);
% % % % % %          eps1=epsilon(xz);
% % %          eps1=val
         
% %         epsmin=eps0;
% %         delta=(epsmax-epsmin)/9;
% %         epsilon=[epsmin:delta:epsmax];
% %          eps11=epsmin;eps12=epsmax;eps13=.1*epsmin+.9*epsmax;eps14=.2*epsmin+.8*epsmax;% eps11, eps12, eps13, eps14
% %          sigma1=svd(A+eps11*E); sigma2=svd(A+eps12*E); sigma3=svd(A+eps13*E); sigma4=svd(A+eps14*E);
% %          lambda11=sigma1(end+1-dim*deg); lambda12=sigma2(end+1-dim*deg);lambda13=sigma3(end+1-dim*deg);
% %          lambda14=sigma4(end+1-dim*deg);
% %          parab=polyfit([eps11,eps12,eps13,eps14],[lambda11,lambda12,lambda13,lambda14],3); %parab
% %          inteps=polyval(parab,epsilon); %plot(inteps)
% %          [val, i]=min(abs(inteps));
% %          eps1=val
       
       
          
        
        if eps1>epsmin & eps1<epsmax
            disp('in the interval')
            if abs(eps1-eps0)< tol
                eps0=eps1;
                break
            else
                eps0=eps1;
            end
        else
            disp('out of the interval')
            % pause
            eps0=(1-c)*epsmin+c*epsmax;
            
        end

%         elseif zvec(end) > threshold1 && zvec(end)< threshold2
%              disp('bisection step left'), it
% %             epsmin=eps0;
%             eps0=(1-c)*epsmin+c*epsmax
%             if abs(epsmin-eps0)< 1e-6
% %                 eps0=eps1;
%                 break
%          
%             end
         
    else
        disp('bisection step right'), it
        epsmax=eps0;
        eps0=(1-c)*epsmin+c*epsmax;
%         if abs(epsmax-eps0)< 1e-6
% %                 eps0=eps1;
%                 break
%            
%             end
       % Eold=E; %%%%%%%%%%%%%%%%%%%%%%%%%%%%%era E=Eold
    end
    %%%%%%%%%   convergence test
%      if eps1>epsmin & eps1<epsmax
%             if abs(eps1-eps0)<tol 
%                 eps0=eps1;
%                 break
%             else
%                 eps0=eps1;
%             end
%         else
%             disp('out of the interval')
%          %   pause
%             eps0=(1-c)*epsmin+c*epsmax;
%         end
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %zvec=[];
    Eold=E;
    disp('integration of ODE')
   if met==1
     [zvec,x,y,A,B,E]=controlodematimp(P,dim,deg,eps0,w,h0,E);
    
   elseif met==2    
[zvec,x,y,A,B,E]=controlodematord2t(P,dim,deg,eps0,w,h0,E);
 else
  [zvec,x,y,A,B,E]=controlodematord2mp(P,dim,deg,eps0,h0,E);
end
    disp('completed')
%    if epsmax-epsmin<tol
%        break
%    end
B
zvec
   for i=1:50
       E2=randn(size(E));
       E2=E2/norm(E2,'fro');
       B2=A+eps0*E2;
       sigma2=svd(B2);
       if sigma2(end+1-dim*deg)<zvec(end)
           disp('found')
           sigma2(end+1-dim*deg)
           zvec(end)
%            pause
       end
   end

end
% format long
% zvec

% this is the computed distance;

S1 = max(svd(A));
S2=  max(svd(B));
dist = S1-S2;
B=A+eps0*E;
Phat(1:dim,:)=B(1:dim,1:dim*(n+1)); 

Phat(dim+1:2*dim,:)=B(size(B,1)/2+1:size(B,1)/2+dim,1:dim*(n+1)); % 2 is the half not the dimension

end