function S = Sprojgenmat(E,n,dim)
% Projection onto Sylvester structure
% E is the matrix we want to project
% n is the degree of the polynomials
% dim is the dimension of the coefficients (assumed square matrices)





for i=1:n+1
    P(1:dim,i*dim-1:i*dim)=0;
    P(dim+1:2*dim, i*dim-1:i*dim) = 0;
    for j=1:n
      P(1:dim,i*dim-1:i*dim)=P(1:dim,i*dim-1:i*dim)+E(j*dim-1:j*dim,j*dim-1+(i-1)*dim:j*dim+(i-1)*dim);
      P(1+dim:2*dim,i*dim-1:i*dim)=P(1+dim:2*dim,i*dim-1:i*dim)+E(n*dim+j*dim-1:n*dim+j*dim,j*dim-1+(i-1)*dim:j*dim+(i-1)*dim);
    end
    P(1:dim,i*dim-1:i*dim)=P(1:dim,i*dim-1:i*dim)./(n+1);
    P(1+dim:2*dim,i*dim-1:i*dim)=P(1+dim:2*dim,i*dim-1:i*dim)./(n+1);
end
S=readmatpol(P,dim);


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % patterns of variable parameters, example
% % p(2)=0; p(4)=0; p(6)=0; q(2)=0; q(4)=0; q(6)=0;
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
% for i=1:n
%     S(i,:)   = [zeros(1,i-1),P(1,:),zeros(1,n-i)];
% end
% for k=2:m
% for i=1:n
%     S((k-1)*n+i,:) = [zeros(1,n-i),P(k,:),zeros(1,i-1)];
% end
% end
