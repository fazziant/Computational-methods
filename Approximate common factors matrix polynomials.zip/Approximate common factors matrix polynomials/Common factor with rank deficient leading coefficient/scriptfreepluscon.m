dP = 3; d = 1; m = 2; n = 2;
% [M, ph,C0] = mat_agcd_antonio(p,dim, d);
C0 = [eye(m); rand(m*d,m)]';
P0 = [];
dA = dP - d;
A0 = rand(m * (dA + 1), m*n)';
P0 = (A0*blktoep(C0, m, dA) );
P = P0 + 0.01 * randn(size(P0));
P1=P(1:m,:);
P2=P(m+1:end,:);
dim=m;
deg=d;

% w=(size(P,2)/dim-1)*(1+dim);
% w=w-dP;
 
w=5;

h0=1e-4;
threshold=1e-6;
c=0.5;
epsval=[];
sval=[];

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;
% w=n*(1+dim)-2;

%construction of A
%A=readmatpol(P,dim);
P1=P(1:dim,:);
P2=P(dim+1:end,:);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);



% estimate interval for distance
S=svd(A);
sval=S(end+1-dim*deg);
epsmin=sval(1);   %prova
% 
 epsmax=norm(A,'fro');
 %epsmax=sqrt(deg)*norm(P1-P2,'fro')
eps0=min(2*epsmin,(epsmin+epsmax)/2)
% eps0=epsmin;
% [epsmin,epsmax,eps0]
% pause



 [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,eps0,w,h0);
 disp('singval')
 zvec
 plotpoints=[zvec];
%  if zvec(end)>1e-8
 delta=1-2*eps0;

 epsval=[eps0, eps0/(eps0+delta)];
 norm((epsval(end-1)/epsval(end))*E,'fro')
 disp('freedyn')
 [zvecf,xf,yf,A,Bf,Ef]=controlodematntfree(P,dim,deg,eps0,epsval(end),w,h0,(epsval(end-1)/epsval(end))*E);
 zvecf
 norm(Ef,'fro')
 norm(epsval(end)*Ef,'fro')
 plotpoints(end), zvecf(1)
 plotpoints=[plotpoints, zvecf];
 disp('condyn')
 [zvec,x,y,A,B,E]=controlodematnt(P,dim,deg,epsval(end)*norm(Ef,'fro'),w,h0,Ef);
 plotpoints(end), zvec(1)
 plotpoints=[plotpoints, zvec];
 
 semilogy(plotpoints)
 epsstar=norm(B-A,'fro')