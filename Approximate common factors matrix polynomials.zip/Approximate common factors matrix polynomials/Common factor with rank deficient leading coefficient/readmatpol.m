function A=readmatpol(P,m1)
% P is the matrix whose block rows are the matrix polynomials
%m1,n1 are the dimensions of the coefficients for the 1st pol
%m2,n2 are the dimensions of the coefficients for the 1st pol
%the function build the corresponding Sylvester matrix

% P =[ 1     1     2     1  3  5;
%      0     1     1     2  2  0;
%      1     1     1     2  1  4;
%      1     0     1     3  3  3];
%  m1=2;n1=2;
%  m2=2;n2=2;

m2=m1;
n1=m1;
n2=m1;

r=size(P,1)/m1;
c=size(P,2)/m2;
deg=c-1;


A=zeros(r*m1*deg,2*n1*deg);
% Construction of A



     for i=1:deg
    A(m1*i-1:i*m1,:)=[zeros(m1,n1*(i-1)),P(1:m1,:),zeros(m1,n1*(deg-i))];
     A(m1*deg+m1*i-1:m1*deg+i*m1,:)=[zeros(m1,n1*(i-1)),P(m1+1:2*m1,:),zeros(m1,n1*(deg-i))]; 
     end
   