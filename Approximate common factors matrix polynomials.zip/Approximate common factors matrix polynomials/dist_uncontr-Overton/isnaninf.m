function ini = isnaninf(M)
% returns the scalar 1 if ANY entry of M is nan or inf; 0 otherwise
% note: isnan and isinf return matrices if M is a matrix, and
% if treats [0 1] as false, not true.
% ini = sum(sum(isnan(M))) > 0 | sum(sum(isinf(M))) > 0;
ini = any(any(isnan(M))) | any(any(isinf(M)));
