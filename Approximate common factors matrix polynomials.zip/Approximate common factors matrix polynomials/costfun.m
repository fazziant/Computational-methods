function [f, Ph] = costfun(C, P, m, dA) 
 C = [eye(size(C, 2)); C];
Mc = multmat(C, m, dA)
P
Ph = Mc * (Mc \ P);
f = norm(P - Ph, 'fro');