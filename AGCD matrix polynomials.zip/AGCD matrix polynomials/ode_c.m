function [zvec,x,y,A,B,E]=ode_c(P,dim,deg,epsil,w,h0,E)
%%%%%%% output 
% zvec = smallest singular value
% x = left eigenvector of B^T B associated to the smallest eigenvalue
% y = B*x
% A = Sylvester matrix associated to the starting polynomials
% B = A + epsilon * E
% E = Perturbation matrix

%%%%%%%%%%%%  input
% P = matrix containing the data polynomials
% deg is the degree of the GCD
% epsil: scalar parameter of the perturbation epsilon * E
% h0 = starting value of the step in Euler method
% E = perturbation matrix
  
format short
%zeroval=1e-14;
tol=1e-10;
h=h0;
hmin=1e-14;
countmax=200;
gamma=1.2;
%w=2; %parameter for the dimension of the toeplitz blocks

mP=size(P,1)/dim;
nP=size(P,2)/dim;
n=nP-1;

% w=n*(1+dim);
%w=3;

P1=P(1:dim,:);
P2=P(dim+1:end,:);
A=[blktoep(P1,1,w); blktoep(P2,1,w)];
[mA,nA]=size(A);



% Initialization
k=1;
if nargin < 7
    E=zeros(mA,nA);
    B=A+epsil*E;

     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     l=length(sigma);
     
     x=V(:,end+1-dim*deg);
     y=U(:,size(V,2)+1-dim*deg);

     xT=x';
     
     
     z = sigma(end+1-dim*deg);

   
    E=-(y*xT);                         
   E = newproj(E,nP-1,dim,w+1);
    E=E/norm(E,'fro');

%   starting matrix   
%   starting matrix   
    B=A+epsil*E;

     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     l=length(sigma);
     
     x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
     xT=x';
     
     
     z = sigma(end+1-dim*deg);


    
    zvec(k)=z;
    Edot=-(y*xT);                  
    
    Edot=newproj(Edot,nP-1,dim,w+1);
    Edot=Edot- (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');

else
    E=E/norm(E,'fro');
   E=newproj(real(E),nP-1,dim,w+1);
   
    B=A+epsil*E;

     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     l=length(sigma);
     
     x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
     xT=x';
     
     z = sigma(end+1-dim*deg);

    zvec(k)=z;
    Edot=-(y*xT);                        
   Edot=newproj(Edot, nP-1,dim,w+1);
    Edot=Edot - (trace(Edot'*E))*E;
    Edot=Edot/norm(Edot,'fro');
    
end

Eold=E;

while h>hmin

z=zvec(k);
count=0;
  while count<=countmax
    count=count+1;
    B=A+epsil*E;
     [U,Sigma,V]=svd(B);
     format long
     sigma=diag(Sigma);
     l=length(sigma);
     
     x=V(:,l+1-dim*deg);
     y=U(:,l+1-dim*deg);
     
     xT=x';
     
     
     z = sigma(end+1-dim*deg);


    if abs(z)<abs(zvec(k))
        Edot=-(y*xT);                  
        Edot=newproj(Edot,nP-1,dim,w+1);
        Edot=Edot-(trace(Edot'*E))*E;
        Edot=Edot/norm(Edot,'fro');

        k=k+1;
        zvec(k)=z;
        Eold=E;
        break
    else
        h=h/gamma;
        E=Eold+h*Edot;
        E=E/norm(E,'fro');
    end
end

if count==1
    h=h*gamma;
end
if count==countmax+1
   disp('maximum number of its reached in while loop')
    return
end

% Error control
if k>1
    if abs(zvec(k)) > abs(zvec(k-1))
        disp('monotonicity broken');
       pause
    end
    if abs(zvec(k)) <= 1e-6
       disp('matrix looks singular');
        return
    end
    if abs(zvec(k)-zvec(k-1) <= tol) 
        disp('reached tolerance');
        return
     end
end

% Euler step
E=Eold+h*Edot; 
E=E/norm(E,'fro');

end