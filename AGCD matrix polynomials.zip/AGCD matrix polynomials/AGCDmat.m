function [dist, Phat, C]=AGCDmat(P,dim,deg,w)


  [dist,eps0,A,E,Phat,epsval,sval ] = dist_agcd(P,dim,deg,1e-6,w);

format long

dist=dist
degpol=size(P,2)/dim-1;
Prev1=zeros(size(P,1)/2,size(P,2));
Prev2=zeros(size(P,1)/2, size(P,2));
for i=1:degpol+1
    Prev1(:,2*i-1:2*i)=Phat(1:dim,end-2*i+1:end-2*i+2);
    Prev2(:,2*i-1:2*i)=Phat(dim+1:end,end-2*i+1:end-2*i+2);
end
A1=ppck(Prev1,degpol) 
A2=ppck(Prev2,degpol) 

%  GCDr=grd(A1,A2,'t',1e-4)
%  GCDr=grd(A1,A2,'t',1e-3)
  GCDr=grd(A1,A2,'t',1e-2)

 C=GCDr;



% svd([blktoep(P(1:dim,:),1,w); blktoep(P(dim+1:end,:),1,w)])
% svd([blktoep(Phat(1:dim,:),1,w); blktoep(Phat(dim+1:end,:),1,w)])
%  proots(A1)
%  proots(A2)